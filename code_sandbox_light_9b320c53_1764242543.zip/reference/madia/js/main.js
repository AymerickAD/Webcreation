// ==========================================
// Mad'ia - Main JavaScript
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all features
    initNavigation();
    initScrollAnimations();
    initPortfolioFilter();
    initContactForm();
    initBackToTop();
    initSmoothScroll();
    initParallaxEffect();
});

// ==========================================
// Navigation
// ==========================================
function initNavigation() {
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section[id]');

    if (!navbar) {
        return;
    }

    const updateNavbarState = () => {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    };

    let highlightTicking = false;

    const highlightActiveSection = () => {
        const scrollY = window.pageYOffset;

        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 120;
            const sectionId = section.getAttribute('id');
            const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);

            if (!navLink || !navLink.getAttribute('href').startsWith('#')) {
                return;
            }

            if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
                navLinks.forEach(link => link.classList.remove('active'));
                navLink.classList.add('active');
            }
        });

        highlightTicking = false;
    };

    const handleScroll = () => {
        updateNavbarState();

        if (!highlightTicking) {
            highlightTicking = true;
            requestAnimationFrame(highlightActiveSection);
        }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    updateNavbarState();
    highlightActiveSection();

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (!link.getAttribute('href').startsWith('#')) {
                return;
            }

            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            if (navMenu && navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');

                if (navToggle) {
                    navToggle.classList.remove('active');
                }
            }
        });
    });
}

// ==========================================
// Scroll Animations
// ==========================================
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
            }
        });
    }, observerOptions);
    
    // Observe all elements with scroll-reveal class
    document.querySelectorAll('.scroll-reveal').forEach(el => {
        observer.observe(el);
    });
    
    // Animate skill progress bars when visible
    const skillObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBars = entry.target.querySelectorAll('.skill-progress');
                progressBars.forEach(bar => {
                    const width = bar.style.width;
                    bar.style.width = '0';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 100);
                });
                skillObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    const skillsChart = document.querySelector('.skills-chart');
    if (skillsChart) {
        skillObserver.observe(skillsChart);
    }
}

// ==========================================
// Portfolio Filter
// ==========================================
function initPortfolioFilter() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.getAttribute('data-filter');
            
            // Update active button
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Filter items
            portfolioItems.forEach(item => {
                const category = item.getAttribute('data-category');
                
                if (filter === 'all' || category === filter) {
                    item.style.display = 'block';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 10);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
}

// ==========================================
// Contact Form
// ==========================================
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const data = Object.fromEntries(formData.entries());
            
            // Create mailto link with form data
            const subject = encodeURIComponent(`Demande de ${data.service} - ${data.name}`);
            const body = encodeURIComponent(`
Nom: ${data.name}
Email: ${data.email}
Téléphone: ${data.phone || 'Non renseigné'}
Entreprise: ${data.company || 'Non renseignée'}
Type de projet: ${data.service}

Message:
${data.message}
            `);
            
            const mailtoLink = `mailto:dansicare.aymerickpro@gmail.com?subject=${subject}&body=${body}`;
            
            // Open email client
            window.location.href = mailtoLink;
            
            // Show success message
            showAlert('Votre client email va s\'ouvrir. Merci !', 'success');
            
            // Reset form
            contactForm.reset();
        });
    }
}

// ==========================================
// Back to Top Button
// ==========================================
function initBackToTop() {
    const backToTopBtn = document.getElementById('backToTop');
    
    if (!backToTopBtn) {
        return;
    }

    let toggleTicking = false;

    const updateButtonState = () => {
        const shouldBeVisible = window.scrollY > 500;
        backToTopBtn.classList.toggle('visible', shouldBeVisible);
        toggleTicking = false;
    };

    window.addEventListener('scroll', () => {
        if (!toggleTicking) {
            toggleTicking = true;
            requestAnimationFrame(updateButtonState);
        }
    }, { passive: true });

    updateButtonState();
    
    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// ==========================================
// Smooth Scroll
// ==========================================
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Skip if href is just "#"
            if (href === '#') return;
            
            const target = document.querySelector(href);
            
            if (target) {
                e.preventDefault();
                
                const offsetTop = target.offsetTop - 80;
                
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ==========================================
// Alert Helper
// ==========================================
function showAlert(message, type = 'info') {
    // Create alert element if it doesn't exist
    let alertEl = document.getElementById('alertMessage');
    
    if (!alertEl) {
        alertEl = document.createElement('div');
        alertEl.id = 'alertMessage';
        alertEl.className = 'alert-message';
        alertEl.innerHTML = `
            <div class="alert-content">
                <i class="fas fa-info-circle"></i>
                <span id="alertText"></span>
            </div>
        `;
        document.body.appendChild(alertEl);
    }
    
    const alertText = document.getElementById('alertText');
    const alertIcon = alertEl.querySelector('i');
    
    // Set message
    alertText.textContent = message;
    
    // Set icon based on type
    alertEl.className = 'alert-message ' + type;
    
    switch(type) {
        case 'success':
            alertIcon.className = 'fas fa-check-circle';
            break;
        case 'error':
            alertIcon.className = 'fas fa-times-circle';
            break;
        case 'warning':
            alertIcon.className = 'fas fa-exclamation-triangle';
            break;
        default:
            alertIcon.className = 'fas fa-info-circle';
    }
    
    // Show alert
    setTimeout(() => {
        alertEl.classList.add('show');
    }, 100);
    
    // Hide after 4 seconds
    setTimeout(() => {
        alertEl.classList.remove('show');
    }, 4000);
}

// ==========================================
// Parallax Effect (Optional Enhancement)
// ==========================================
function initParallaxEffect() {
    const parallaxElements = document.querySelectorAll('.parallax');

    if (!parallaxElements.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
    }

    let rafId = null;

    const updateParallax = () => {
        const scrolled = window.pageYOffset;

        parallaxElements.forEach(el => {
            const rate = scrolled * -0.3;
            el.style.transform = `translate3d(0, ${rate}px, 0)`;
        });

        rafId = null;
    };

    window.addEventListener('scroll', () => {
        if (rafId === null) {
            rafId = requestAnimationFrame(updateParallax);
        }
    }, { passive: true });

    updateParallax();
}