// ==========================================
// Mad'ia - Advanced Animations
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    initFloatingCards();
    initParticles();
    initCursorEffect();
});

// ==========================================
// Floating Cards Animation
// ==========================================
function initFloatingCards() {
    const cards = document.querySelectorAll('.floating-card');
    
    if (!cards.length || window.innerWidth <= 768 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
    }

    const cardData = Array.from(cards).map((card, index) => {
        const randomX = Math.random() * 20 - 10;
        const randomY = Math.random() * 20 - 10;
        const intensity = (index + 1) * 0.02;

        card.style.setProperty('--random-x', `${randomX}px`);
        card.style.setProperty('--random-y', `${randomY}px`);

        return { card, intensity };
    });

    let pointerX = window.innerWidth / 2;
    let pointerY = window.innerHeight / 2;
    let rafId = null;

    const updateCardsPosition = () => {
        cardData.forEach(({ card, intensity }) => {
            const moveX = (pointerX - window.innerWidth / 2) * intensity;
            const moveY = (pointerY - window.innerHeight / 2) * intensity;
            const baseX = parseFloat(card.style.getPropertyValue('--random-x')) || 0;
            const baseY = parseFloat(card.style.getPropertyValue('--random-y')) || 0;

            card.style.transform = `translate(${baseX + moveX}px, ${baseY + moveY}px)`;
        });

        rafId = null;
    };

    document.addEventListener('mousemove', (event) => {
        pointerX = event.clientX;
        pointerY = event.clientY;

        if (rafId === null) {
            rafId = requestAnimationFrame(updateCardsPosition);
        }
    }, { passive: true });
}

// ==========================================
// Particles Effect
// ==========================================
function initParticles() {
    const heroParticles = document.querySelector('.hero-particles');
    
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!heroParticles || prefersReducedMotion) return;
    
    const particlesCount = window.innerWidth <= 768 ? 12 : 20;

    // Create floating particles
    for (let i = 0; i < particlesCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        // Random position
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        
        // Random size
        const size = Math.random() * 4 + 2;
        particle.style.width = size + 'px';
        particle.style.height = size + 'px';
        
        // Random animation duration
        const duration = Math.random() * 10 + 10;
        particle.style.animationDuration = duration + 's';
        
        // Random delay
        const delay = Math.random() * 5;
        particle.style.animationDelay = delay + 's';
        
        // Random opacity
        particle.style.opacity = Math.random() * 0.5 + 0.1;
        
        heroParticles.appendChild(particle);
    }
    
    // Add CSS for particles
    if (!document.getElementById('particle-styles')) {
        const style = document.createElement('style');
        style.id = 'particle-styles';
        style.textContent = `
            .particle {
                position: absolute;
                background: var(--caribbean-blue);
                border-radius: 50%;
                animation: floatParticle 15s infinite ease-in-out;
            }
            
            @keyframes floatParticle {
                0%, 100% {
                    transform: translate(0, 0);
                }
                25% {
                    transform: translate(20px, -30px);
                }
                50% {
                    transform: translate(-15px, -60px);
                }
                75% {
                    transform: translate(10px, -30px);
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// ==========================================
// Custom Cursor Effect (Desktop only)
// ==========================================
function initCursorEffect() {
    if (window.innerWidth <= 768 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return; // Skip on mobile or reduced motion
    
    const cursor = document.createElement('div');
    cursor.className = 'custom-cursor';
    document.body.appendChild(cursor);
    
    const cursorFollower = document.createElement('div');
    cursorFollower.className = 'cursor-follower';
    document.body.appendChild(cursorFollower);
    
    let mouseX = 0;
    let mouseY = 0;
    let followerX = 0;
    let followerY = 0;
    
    // Track mouse position
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        cursor.style.left = mouseX + 'px';
        cursor.style.top = mouseY + 'px';
    });
    
    // Smooth follower animation
    function animateFollower() {
        const dx = mouseX - followerX;
        const dy = mouseY - followerY;
        
        followerX += dx * 0.1;
        followerY += dy * 0.1;
        
        cursorFollower.style.left = followerX + 'px';
        cursorFollower.style.top = followerY + 'px';
        
        requestAnimationFrame(animateFollower);
    }
    
    animateFollower();
    
    // Hover effects
    const hoverElements = document.querySelectorAll('a, button, .btn, .portfolio-item, .service-card');
    
    hoverElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
            cursor.classList.add('hover');
            cursorFollower.classList.add('hover');
        });
        
        el.addEventListener('mouseleave', () => {
            cursor.classList.remove('hover');
            cursorFollower.classList.remove('hover');
        });
    });
    
    // Add cursor styles
    if (!document.getElementById('cursor-styles')) {
        const style = document.createElement('style');
        style.id = 'cursor-styles';
        style.textContent = `
            .custom-cursor,
            .cursor-follower {
                position: fixed;
                pointer-events: none;
                z-index: 9999;
                border-radius: 50%;
                transition: transform 0.2s ease;
            }
            
            .custom-cursor {
                width: 10px;
                height: 10px;
                background: var(--caribbean-blue);
                transform: translate(-50%, -50%);
            }
            
            .cursor-follower {
                width: 40px;
                height: 40px;
                border: 2px solid var(--caribbean-blue);
                transform: translate(-50%, -50%);
                opacity: 0.5;
            }
            
            .custom-cursor.hover {
                transform: translate(-50%, -50%) scale(0.5);
            }
            
            .cursor-follower.hover {
                transform: translate(-50%, -50%) scale(1.5);
                opacity: 0.3;
            }
            
            body {
                cursor: none;
            }
            
            a, button, .btn, .portfolio-item, .service-card {
                cursor: none;
            }
        `;
        document.head.appendChild(style);
    }
}

// ==========================================
// Text Typing Effect
// ==========================================
function typeText(element, text, speed = 50) {
    let i = 0;
    element.textContent = '';
    
    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// ==========================================
// Counter Animation
// ==========================================
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16); // 60fps
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Initialize counter animations when stats are visible
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const statNumber = entry.target.querySelector('.stat-number');
            const targetValue = parseInt(statNumber.textContent);
            
            if (!isNaN(targetValue)) {
                animateCounter(statNumber, targetValue);
            }
            
            statsObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

document.querySelectorAll('.stat-item').forEach(item => {
    statsObserver.observe(item);
});

// ==========================================
// Scroll Progress Bar
// ==========================================
function initScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    document.body.appendChild(progressBar);
    
    window.addEventListener('scroll', () => {
        const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (window.scrollY / windowHeight) * 100;
        progressBar.style.width = scrolled + '%';
    });
    
    // Add progress bar styles
    if (!document.getElementById('progress-styles')) {
        const style = document.createElement('style');
        style.id = 'progress-styles';
        style.textContent = `
            .scroll-progress {
                position: fixed;
                top: 0;
                left: 0;
                height: 3px;
                background: var(--gradient-primary);
                z-index: 9999;
                transition: width 0.1s ease;
            }
        `;
        document.head.appendChild(style);
    }
}

// Initialize scroll progress
initScrollProgress();

// ==========================================
// Image Lazy Loading Enhancement
// ==========================================
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[loading="lazy"]').forEach(img => {
        imageObserver.observe(img);
    });
}