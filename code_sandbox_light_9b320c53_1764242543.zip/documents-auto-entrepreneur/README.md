# 📁 Documents Auto-Entrepreneur - Mode d'emploi

## 🎯 Contenu de ce dossier

Ce dossier contient **tous les modèles de documents** nécessaires pour compléter ton dossier d'immatriculation auto-entrepreneur auprès de l'URSSAF.

---

## 📄 Fichiers disponibles

### **1. CHECKLIST-Documents-A-Reunir.md**
📋 **Guide complet** listant tous les documents à préparer selon ta situation
- Liste exhaustive par catégorie
- Explications détaillées
- Où trouver chaque document
- Délais et conseils pratiques

👉 **À LIRE EN PREMIER**

---

### **2. MODELE-Attestation-Non-Condamnation.txt**
📝 Attestation obligatoire certifiant que tu n'as pas de condamnation t'interdisant d'exercer

**Comment l'utiliser :**
1. Ouvrir le fichier `.txt`
2. Copier le contenu dans Word/LibreOffice
3. Remplir les champs `_______`
4. **Imprimer**
5. **Signer à la main**
6. Scanner en PDF

---

### **3. MODELE-Declaration-Sur-Honneur.txt**
📝 Déclaration générale certifiant l'exactitude de tes informations

**Comment l'utiliser :**
1. Ouvrir le fichier `.txt`
2. Copier dans Word/LibreOffice
3. Remplir tes informations
4. Cocher les cases appropriées (remplacer □ par ☑)
5. **Imprimer**
6. **Signer à la main**
7. Scanner en PDF

---

### **4. MODELE-Attestation-Hebergement.txt**
📝 Attestation à faire remplir si tu es hébergé(e) chez quelqu'un

**Qui doit la remplir ?**
La personne qui t'héberge (parent, conjoint, ami, etc.)

**Comment l'utiliser :**
1. Donner le modèle à ton hébergeur
2. Il/elle remplit et **signe à la main**
3. Joindre obligatoirement :
   - Sa pièce d'identité (copie)
   - Son justificatif de domicile récent

---

## ✅ Checklist rapide

### **Étape 1 : Identifier ta situation**
- [ ] Je suis locataire
- [ ] Je suis propriétaire
- [ ] Je suis hébergé(e)

### **Étape 2 : Ouvrir la CHECKLIST**
- [ ] Lire `CHECKLIST-Documents-A-Reunir.md`
- [ ] Cocher les documents que tu as déjà
- [ ] Noter ce qui manque

### **Étape 3 : Compléter les attestations**
- [ ] Imprimer les 3 modèles si nécessaire
- [ ] Remplir les informations
- [ ] **Signer à la main** (obligatoire !)
- [ ] Scanner en PDF

### **Étape 4 : Rassembler les pièces**
- [ ] CNI (recto/verso)
- [ ] Justificatif de domicile (< 3 mois)
- [ ] RIB bancaire
- [ ] Attestations signées

### **Étape 5 : Déposer le dossier**
- [ ] Aller sur [autoentrepreneur.urssaf.fr](https://www.autoentrepreneur.urssaf.fr)
- [ ] Créer un compte
- [ ] Remplir le formulaire P0
- [ ] Télécharger tous les documents

---

## 💡 Conseils pratiques

### **Format des fichiers**
- ✅ PDF uniquement
- ✅ Moins de 5 Mo par fichier
- ✅ Noms clairs : `CNI-recto.pdf`, `Attestation-non-condamnation.pdf`

### **Signatures**
- ⚠️ **MANUSCRITES OBLIGATOIRES** sur toutes les attestations
- ❌ Ne PAS utiliser de signature numérique/électronique pour l'URSSAF
- ✅ Signer au stylo, puis scanner

### **Qualité des scans**
- 300 DPI minimum
- Couleur (pour CNI)
- Bien lisible (pas de flou)

---

## 🚨 Erreurs à éviter

❌ Oublier de signer les attestations  
❌ Justificatif de domicile de plus de 3 mois  
❌ CNI expirée  
❌ Fichiers trop lourds (> 5 Mo)  
❌ Mauvaise qualité de scan (illisible)  
❌ Oublier la pièce d'identité de l'hébergeur si tu es hébergé  

---

## ⏱️ Temps nécessaire

| Tâche | Durée |
|-------|-------|
| Rassembler documents existants | 30 min |
| Remplir les 2-3 attestations | 15 min |
| Scanner et nommer les fichiers | 30 min |
| Compléter formulaire URSSAF | 30 min |
| **TOTAL** | **~2h** |

---

## 📞 Besoin d'aide ?

**URSSAF Auto-Entrepreneur :**
- ☎️ 3698 (service gratuit)
- 💬 Messagerie sur [autoentrepreneur.urssaf.fr](https://www.autoentrepreneur.urssaf.fr)

**Questions sur les documents :**
- Consulte `CHECKLIST-Documents-A-Reunir.md`
- Section FAQ à la fin du document

---

## 🎉 Après validation

Une fois ton dossier validé (7-15 jours) :

✅ Tu reçois ton **numéro SIRET** par email  
✅ Tu peux commencer à facturer  
✅ Tu dois déclarer ton CA mensuellement/trimestriellement  
✅ Tu peux adhérer à l'ACRE si éligible (50% de réduction charges 1ère année)  

---

**Bon courage pour ton inscription ! 🚀**

*Ces documents sont prêts à l'emploi et conformes aux exigences URSSAF 2024.*
