# 📋 CHECKLIST COMPLÈTE - Documents Auto-Entrepreneur

## ✅ Documents à préparer pour l'URSSAF

---

### 🆔 **1. PIÈCE D'IDENTITÉ** (OBLIGATOIRE)

**Options acceptées :**
- [ ] Carte Nationale d'Identité (CNI) - recto/verso
- [ ] Passeport français - page avec photo
- [ ] Titre de séjour en cours de validité (pour ressortissants étrangers)

**Format :** Copie couleur lisible, non expirée

**Où trouver :** Dans tes papiers personnels

---

### 🏠 **2. JUSTIFICATIF DE DOMICILE** (OBLIGATOIRE)

**Situations possibles :**

#### **CAS 1 : Tu es LOCATAIRE**
- [ ] Contrat de bail (toutes les pages)
- [ ] OU Quittance de loyer récente (moins de 3 mois)
- [ ] OU Attestation de loyer signée par le propriétaire

#### **CAS 2 : Tu es PROPRIÉTAIRE**
- [ ] Taxe foncière récente
- [ ] OU Acte de propriété
- [ ] OU Attestation notariale

#### **CAS 3 : Tu es HÉBERGÉ (chez parents/ami)**
- [ ] Attestation d'hébergement signée par l'hébergeur ([modèle disponible](https://www.service-public.fr/particuliers/vosdroits/R39697))
- [ ] + Justificatif de domicile de l'hébergeur (facture EDF, eau, gaz, internet)
- [ ] + Copie de la pièce d'identité de l'hébergeur

**Où trouver :**
- Tes emails (factures dématérialisées)
- Ton espace client EDF/Engie/Free/SFR
- Tes papiers administratifs

---

### 📄 **3. ATTESTATIONS SUR L'HONNEUR** (OBLIGATOIRES)

✅ **Documents créés - disponibles dans ce dossier :**

- [ ] **MODELE-Attestation-Non-Condamnation.txt**
  - À imprimer
  - Remplir à la main ou sur ordinateur
  - **SIGNER À LA MAIN obligatoirement**

- [ ] **MODELE-Declaration-Sur-Honneur.txt**
  - À imprimer
  - Remplir tes informations
  - Cocher les cases appropriées
  - **SIGNER À LA MAIN obligatoirement**

**Action :** Imprimer, remplir, signer, scanner

---

### 🏢 **4. JUSTIFICATIF DE JOUISSANCE DES LOCAUX**

**Si tu travailles DEPUIS CHEZ TOI :**
- [ ] Même document que le justificatif de domicile (point 2)
- [ ] + Autorisation du propriétaire si tu es locataire (lettre simple)

**Si tu as un LOCAL PROFESSIONNEL :**
- [ ] Contrat de bail commercial
- [ ] OU Convention de mise à disposition
- [ ] OU Contrat de domiciliation

**Si tu travailles en ITINÉRANT (sans local fixe) :**
- [ ] Déclaration sur l'honneur d'activité itinérante
- [ ] + Justificatif de domicile personnel

---

### 👨‍👩‍👦 **5. ATTESTATION DE FILIATION** (Optionnel)

- [ ] Copie intégrale de ton acte de naissance

**Où l'obtenir :**
- En ligne : [service-public.fr](https://www.service-public.fr/particuliers/vosdroits/R1406)
- À la mairie de ta ville de naissance
- Gratuit, délai 2-5 jours

**Note :** Rarement demandé pour l'auto-entrepreneur, mais utile si demandé

---

### 💳 **6. RIB (Relevé d'Identité Bancaire)** (OBLIGATOIRE)

- [ ] RIB à ton nom (compte personnel accepté au début)
- [ ] Recommandé : RIB d'un compte professionnel dédié

**Où trouver :**
- Application bancaire (section "RIB")
- Espace client en ligne de ta banque
- Demander à ton agence

---

### 🎓 **7. DIPLÔMES / QUALIFICATIONS** (Selon activité)

**Obligatoire uniquement si tu exerces :**
- [ ] Activité réglementée (coiffure, esthétique, BTP, etc.)
- [ ] Profession nécessitant un diplôme spécifique

**Exemples :**
- CAP/BEP pour artisans
- Diplôme d'expertise comptable
- Certificat de qualification professionnelle

**Pour WebCreation (développement web) :** ❌ **PAS OBLIGATOIRE**

---

## 📊 RÉCAPITULATIF PAR SITUATION

### **Situation Standard (locataire, sans activité réglementée) :**
```
✓ CNI recto/verso
✓ Quittance de loyer ou facture EDF (< 3 mois)
✓ RIB bancaire
✓ Attestation non-condamnation (signée)
✓ Déclaration sur l'honneur (signée)
```

### **Situation Hébergé chez parents :**
```
✓ CNI recto/verso
✓ Attestation d'hébergement signée par parent
✓ Facture EDF du parent (< 3 mois)
✓ Copie CNI du parent
✓ RIB bancaire
✓ Attestation non-condamnation (signée)
✓ Déclaration sur l'honneur (signée)
```

---

## 🎯 PROCHAINES ÉTAPES

### **Étape 1 : Rassembler les documents**
- [ ] Vérifier ce que tu as déjà
- [ ] Noter ce qui manque
- [ ] Commander acte de naissance si nécessaire

### **Étape 2 : Compléter les attestations**
- [ ] Imprimer les 2 modèles
- [ ] Remplir avec tes informations
- [ ] Signer à la main
- [ ] Scanner en PDF

### **Étape 3 : Numériser tout en PDF**
- [ ] Format PDF uniquement
- [ ] Fichiers < 5 Mo chacun
- [ ] Noms de fichiers clairs : `CNI-recto.pdf`, `Justificatif-domicile.pdf`, etc.

### **Étape 4 : Créer ton dossier**
- [ ] Aller sur [autoentrepreneur.urssaf.fr](https://www.autoentrepreneur.urssaf.fr)
- [ ] Créer ton compte
- [ ] Remplir le formulaire P0
- [ ] Télécharger tes documents scannés

---

## ⏱️ DÉLAIS

| Étape | Temps estimé |
|-------|--------------|
| Rassembler documents | 30 min - 2h |
| Compléter attestations | 15 min |
| Scanner tout en PDF | 30 min |
| Remplir formulaire URSSAF | 30 min |
| **TOTAL** | **2h - 3h15** |

---

## ❓ QUESTIONS FRÉQUENTES

**Q : Je n'ai pas de compte professionnel, mon RIB personnel suffit ?**
✅ Oui au début, mais ouvre-en un rapidement (Qonto, Shine, N26)

**Q : Mon justificatif de domicile est au nom de mon conjoint ?**
✅ OK si vous êtes mariés/pacsés + copie livret de famille

**Q : Je travaille depuis chez moi en location, besoin d'autorisation ?**
⚠️ Recommandé de demander par écrit au propriétaire (mais pas toujours vérifié)

**Q : Combien de temps pour validation du dossier ?**
⏱️ 7 à 15 jours après dépôt (tu reçois ton SIRET par email)

---

## 📞 AIDE

**URSSAF Auto-Entrepreneur :**
- 📞 3698 (service gratuit + prix appel)
- 💬 [autoentrepreneur.urssaf.fr](https://www.autoentrepreneur.urssaf.fr) (messagerie)

**Si blocage :** N'hésite pas à demander de l'aide ! 🚀
