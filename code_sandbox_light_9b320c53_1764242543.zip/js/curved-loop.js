/* ========================================
   CURVED LOOP - Vanilla JS Version
   Text Animation Component
   ======================================== */

class CurvedLoop {
  constructor(container, options = {}) {
    this.container = typeof container === 'string' 
      ? document.querySelector(container) 
      : container;
    
    if (!this.container) {
      console.warn('CurvedLoop: Container not found');
      return;
    }
    
    // Options
    this.text = options.text || 'WebCreation.pro';
    this.speed = options.speed || 2;
    this.curveAmount = options.curveAmount || 400;
    this.direction = options.direction || 'left';
    this.interactive = options.interactive !== false;
    this.gradient = options.gradient || false;
    this.className = options.className || '';
    
    // State
    this.spacing = 0;
    this.offset = 0;
    this.isDragging = false;
    this.lastX = 0;
    this.velocity = 0;
    this.animationFrame = null;
    
    // Generate unique ID
    this.id = 'curve-' + Math.random().toString(36).substr(2, 9);
    
    this.init();
  }
  
  init() {
    this.createSVG();
    this.measureText();
    this.setupEventListeners();
    this.startAnimation();
  }
  
  createSVG() {
    // Ensure text has trailing space
    const hasTrailing = /\s|\u00A0$/.test(this.text);
    this.displayText = (hasTrailing ? this.text.replace(/\s+$/, '') : this.text) + '\u00A0';
    
    // Create SVG structure - adjusted for smaller height
    const pathD = `M-100,40 Q720,${40 - this.curveAmount} 1540,40`;
    
    this.container.innerHTML = `
      <svg class="curved-loop-svg" viewBox="0 0 1440 80" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <path id="${this.id}" d="${pathD}" fill="none" stroke="transparent" />
          ${this.gradient ? `
            <linearGradient id="textGradient-${this.id}" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" style="stop-color:#0066FF;stop-opacity:1" />
              <stop offset="50%" style="stop-color:#F97316;stop-opacity:1" />
              <stop offset="100%" style="stop-color:#0066FF;stop-opacity:1" />
            </linearGradient>
          ` : ''}
        </defs>
        <text 
          id="measure-${this.id}" 
          class="curved-loop-text ${this.className}" 
          xml:space="preserve" 
          style="visibility: hidden; opacity: 0; pointer-events: none;"
        >
          ${this.displayText}
        </text>
        <text 
          id="display-${this.id}" 
          class="curved-loop-text ${this.className} ${this.gradient ? 'gradient' : ''}" 
          xml:space="preserve"
          style="visibility: hidden;"
        >
          <textPath 
            id="textpath-${this.id}" 
            href="#${this.id}" 
            startOffset="0" 
            xml:space="preserve"
          >
          </textPath>
        </text>
      </svg>
    `;
    
    // Store references
    this.svg = this.container.querySelector('.curved-loop-svg');
    this.measureText_el = this.container.querySelector(`#measure-${this.id}`);
    this.displayText_el = this.container.querySelector(`#display-${this.id}`);
    this.textPath = this.container.querySelector(`#textpath-${this.id}`);
  }
  
  measureText() {
    if (this.measureText_el) {
      // Wait for font to load
      setTimeout(() => {
        this.spacing = this.measureText_el.getComputedTextLength();
        if (this.spacing > 0) {
          this.setupText();
        }
      }, 100);
    }
  }
  
  setupText() {
    // Calculate how many repetitions needed
    const totalLength = 1800;
    const repetitions = Math.ceil(totalLength / this.spacing) + 2;
    const repeatedText = Array(repetitions).fill(this.displayText).join('');
    
    // Set initial offset
    this.offset = -this.spacing;
    
    // Update textPath
    if (this.textPath) {
      this.textPath.textContent = repeatedText;
      this.textPath.setAttribute('startOffset', this.offset + 'px');
      
      // Show the display text
      if (this.displayText_el) {
        this.displayText_el.style.visibility = 'visible';
      }
    }
  }
  
  setupEventListeners() {
    if (!this.interactive || !this.svg) return;
    
    this.svg.addEventListener('pointerdown', this.onPointerDown.bind(this));
    this.svg.addEventListener('pointermove', this.onPointerMove.bind(this));
    this.svg.addEventListener('pointerup', this.onPointerUp.bind(this));
    this.svg.addEventListener('pointerleave', this.onPointerUp.bind(this));
  }
  
  onPointerDown(e) {
    this.isDragging = true;
    this.lastX = e.clientX;
    this.velocity = 0;
    e.target.setPointerCapture(e.pointerId);
  }
  
  onPointerMove(e) {
    if (!this.isDragging || !this.textPath) return;
    
    const dx = e.clientX - this.lastX;
    this.lastX = e.clientX;
    this.velocity = dx;
    
    const currentOffset = parseFloat(this.textPath.getAttribute('startOffset') || '0');
    let newOffset = currentOffset + dx;
    
    // Wrap around
    const wrapPoint = this.spacing;
    if (newOffset <= -wrapPoint) newOffset += wrapPoint;
    if (newOffset > 0) newOffset -= wrapPoint;
    
    this.textPath.setAttribute('startOffset', newOffset + 'px');
    this.offset = newOffset;
  }
  
  onPointerUp() {
    if (!this.isDragging) return;
    this.isDragging = false;
    this.direction = this.velocity > 0 ? 'right' : 'left';
  }
  
  startAnimation() {
    if (!this.textPath || this.spacing === 0) {
      // Retry after a delay if not ready
      setTimeout(() => this.startAnimation(), 200);
      return;
    }
    
    const animate = () => {
      if (!this.isDragging && this.textPath) {
        const delta = this.direction === 'right' ? this.speed : -this.speed;
        const currentOffset = parseFloat(this.textPath.getAttribute('startOffset') || '0');
        let newOffset = currentOffset + delta;
        
        // Wrap around
        const wrapPoint = this.spacing;
        if (newOffset <= -wrapPoint) newOffset += wrapPoint;
        if (newOffset > 0) newOffset -= wrapPoint;
        
        this.textPath.setAttribute('startOffset', newOffset + 'px');
        this.offset = newOffset;
      }
      
      this.animationFrame = requestAnimationFrame(animate);
    };
    
    this.animationFrame = requestAnimationFrame(animate);
  }
  
  destroy() {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
    }
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
  
  // Update methods
  updateSpeed(speed) {
    this.speed = speed;
  }
  
  updateDirection(direction) {
    this.direction = direction;
  }
  
  updateText(text) {
    this.text = text;
    this.destroy();
    this.init();
  }
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CurvedLoop;
}

// Make available globally
window.CurvedLoop = CurvedLoop;
