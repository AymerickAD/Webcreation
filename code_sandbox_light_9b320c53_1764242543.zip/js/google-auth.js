// ==========================================
// Mad'ia - Google OAuth Integration
// ==========================================

// Variables globales pour Google OAuth
let googleUser = null;
let isGoogleLoaded = false;

// ==========================================
// Initialisation de Google OAuth
// ==========================================
function initGoogleAuth() {
    // Charger la librairie Google Identity Services
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = handleGoogleLibraryLoaded;
    script.onerror = () => {
        console.error('❌ Erreur lors du chargement de Google Identity Services');
        showAlert('Impossible de charger Google Sign-In. Veuillez réessayer.', 'error');
    };
    document.head.appendChild(script);
}

// ==========================================
// Callback après chargement de la librairie
// ==========================================
function handleGoogleLibraryLoaded() {
    isGoogleLoaded = true;
    console.log('✅ Google Identity Services chargé');
    
    // Vérifier que le Client ID est configuré
    if (!CONFIG.GOOGLE_CLIENT_ID || CONFIG.GOOGLE_CLIENT_ID === 'VOTRE_CLIENT_ID_ICI.apps.googleusercontent.com') {
        console.error('❌ Client ID Google non configuré !');
        console.log('📖 Consultez GOOGLE_OAUTH_SETUP.md pour configurer Google OAuth');
        return;
    }
    
    // Initialiser Google Identity Services
    google.accounts.id.initialize({
        client_id: CONFIG.GOOGLE_CLIENT_ID,
        callback: handleGoogleCallback,
        auto_select: false,
        cancel_on_tap_outside: true
    });
}

// ==========================================
// Callback après connexion Google
// ==========================================
function handleGoogleCallback(response) {
    console.log('🔐 Réponse Google reçue');
    
    try {
        // Décoder le JWT token
        const credential = response.credential;
        const payload = parseJwt(credential);
        
        console.log('✅ Utilisateur Google authentifié:', payload.email);
        
        // Créer l'objet utilisateur
        const userData = {
            email: payload.email,
            firstName: payload.given_name || payload.name.split(' ')[0],
            lastName: payload.family_name || payload.name.split(' ')[1] || '',
            fullName: payload.name,
            picture: payload.picture,
            googleId: payload.sub,
            loggedIn: true,
            loginMethod: 'google',
            loginTime: new Date().toISOString()
        };
        
        // Sauvegarder dans localStorage
        localStorage.setItem('madiaUser', JSON.stringify(userData));
        
        // Afficher message de succès
        showAlert(`Bienvenue ${userData.firstName} ! Redirection...`, 'success');
        
        // Rediriger vers le dashboard
        setTimeout(() => {
            window.location.href = CONFIG.REDIRECT_AFTER_LOGIN;
        }, 1500);
        
    } catch (error) {
        console.error('❌ Erreur lors du traitement de la réponse Google:', error);
        showAlert('Erreur lors de la connexion avec Google. Veuillez réessayer.', 'error');
    }
}

// ==========================================
// Décoder le JWT token
// ==========================================
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(
            atob(base64)
                .split('')
                .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
                .join('')
        );
        return JSON.parse(jsonPayload);
    } catch (error) {
        console.error('❌ Erreur lors du décodage du JWT:', error);
        throw error;
    }
}

// ==========================================
// Afficher le popup Google Sign-In
// ==========================================
function signInWithGoogle() {
    console.log('🔐 Tentative de connexion avec Google...');
    
    // Vérifier que Google est chargé
    if (!isGoogleLoaded) {
        showAlert('Google Sign-In n\'est pas encore chargé. Veuillez patienter...', 'warning');
        setTimeout(signInWithGoogle, 1000);
        return;
    }
    
    // Vérifier que le Client ID est configuré
    if (!CONFIG.GOOGLE_CLIENT_ID || CONFIG.GOOGLE_CLIENT_ID === 'VOTRE_CLIENT_ID_ICI.apps.googleusercontent.com') {
        showAlert(
            'Google Sign-In n\'est pas encore configuré. Consultez le fichier GOOGLE_OAUTH_SETUP.md pour obtenir votre Client ID.',
            'warning'
        );
        return;
    }
    
    try {
        // Afficher le popup de connexion Google
        google.accounts.id.prompt((notification) => {
            if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
                console.log('ℹ️ Popup Google non affiché, utilisation du bouton One Tap');
                // Si le popup ne s'affiche pas, on peut afficher un bouton alternatif
                renderGoogleButton();
            }
        });
    } catch (error) {
        console.error('❌ Erreur lors de l\'affichage du popup Google:', error);
        showAlert('Erreur lors de la connexion avec Google. Veuillez réessayer.', 'error');
    }
}

// ==========================================
// Render Google Sign-In Button (alternative)
// ==========================================
function renderGoogleButton() {
    const buttons = document.querySelectorAll('.btn-google');
    
    buttons.forEach(button => {
        // Créer un container pour le bouton Google
        const googleButtonContainer = document.createElement('div');
        googleButtonContainer.id = 'google-signin-button-' + Math.random().toString(36).substr(2, 9);
        
        // Remplacer le bouton par le container temporairement
        const parent = button.parentElement;
        parent.insertBefore(googleButtonContainer, button);
        button.style.display = 'none';
        
        // Render le bouton Google officiel
        try {
            google.accounts.id.renderButton(
                googleButtonContainer,
                {
                    theme: 'outline',
                    size: 'large',
                    width: button.offsetWidth,
                    text: 'continue_with',
                    shape: 'rectangular',
                    logo_alignment: 'left'
                }
            );
        } catch (error) {
            console.error('❌ Erreur lors du rendu du bouton Google:', error);
            // Réafficher le bouton personnalisé en cas d'erreur
            button.style.display = 'flex';
            googleButtonContainer.remove();
        }
    });
}

// ==========================================
// Déconnexion Google
// ==========================================
function signOutGoogle() {
    try {
        // Effacer les données utilisateur
        localStorage.removeItem('madiaUser');
        sessionStorage.removeItem('madiaUser');
        
        // Révoquer le token Google (si disponible)
        if (window.google && google.accounts && google.accounts.id) {
            google.accounts.id.disableAutoSelect();
        }
        
        googleUser = null;
        
        console.log('✅ Déconnexion Google réussie');
        showAlert('Déconnexion réussie', 'success');
        
        // Rediriger vers la page d'accueil
        setTimeout(() => {
            window.location.href = CONFIG.REDIRECT_AFTER_LOGOUT;
        }, 1000);
        
    } catch (error) {
        console.error('❌ Erreur lors de la déconnexion:', error);
        showAlert('Erreur lors de la déconnexion', 'error');
    }
}

// ==========================================
// Vérifier si l'utilisateur est connecté
// ==========================================
function isUserLoggedIn() {
    const userData = localStorage.getItem('madiaUser') || sessionStorage.getItem('madiaUser');
    return userData !== null;
}

// ==========================================
// Obtenir les données utilisateur
// ==========================================
function getCurrentUser() {
    const sessionData = sessionStorage.getItem('madiaUser');
    const localData = localStorage.getItem('madiaUser');
    
    if (sessionData) {
        return JSON.parse(sessionData);
    } else if (localData) {
        return JSON.parse(localData);
    }
    
    return null;
}

// ==========================================
// Initialisation automatique
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initialisation Google OAuth...');
    
    // Initialiser Google Auth
    initGoogleAuth();
    
    // Attacher les événements aux boutons Google
    setTimeout(() => {
        const googleButtons = document.querySelectorAll('.btn-google');
        googleButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                signInWithGoogle();
            });
        });
        
        console.log(`✅ ${googleButtons.length} bouton(s) Google configuré(s)`);
    }, 500);
});

// Export des fonctions pour utilisation globale
window.signInWithGoogle = signInWithGoogle;
window.signOutGoogle = signOutGoogle;
window.isUserLoggedIn = isUserLoggedIn;
window.getCurrentUser = getCurrentUser;