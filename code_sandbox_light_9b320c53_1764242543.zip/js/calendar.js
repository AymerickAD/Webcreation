// ==========================================
// Mad'ia - Google Calendar Booking Logic
// ==========================================

(function () {
    'use strict';

    const config = window.CONFIG || {};
    const bookingUrl = config.GOOGLE_CALENDAR_BOOKING_URL || '';
    const bookingButton = document.getElementById('bookWithGoogle');

    if (!bookingButton) {
        return;
    }

    const labelNode = bookingButton.querySelector('span');
    const iconNode = bookingButton.querySelector('i');
    const originalLabel = labelNode ? labelNode.textContent.trim() : bookingButton.textContent.trim();
    const originalIconClass = iconNode ? iconNode.className : '';

    const emitMessage = (message, type = 'info') => {
        if (typeof window.showAlert === 'function') {
            window.showAlert(message, type);
        } else {
            const logMethod = type === 'error' ? 'error' : type === 'warning' ? 'warn' : 'log';
            console[logMethod](`[Mad'ia] ${message}`);
        }
    };

    const disableBookingButton = (reasonMessage) => {
        bookingButton.disabled = true;
        bookingButton.setAttribute('aria-disabled', 'true');
        bookingButton.setAttribute('title', reasonMessage);
        emitMessage(reasonMessage, 'warning');
    };

    if (!config.GOOGLE_CLIENT_ID || config.GOOGLE_CLIENT_ID.includes('VOTRE_CLIENT_ID_ICI')) {
        disableBookingButton('Configurez votre Client ID Google OAuth dans js/config.js pour activer la prise de rendez-vous.');
        return;
    }

    if (!bookingUrl || bookingUrl.includes('YOUR_SCHEDULE_ID')) {
        disableBookingButton('Ajoutez l\'URL "Publier" de votre planning Google Calendar dans js/config.js.');
        return;
    }

    let tokenClient = null;
    let accessToken = null;

    const setLoadingState = (isLoading) => {
        if (isLoading) {
            bookingButton.disabled = true;
            bookingButton.setAttribute('aria-busy', 'true');
            bookingButton.classList.add('is-loading');
            if (labelNode) {
                bookingButton.dataset.originalLabel = originalLabel;
                labelNode.textContent = 'Connexion...';
            }
            if (iconNode) {
                bookingButton.dataset.originalIcon = originalIconClass;
                iconNode.className = 'fas fa-circle-notch fa-spin';
            }
        } else {
            bookingButton.disabled = false;
            bookingButton.removeAttribute('aria-busy');
            bookingButton.classList.remove('is-loading');
            if (labelNode && bookingButton.dataset.originalLabel) {
                labelNode.textContent = bookingButton.dataset.originalLabel;
            }
            if (iconNode && bookingButton.dataset.originalIcon) {
                iconNode.className = bookingButton.dataset.originalIcon;
            }
        }
    };

    const handleTokenResponse = (tokenResponse) => {
        if (!tokenResponse || tokenResponse.error || !tokenResponse.access_token) {
            setLoadingState(false);
            console.error('Mad\'ia · Google Calendar', tokenResponse);
            emitMessage('Impossible de se connecter à Google. Veuillez réessayer.', 'error');
            return;
        }

        accessToken = tokenResponse.access_token;
        setLoadingState(false);

        // Rediriger l'utilisateur vers la page officielle de prise de rendez-vous Google Calendar.
        window.location.assign(bookingUrl);
    };

    const ensureTokenClient = () => {
        if (tokenClient) {
            return tokenClient;
        }

        if (!window.google || !google.accounts || !google.accounts.oauth2) {
            emitMessage('Les scripts Google ne sont pas disponibles. Vérifiez que rien ne bloque https://accounts.google.com.', 'error');
            return null;
        }

        tokenClient = google.accounts.oauth2.initTokenClient({
            client_id: config.GOOGLE_CLIENT_ID,
            scope: config.GOOGLE_SCOPES,
            callback: handleTokenResponse
        });

        return tokenClient;
    };

    const requestAccessToken = () => {
        const client = ensureTokenClient();

        if (!client) {
            setLoadingState(false);
            return;
        }

        try {
            client.callback = handleTokenResponse;
            client.requestAccessToken({
                prompt: accessToken ? '' : 'consent'
            });
        } catch (error) {
            setLoadingState(false);
            console.error('Mad\'ia · Google Calendar - requestAccessToken', error);
            emitMessage('Impossible d\'ouvrir la fenêtre de connexion Google.', 'error');
        }
    };

    bookingButton.addEventListener('click', (event) => {
        event.preventDefault();

        if (!navigator.onLine) {
            emitMessage('Connexion Internet requise pour accéder à Google Calendar.', 'warning');
            return;
        }

        setLoadingState(true);
        requestAccessToken();
    });
})();
