/**
 * WebCreation - Blog Manager
 * Gestion de l'affichage des articles, navigation, SEO
 */

class BlogManager {
    constructor() {
        this.articles = [];
        this.currentArticle = null;
        this.init();
    }

    async init() {
        // Charger tous les articles
        await this.loadArticles();
        
        // Vérifier si on est sur une page d'article
        const urlParams = new URLSearchParams(window.location.search);
        const articleSlug = urlParams.get('article');
        
        if (articleSlug) {
            this.displayArticlePage(articleSlug);
        } else {
            this.displayBlogSection();
        }
    }

    async loadArticles() {
        // Fusionner tous les articles des 3 fichiers
        this.articles = [
            ...(typeof blogArticles !== 'undefined' ? blogArticles : []),
            ...(typeof blogArticlesPart2 !== 'undefined' ? blogArticlesPart2 : []),
            ...(typeof blogArticlesPart3 !== 'undefined' ? blogArticlesPart3 : [])
        ];
        
        console.log(`📚 ${this.articles.length} articles chargés`);
    }

    displayBlogSection() {
        // Vérifier si la section blog existe déjà
        let blogSection = document.getElementById('blog');
        
        if (!blogSection) {
            // Créer la section blog et l'insérer après la section portfolio
            blogSection = document.createElement('section');
            blogSection.id = 'blog';
            blogSection.className = 'blog-section';
            
            const portfolioSection = document.getElementById('portfolio');
            if (portfolioSection) {
                portfolioSection.parentNode.insertBefore(blogSection, portfolioSection.nextSibling);
            } else {
                // Insérer avant le footer si pas de portfolio
                const footer = document.querySelector('footer');
                footer.parentNode.insertBefore(blogSection, footer);
            }
        }

        // Construire le HTML de la section blog
        blogSection.innerHTML = this.getBlogSectionHTML();
        
        // Ajouter les event listeners
        this.attachEventListeners();
    }

    getBlogSectionHTML() {
        return `
            <div class="container">
                <div class="blog-header reveal-element">
                    <div class="blog-badge">📚 Blog & Ressources</div>
                    <h2 class="blog-title">Guides & Conseils Web</h2>
                    <p class="blog-description">
                        Découvrez nos articles d'experts sur la création web, la cybersécurité, 
                        le SEO et toutes les tendances digitales 2024.
                    </p>
                </div>

                <div class="blog-grid">
                    ${this.articles.map((article, index) => this.getArticleCardHTML(article, index === 0)).join('')}
                </div>

                <div class="blog-cta">
                    <a href="#contact" class="blog-cta-btn magnetic-btn">
                        Besoin d'accompagnement ?
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        `;
    }

    getArticleCardHTML(article, isFeatured = false) {
        const featuredClass = (isFeatured && article.featured) ? 'featured' : '';
        
        return `
            <article class="article-card ${featuredClass} reveal-element" data-article-id="${article.id}">
                <div class="article-image">
                    <img src="${article.image}" alt="${article.title}" loading="lazy">
                    <div class="article-category">${article.category}</div>
                    <div class="article-reading-time">
                        <i class="far fa-clock"></i>
                        ${article.readingTime}
                    </div>
                </div>
                
                <div class="article-content">
                    <div class="article-meta">
                        <div class="article-date">
                            <i class="far fa-calendar"></i>
                            ${this.formatDate(article.date)}
                        </div>
                        <span>·</span>
                        <span>${article.author}</span>
                    </div>
                    
                    <h3 class="article-title-card">${article.title}</h3>
                    <p class="article-excerpt">${article.excerpt}</p>
                    
                    <div class="article-tags">
                        ${article.tags.slice(0, 3).map(tag => `
                            <span class="article-tag">${tag}</span>
                        `).join('')}
                    </div>
                    
                    <div class="article-footer">
                        <a href="?article=${article.slug}" class="article-cta">
                            Lire l'article
                            <i class="fas fa-arrow-right"></i>
                        </a>
                        <div class="article-stats">
                            <div class="article-stat">
                                <i class="far fa-eye"></i>
                                ${this.getRandomViews()}
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        `;
    }

    displayArticlePage(slug) {
        const article = this.articles.find(a => a.slug === slug);
        
        if (!article) {
            console.error(`Article introuvable : ${slug}`);
            return;
        }

        this.currentArticle = article;
        
        // Mettre à jour les meta tags SEO
        this.updateSEOTags(article);
        
        // Créer la page article complète
        const articlePageHTML = `
            <section class="article-page" id="article-${article.id}">
                <div class="container">
                    <!-- Breadcrumb -->
                    <nav class="breadcrumb" aria-label="breadcrumb">
                        <a href="/">Accueil</a>
                        <span>/</span>
                        <a href="/?#blog">Blog</a>
                        <span>/</span>
                        <span>${article.category}</span>
                    </nav>

                    <!-- Article Header -->
                    <header class="article-header">
                        <div class="article-category-badge">${article.category}</div>
                        <h1 class="article-title-main">${article.title}</h1>
                        
                        <div class="article-meta-main">
                            <div class="meta-item">
                                <i class="far fa-calendar"></i>
                                <span>${this.formatDate(article.date)}</span>
                            </div>
                            <div class="meta-item">
                                <i class="far fa-clock"></i>
                                <span>${article.readingTime} de lecture</span>
                            </div>
                            <div class="meta-item">
                                <i class="far fa-user"></i>
                                <span>${article.author}</span>
                            </div>
                        </div>

                        <div class="article-image-main">
                            <img src="${article.image}" alt="${article.title}" loading="eager">
                        </div>
                    </header>

                    <!-- Article Content -->
                    <article class="article-body">
                        ${article.content}
                    </article>

                    <!-- Article Footer -->
                    <footer class="article-footer-main">
                        <div class="article-tags-main">
                            ${article.tags.map(tag => `
                                <span class="article-tag-main">#${tag}</span>
                            `).join('')}
                        </div>

                        <div class="article-share">
                            <h3>Partager cet article</h3>
                            <div class="share-buttons">
                                <a href="https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(window.location.href)}" 
                                   target="_blank" 
                                   class="share-btn twitter"
                                   aria-label="Partager sur Twitter">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}" 
                                   target="_blank" 
                                   class="share-btn linkedin"
                                   aria-label="Partager sur LinkedIn">
                                    <i class="fab fa-linkedin"></i>
                                </a>
                                <a href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}" 
                                   target="_blank" 
                                   class="share-btn facebook"
                                   aria-label="Partager sur Facebook">
                                    <i class="fab fa-facebook"></i>
                                </a>
                                <button onclick="navigator.clipboard.writeText('${window.location.href}'); alert('Lien copié !')" 
                                        class="share-btn copy"
                                        aria-label="Copier le lien">
                                    <i class="fas fa-link"></i>
                                </button>
                            </div>
                        </div>
                    </footer>

                    <!-- Articles connexes -->
                    <section class="related-articles">
                        <h2>Articles connexes</h2>
                        <div class="related-grid">
                            ${this.getRelatedArticles(article).map(relatedArticle => `
                                <article class="related-card">
                                    <div class="related-image">
                                        <img src="${relatedArticle.image}" alt="${relatedArticle.title}" loading="lazy">
                                        <div class="related-category">${relatedArticle.category}</div>
                                    </div>
                                    <div class="related-content">
                                        <h3>${relatedArticle.title}</h3>
                                        <p>${relatedArticle.excerpt.substring(0, 120)}...</p>
                                        <a href="?article=${relatedArticle.slug}" class="related-link">
                                            Lire l'article <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </article>
                            `).join('')}
                        </div>
                    </section>

                    <!-- CTA -->
                    <div class="article-cta-box">
                        <h2>🚀 Besoin d'accompagnement pour votre projet web ?</h2>
                        <p>Notre équipe d'experts est à votre écoute pour transformer vos idées en réalité digitale.</p>
                        <a href="#contact" class="btn-primary btn-large magnetic-btn">
                            Parlons de votre projet
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>

                    <!-- Retour blog -->
                    <div class="back-to-blog">
                        <a href="/?#blog" class="back-link">
                            <i class="fas fa-arrow-left"></i>
                            Retour au blog
                        </a>
                    </div>
                </div>
            </section>
        `;

        // Insérer la page article après le header
        const header = document.querySelector('header');
        const articleSection = document.createElement('div');
        articleSection.innerHTML = articlePageHTML;
        header.parentNode.insertBefore(articleSection.firstElementChild, header.nextSibling);

        // Masquer les autres sections
        this.hideOtherSections();
        
        // Scroller en haut
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    hideOtherSections() {
        const sectionsToHide = ['hero', 'trusted', 'services', 'portfolio', 'blog', 'contact'];
        sectionsToHide.forEach(sectionId => {
            const section = document.getElementById(sectionId);
            if (section) {
                section.style.display = 'none';
            }
        });
    }

    getRelatedArticles(currentArticle) {
        // Trouver 3 articles de la même catégorie ou avec tags similaires
        const related = this.articles
            .filter(article => 
                article.id !== currentArticle.id && 
                (article.category === currentArticle.category || 
                 article.tags.some(tag => currentArticle.tags.includes(tag)))
            )
            .slice(0, 3);

        // Si moins de 3, compléter avec d'autres articles
        if (related.length < 3) {
            const remaining = this.articles
                .filter(article => 
                    article.id !== currentArticle.id && 
                    !related.includes(article)
                )
                .slice(0, 3 - related.length);
            
            related.push(...remaining);
        }

        return related;
    }

    updateSEOTags(article) {
        // Title
        document.title = article.seo.metaTitle;
        
        // Meta description
        let metaDesc = document.querySelector('meta[name="description"]');
        if (!metaDesc) {
            metaDesc = document.createElement('meta');
            metaDesc.name = 'description';
            document.head.appendChild(metaDesc);
        }
        metaDesc.content = article.seo.metaDescription;

        // Meta keywords
        let metaKeywords = document.querySelector('meta[name="keywords"]');
        if (!metaKeywords) {
            metaKeywords = document.createElement('meta');
            metaKeywords.name = 'keywords';
            document.head.appendChild(metaKeywords);
        }
        metaKeywords.content = article.seo.keywords.join(', ');

        // Open Graph tags
        this.updateOGTag('og:title', article.title);
        this.updateOGTag('og:description', article.seo.metaDescription);
        this.updateOGTag('og:image', article.image);
        this.updateOGTag('og:url', window.location.href);
        this.updateOGTag('og:type', 'article');

        // Twitter Card
        this.updateOGTag('twitter:card', 'summary_large_image');
        this.updateOGTag('twitter:title', article.title);
        this.updateOGTag('twitter:description', article.seo.metaDescription);
        this.updateOGTag('twitter:image', article.image);

        // Schema.org JSON-LD
        this.addArticleSchema(article);
    }

    updateOGTag(property, content) {
        let tag = document.querySelector(`meta[property="${property}"]`);
        if (!tag) {
            tag = document.createElement('meta');
            tag.setAttribute('property', property);
            document.head.appendChild(tag);
        }
        tag.content = content;
    }

    addArticleSchema(article) {
        // Supprimer ancien schema si existe
        const oldSchema = document.getElementById('article-schema');
        if (oldSchema) oldSchema.remove();

        const schema = {
            "@context": "https://schema.org",
            "@type": "Article",
            "headline": article.title,
            "description": article.excerpt,
            "image": article.image,
            "datePublished": article.date,
            "author": {
                "@type": "Organization",
                "name": article.author
            },
            "publisher": {
                "@type": "Organization",
                "name": "WebCreation",
                "logo": {
                    "@type": "ImageObject",
                    "url": "https://votresite.fr/images/logo.png"
                }
            },
            "mainEntityOfPage": {
                "@type": "WebPage",
                "@id": window.location.href
            }
        };

        const script = document.createElement('script');
        script.id = 'article-schema';
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(schema);
        document.head.appendChild(script);
    }

    attachEventListeners() {
        // Event listeners pour les cartes d'articles
        document.querySelectorAll('.article-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (e.target.closest('.article-cta')) {
                    return; // Laisser le lien fonctionner
                }
                const articleId = card.dataset.articleId;
                const article = this.articles.find(a => a.id === articleId);
                if (article) {
                    window.location.href = `?article=${article.slug}`;
                }
            });
        });
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('fr-FR', options);
    }

    getRandomViews() {
        // Générer un nombre aléatoire de vues (pour l'exemple)
        return Math.floor(Math.random() * (2000 - 300) + 300);
    }
}

// Initialiser le blog manager au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
    const blogManager = new BlogManager();
    
    // Exposer globalement pour debug
    window.blogManager = blogManager;
});
