/**
 * WEBCREATION.PRO - REFONTE V5.0
 * Main JavaScript - Animations, Navigation, Form Handling
 */

// ============================================
// 1. NAVIGATION
// ============================================

const header = document.getElementById('header');
const navToggle = document.getElementById('nav-toggle');
const navMenu = document.getElementById('nav-menu');
const navLinks = document.querySelectorAll('.nav-link');

// Toggle Mobile Menu
if (navToggle) {
  navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    const icon = navToggle.querySelector('i');
    icon.classList.toggle('fa-bars');
    icon.classList.toggle('fa-times');
  });
}

// Close menu when clicking on a link
navLinks.forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('active');
    const icon = navToggle?.querySelector('i');
    if (icon) {
      icon.classList.add('fa-bars');
      icon.classList.remove('fa-times');
    }
  });
});

// Sticky Header on Scroll
window.addEventListener('scroll', () => {
  if (window.scrollY > 100) {
    header.classList.add('header-scrolled');
  } else {
    header.classList.remove('header-scrolled');
  }
});

// ============================================
// 2. SCROLL ANIMATIONS
// ============================================

const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

// Observe all reveal elements
document.addEventListener('DOMContentLoaded', () => {
  const revealElements = document.querySelectorAll(
    '.reveal-fade-up, .reveal-fade-right, .reveal-fade-left, .reveal-scale'
  );
  
  revealElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    observer.observe(el);
  });
});

// ============================================
// 3. SMOOTH SCROLL
// ============================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const href = this.getAttribute('href');
    
    // Skip if href is just "#"
    if (href === '#') {
      e.preventDefault();
      return;
    }
    
    const target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      const headerOffset = 80;
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  });
});

// ============================================
// 4. FORM HANDLING
// ============================================

const contactForm = document.getElementById('contact-form');

if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitBtn = contactForm.querySelector('.btn-primary');
    const originalText = submitBtn.innerHTML;
    
    // Show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Envoi en cours...</span>';
    
    // Get form data
    const formData = new FormData(contactForm);
    const data = Object.fromEntries(formData);
    
    // Simulate form submission (replace with actual API call)
    try {
      await simulateFormSubmission(data);
      
      // Success
      submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> <span>Message envoyé !</span>';
      submitBtn.style.backgroundColor = 'var(--success)';
      
      // Reset form after 3 seconds
      setTimeout(() => {
        contactForm.reset();
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        submitBtn.style.backgroundColor = '';
      }, 3000);
      
    } catch (error) {
      // Error
      submitBtn.innerHTML = '<i class="fas fa-exclamation-circle"></i> <span>Erreur, réessayez</span>';
      submitBtn.style.backgroundColor = 'var(--error)';
      
      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        submitBtn.style.backgroundColor = '';
      }, 3000);
    }
  });
}

// Simulate form submission
function simulateFormSubmission(data) {
  return new Promise((resolve, reject) => {
    console.log('Form data:', data);
    
    // Simulate network delay
    setTimeout(() => {
      // 90% success rate for demo
      if (Math.random() > 0.1) {
        resolve({ success: true });
      } else {
        reject({ error: 'Network error' });
      }
    }, 2000);
  });
}

// ============================================
// 5. ANIMATED COUNTERS
// ============================================

function animateCounter(element, target, duration = 2000) {
  const start = 0;
  const increment = target / (duration / 16); // 60fps
  let current = start;
  
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      element.textContent = target;
      clearInterval(timer);
    } else {
      element.textContent = Math.floor(current);
    }
  }, 16);
}

// Trigger counters when visible
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !entry.target.dataset.animated) {
      const target = parseInt(entry.target.dataset.target);
      animateCounter(entry.target, target);
      entry.target.dataset.animated = 'true';
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('[data-counter]').forEach(counter => {
  counterObserver.observe(counter);
});

// ============================================
// 6. PARALLAX EFFECT
// ============================================

window.addEventListener('scroll', () => {
  const scrolled = window.pageYOffset;
  const parallaxElements = document.querySelectorAll('[data-parallax]');
  
  parallaxElements.forEach(element => {
    const speed = element.dataset.parallax || 0.5;
    const yPos = -(scrolled * speed);
    element.style.transform = `translateY(${yPos}px)`;
  });
});

// ============================================
// 7. COPY TO CLIPBOARD
// ============================================

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showNotification('Copié dans le presse-papiers !', 'success');
  }).catch(err => {
    console.error('Failed to copy:', err);
    showNotification('Erreur lors de la copie', 'error');
  });
}

// ============================================
// 8. NOTIFICATIONS
// ============================================

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
    <span>${message}</span>
  `;
  
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 20px;
    padding: 16px 24px;
    background-color: ${type === 'success' ? 'var(--success)' : type === 'error' ? 'var(--error)' : 'var(--info)'};
    color: white;
    border-radius: 12px;
    box-shadow: var(--shadow-xl);
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    z-index: 10000;
    animation: slideInRight 0.3s ease;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOutRight 0.3s ease';
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// Add notification animations
const style = document.createElement('style');
style.textContent = `
  @keyframes slideInRight {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOutRight {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
  
  .header-scrolled {
    box-shadow: var(--shadow-lg);
    background-color: rgba(255, 255, 255, 0.98);
  }
`;
document.head.appendChild(style);

// ============================================
// 9. LAZY LOADING IMAGES
// ============================================

if ('IntersectionObserver' in window) {
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.classList.add('loaded');
        observer.unobserve(img);
      }
    });
  });

  document.querySelectorAll('img[data-src]').forEach(img => {
    imageObserver.observe(img);
  });
}

// ============================================
// 10. KEYBOARD NAVIGATION
// ============================================

document.addEventListener('keydown', (e) => {
  // Close mobile menu with Escape key
  if (e.key === 'Escape' && navMenu.classList.contains('active')) {
    navMenu.classList.remove('active');
    const icon = navToggle?.querySelector('i');
    if (icon) {
      icon.classList.add('fa-bars');
      icon.classList.remove('fa-times');
    }
  }
});

// ============================================
// 11. PERFORMANCE MONITORING
// ============================================

if ('PerformanceObserver' in window) {
  try {
    const perfObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'largest-contentful-paint') {
          console.log('LCP:', entry.renderTime || entry.loadTime);
        }
      }
    });
    perfObserver.observe({ entryTypes: ['largest-contentful-paint'] });
  } catch (e) {
    // PerformanceObserver not supported
  }
}

// ============================================
// 12. ANALYTICS (Ready for integration)
// ============================================

function trackEvent(category, action, label) {
  // Ready for Google Analytics integration
  if (typeof gtag !== 'undefined') {
    gtag('event', action, {
      'event_category': category,
      'event_label': label
    });
  }
  console.log('Event tracked:', { category, action, label });
}

// Track CTA clicks
document.querySelectorAll('.btn-primary, .btn-secondary').forEach(btn => {
  btn.addEventListener('click', () => {
    const text = btn.textContent.trim();
    trackEvent('CTA', 'click', text);
  });
});

// Track form submissions
if (contactForm) {
  contactForm.addEventListener('submit', () => {
    trackEvent('Form', 'submit', 'Contact Form');
  });
}

// ============================================
// 13. ACCESSIBILITY ENHANCEMENTS
// ============================================

// Add skip to main content link
const skipLink = document.createElement('a');
skipLink.href = '#main';
skipLink.className = 'skip-link';
skipLink.textContent = 'Passer au contenu principal';
skipLink.style.cssText = `
  position: absolute;
  top: -40px;
  left: 0;
  background-color: var(--primary-600);
  color: white;
  padding: 8px 16px;
  text-decoration: none;
  z-index: 100000;
`;
skipLink.addEventListener('focus', () => {
  skipLink.style.top = '0';
});
skipLink.addEventListener('blur', () => {
  skipLink.style.top = '-40px';
});
document.body.insertBefore(skipLink, document.body.firstChild);

// Announce dynamic content changes to screen readers
function announceToScreenReader(message) {
  const announcement = document.createElement('div');
  announcement.setAttribute('role', 'status');
  announcement.setAttribute('aria-live', 'polite');
  announcement.className = 'sr-only';
  announcement.textContent = message;
  document.body.appendChild(announcement);
  
  setTimeout(() => {
    announcement.remove();
  }, 1000);
}

// ============================================
// 14. CONSOLE BRANDING
// ============================================

console.log(
  '%cWebcreation.pro',
  'font-size: 24px; font-weight: bold; color: #0A2463;'
);
console.log(
  '%cSites web performants. Sécurisés. Garantis.',
  'font-size: 14px; color: #F97316;'
);
console.log(
  '%c💼 Vous cherchez un développeur ? contact@webcreation.pro',
  'font-size: 12px; color: #666;'
);

// ============================================
// INITIALIZATION COMPLETE
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  console.log('✅ Webcreation.pro loaded successfully');
});