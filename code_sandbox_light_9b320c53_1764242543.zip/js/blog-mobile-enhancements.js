/**
 * WebCreation - Blog Mobile Enhancements
 * Améliorations d'interactivité et de performance mobile pour la section blog
 */

(function() {
    'use strict';
    
    // Détection mobile
    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    
    // ===================================
    // 1. LAZY LOADING IMAGES OPTIMISÉ
    // ===================================
    
    function initLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        
                        // Ajouter classe de chargement
                        const parent = img.closest('.article-image');
                        if (parent) {
                            parent.setAttribute('data-loading', 'true');
                        }
                        
                        // Charger l'image
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                        }
                        
                        img.onload = () => {
                            img.classList.add('loaded');
                            if (parent) {
                                parent.removeAttribute('data-loading');
                            }
                        };
                        
                        observer.unobserve(img);
                    }
                });
            }, {
                rootMargin: '50px' // Charger 50px avant d'être visible
            });
            
            // Observer toutes les images lazy
            document.querySelectorAll('img[loading="lazy"]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    }
    
    // ===================================
    // 2. TOUCH FEEDBACK SUR CARDS
    // ===================================
    
    function initTouchFeedback() {
        if (!isTouchDevice) return;
        
        const cards = document.querySelectorAll('.article-card');
        
        cards.forEach(card => {
            // Touch start
            card.addEventListener('touchstart', function() {
                this.style.transform = 'scale(0.98)';
                this.style.transition = 'transform 0.1s ease';
            }, { passive: true });
            
            // Touch end
            card.addEventListener('touchend', function() {
                this.style.transform = '';
                this.style.transition = 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)';
            }, { passive: true });
            
            // Touch cancel
            card.addEventListener('touchcancel', function() {
                this.style.transform = '';
            }, { passive: true });
        });
    }
    
    // ===================================
    // 3. TRUNCATE TEXT AVEC "LIRE PLUS"
    // ===================================
    
    function initReadMore() {
        if (!isMobile) return;
        
        const excerpts = document.querySelectorAll('.article-excerpt');
        
        excerpts.forEach(excerpt => {
            const text = excerpt.textContent;
            const maxLength = 120; // Caractères max sur mobile
            
            if (text.length > maxLength) {
                const truncated = text.substring(0, maxLength) + '...';
                excerpt.textContent = truncated;
                
                // Stocker le texte complet
                excerpt.dataset.fullText = text;
                excerpt.dataset.truncated = 'true';
            }
        });
    }
    
    // ===================================
    // 4. SMOOTH SCROLL POUR ANCRES
    // ===================================
    
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href === '#' || href === '#!') return;
                
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    
                    const offsetTop = target.offsetTop - 80; // Offset pour navbar
                    
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }
    
    // ===================================
    // 5. INDICATEUR DE LECTURE
    // ===================================
    
    function initReadingProgress() {
        const progressBar = document.createElement('div');
        progressBar.id = 'reading-progress';
        progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(90deg, #0066FF 0%, #00A3FF 100%);
            z-index: 9999;
            transition: width 0.1s ease;
        `;
        document.body.appendChild(progressBar);
        
        // Mettre à jour la progression
        function updateProgress() {
            const windowHeight = window.innerHeight;
            const documentHeight = document.documentElement.scrollHeight - windowHeight;
            const scrolled = window.scrollY;
            const progress = (scrolled / documentHeight) * 100;
            
            progressBar.style.width = Math.min(progress, 100) + '%';
        }
        
        window.addEventListener('scroll', updateProgress, { passive: true });
        updateProgress(); // Init
    }
    
    // ===================================
    // 6. SWIPE ENTRE ARTICLES (Mobile)
    // ===================================
    
    function initSwipeNavigation() {
        if (!isMobile || !isTouchDevice) return;
        
        let touchStartX = 0;
        let touchEndX = 0;
        
        document.addEventListener('touchstart', e => {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        document.addEventListener('touchend', e => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, { passive: true });
        
        function handleSwipe() {
            const swipeThreshold = 100; // pixels
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) < swipeThreshold) return;
            
            // Swipe gauche (article suivant)
            if (diff > 0) {
                const nextLink = document.querySelector('[rel="next"]');
                if (nextLink) {
                    window.location.href = nextLink.href;
                }
            }
            // Swipe droite (article précédent)
            else {
                const prevLink = document.querySelector('[rel="prev"]');
                if (prevLink) {
                    window.location.href = prevLink.href;
                }
            }
        }
    }
    
    // ===================================
    // 7. AMÉLIORER PERFORMANCE SCROLL
    // ===================================
    
    function optimizeScrollPerformance() {
        let ticking = false;
        
        window.addEventListener('scroll', () => {
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    // Logique de scroll ici si nécessaire
                    ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });
    }
    
    // ===================================
    // 8. ORIENTATION CHANGE HANDLER
    // ===================================
    
    function handleOrientationChange() {
        window.addEventListener('orientationchange', () => {
            // Recalculer layouts après rotation
            setTimeout(() => {
                window.dispatchEvent(new Event('resize'));
            }, 300);
        });
    }
    
    // ===================================
    // 9. CACHE IMAGES POUR NAVIGATION RAPIDE
    // ===================================
    
    function prefetchRelatedArticles() {
        if (!isMobile) return;
        
        // Prefetch images des articles similaires
        const relatedImages = document.querySelectorAll('.related-articles img');
        
        relatedImages.forEach(img => {
            const link = document.createElement('link');
            link.rel = 'prefetch';
            link.href = img.src;
            document.head.appendChild(link);
        });
    }
    
    // ===================================
    // 10. FEEDBACK VISUEL CHARGEMENT
    // ===================================
    
    function initLoadingFeedback() {
        // Ajouter feedback lors des clics sur liens
        document.querySelectorAll('.article-link, .article-card').forEach(element => {
            element.addEventListener('click', function(e) {
                // Vérifier si c'est un vrai lien
                const link = this.querySelector('a[href]') || this;
                if (link.href && !link.href.includes('#')) {
                    // Ajouter classe de chargement
                    this.style.opacity = '0.6';
                    this.style.pointerEvents = 'none';
                }
            });
        });
    }
    
    // ===================================
    // 11. OPTIMISER ANIMATIONS MOBILE
    // ===================================
    
    function optimizeAnimations() {
        if (!isMobile) return;
        
        // Désactiver animations complexes sur mobile pour performance
        const style = document.createElement('style');
        style.textContent = `
            @media (max-width: 768px) {
                * {
                    animation-duration: 0.3s !important;
                    transition-duration: 0.3s !important;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // ===================================
    // 12. COPY LINK FUNCTIONALITY
    // ===================================
    
    function initCopyLink() {
        const shareButtons = document.querySelectorAll('.article-share-btn');
        
        shareButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Si c'est le bouton de copie (à ajouter dans HTML)
                if (this.classList.contains('copy-link')) {
                    e.preventDefault();
                    
                    const url = window.location.href;
                    
                    if (navigator.clipboard) {
                        navigator.clipboard.writeText(url).then(() => {
                            // Feedback visuel
                            const originalText = this.innerHTML;
                            this.innerHTML = '<i class="fas fa-check"></i> Copié !';
                            this.style.background = '#10B981';
                            
                            setTimeout(() => {
                                this.innerHTML = originalText;
                                this.style.background = '';
                            }, 2000);
                        });
                    }
                }
            });
        });
    }
    
    // ===================================
    // INITIALIZATION
    // ===================================
    
    function init() {
        // Attendre que le DOM soit prêt
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initAll);
        } else {
            initAll();
        }
    }
    
    function initAll() {
        console.log('🚀 Blog Mobile Enhancements initialized');
        
        initLazyLoading();
        initTouchFeedback();
        initReadMore();
        initSmoothScroll();
        initSwipeNavigation();
        optimizeScrollPerformance();
        handleOrientationChange();
        initLoadingFeedback();
        optimizeAnimations();
        initCopyLink();
        
        // Sur page article uniquement
        if (document.querySelector('.article-body')) {
            initReadingProgress();
            prefetchRelatedArticles();
        }
    }
    
    // Start
    init();
    
})();
