// Centralized Data Source for WebCreation.pro

const siteData = {
    services: [
        {
            id: 1,
            title: "Design & UX/UI",
            icon: "fa-palette",
            description: "Interfaces modernes et intuitives conçues pour maximiser l'engagement.",
            tags: ["Figma", "Prototypage", "Mobile First"],
            featured: false
        },
        {
            id: 2,
            title: "Développement Web",
            icon: "fa-code",
            description: "Sites vitrines, e-commerce et applications sur-mesure.",
            tags: ["React", "Next.js", "Tailwind"],
            featured: true
        },
        {
            id: 3,
            title: "Intégration IA",
            icon: "fa-brain",
            description: "Automatisation intelligente et chatbots GPT-4 pour votre business.",
            tags: ["OpenAI", "Automation", "Chatbots"],
            featured: false
        }
    ],

    portfolio: [
        {
            id: 'bistrot',
            title: "Le Bistrot Gourmet",
            category: "web",
            image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=600&fit=crop&q=80",
            description: "Site vitrine moderne avec menu interactif et réservation.",
            metrics: "+85% Réservations"
        },
        {
            id: 'style-co',
            title: "Style & Co",
            category: "ecommerce",
            image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=800&h=600&fit=crop&q=80",
            description: "Boutique en ligne avec gestion des stocks et paiements.",
            metrics: "150+ Commandes/mois"
        },
        {
            id: 'fitclub',
            title: "FitClub",
            category: "web",
            image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&h=600&fit=crop&q=80",
            description: "Site de salle de sport avec planning dynamique.",
            metrics: "+200 Inscriptions"
        }
    ],

    posts: [
        {
            id: 'seo-guide-2024',
            title: "Guide SEO 2024 : Optimisez votre site",
            date: "15 Nov 2024",
            readTime: "8 min",
            category: "SEO",
            image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop&q=80",
            excerpt: "Découvrez les stratégies SEO les plus efficaces pour propulser votre site en première page de Google."
        },
        {
            id: 'ux-ui-principles',
            title: "10 Principes UX/UI essentiels",
            date: "12 Nov 2024",
            readTime: "6 min",
            category: "Design",
            image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=600&fit=crop&q=80",
            excerpt: "L'expérience utilisateur est au cœur de la conversion. Transformez vos visiteurs en clients fidèles."
        },
        {
            id: 'ai-chatbots',
            title: "Chatbots IA : Révolution du service client",
            date: "10 Nov 2024",
            readTime: "7 min",
            category: "IA",
            image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop&q=80",
            excerpt: "Comment intégrer GPT-4 pour automatiser 80% de vos demandes clients sans perdre le contact humain."
        }
    ]
};