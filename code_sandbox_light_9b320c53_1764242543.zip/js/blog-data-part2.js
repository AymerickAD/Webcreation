/**
 * WebCreation - Articles de blog (Partie 2/2)
 * Articles 4 à 8
 */

const blogArticlesPart2 = [
    {
        id: 'rgpd-conformite-site-web-2024',
        title: 'RGPD et Sites Web : Guide de conformité 2024',
        slug: 'rgpd-conformite-site-web-2024',
        excerpt: 'Mettez votre site web en conformité RGPD. Évitez les amendes jusqu\'à 20M€ avec notre guide complet des obligations légales.',
        content: `
            <h2>RGPD : Pourquoi c'est obligatoire pour votre site</h2>
            <p>Depuis mai 2018, le <strong>Règlement Général sur la Protection des Données (RGPD)</strong> impose des règles strictes pour tout site web collectant des données personnelles.</p>
            
            <div class="rgpd-penalties">
                <h3>⚠️ Sanctions en cas de non-conformité :</h3>
                <div class="penalty-box">
                    <h4>Niveau 1 (violations mineures)</h4>
                    <p class="penalty-amount">Jusqu'à 10M€ ou 2% CA mondial</p>
                </div>
                <div class="penalty-box severe">
                    <h4>Niveau 2 (violations graves)</h4>
                    <p class="penalty-amount">Jusqu'à 20M€ ou 4% CA mondial</p>
                </div>
            </div>

            <p class="highlight">En 2023, la CNIL a infligé <strong>91 millions d'euros</strong> d'amendes en France.</p>

            <h2>Qu'est-ce qu'une donnée personnelle ?</h2>
            <p>Toute information permettant d'<strong>identifier directement ou indirectement</strong> une personne :</p>
            
            <ul>
                <li>📧 Email, téléphone, adresse postale</li>
                <li>👤 Nom, prénom, date de naissance</li>
                <li>💳 Numéro de carte bancaire, IBAN</li>
                <li>🆔 Numéro de sécurité sociale, permis de conduire</li>
                <li>📍 Adresse IP, cookies, identifiant unique</li>
                <li>📷 Photos, vidéos, empreintes biométriques</li>
            </ul>

            <h2>Les 7 principes fondamentaux du RGPD</h2>
            
            <div class="rgpd-principles">
                <div class="principle">
                    <h3>1. Licéité, loyauté, transparence</h3>
                    <p>Traiter les données de manière <strong>légale, honnête et transparente</strong>.</p>
                    <p><strong>En pratique :</strong> Informer clairement l'utilisateur avant collecte.</p>
                </div>
                
                <div class="principle">
                    <h3>2. Limitation des finalités</h3>
                    <p>Collecter les données pour des <strong>objectifs précis et légitimes</strong>.</p>
                    <p><strong>En pratique :</strong> Ne pas utiliser les emails marketing pour autre chose.</p>
                </div>
                
                <div class="principle">
                    <h3>3. Minimisation des données</h3>
                    <p>Collecter uniquement les données <strong>nécessaires et pertinentes</strong>.</p>
                    <p><strong>En pratique :</strong> Pas de demande de date de naissance si inutile.</p>
                </div>
                
                <div class="principle">
                    <h3>4. Exactitude</h3>
                    <p>Maintenir les données <strong>à jour et exactes</strong>.</p>
                    <p><strong>En pratique :</strong> Permettre la modification du profil utilisateur.</p>
                </div>
                
                <div class="principle">
                    <h3>5. Limitation de la conservation</h3>
                    <p>Conserver les données uniquement le <strong>temps nécessaire</strong>.</p>
                    <p><strong>En pratique :</strong> Supprimer automatiquement après 3 ans d'inactivité.</p>
                </div>
                
                <div class="principle">
                    <h3>6. Intégrité et confidentialité</h3>
                    <p>Protéger les données par des <strong>mesures de sécurité adaptées</strong>.</p>
                    <p><strong>En pratique :</strong> Chiffrement, accès restreints, audits réguliers.</p>
                </div>
                
                <div class="principle">
                    <h3>7. Responsabilité</h3>
                    <p>Prouver la conformité avec des <strong>documents et procédures</strong>.</p>
                    <p><strong>En pratique :</strong> Registre des traitements, PIA, contrats sous-traitants.</p>
                </div>
            </div>

            <h2>Checklist de conformité RGPD pour votre site web</h2>
            
            <div class="compliance-checklist">
                <h3>📋 Documents obligatoires</h3>
                <div class="checklist-item">✅ Politique de confidentialité complète et accessible</div>
                <div class="checklist-item">✅ Mentions légales avec DPO (si applicable)</div>
                <div class="checklist-item">✅ Registre des traitements documenté</div>
                <div class="checklist-item">✅ Procédure de gestion des demandes d'accès</div>
                
                <h3>🍪 Cookies et traceurs</h3>
                <div class="checklist-item">✅ Banner cookie conforme (refuse facile)</div>
                <div class="checklist-item">✅ Pas de cookies avant consentement</div>
                <div class="checklist-item">✅ Liste détaillée des cookies utilisés</div>
                <div class="checklist-item">✅ Durée de conservation affichée</div>
                
                <h3>📝 Formulaires</h3>
                <div class="checklist-item">✅ Consentement explicite (opt-in)</div>
                <div class="checklist-item">✅ Cases pré-cochées interdites</div>
                <div class="checklist-item">✅ Finalité clairement expliquée</div>
                <div class="checklist-item">✅ Champs obligatoires justifiés</div>
                
                <h3>🔒 Sécurité</h3>
                <div class="checklist-item">✅ Certificat SSL (HTTPS)</div>
                <div class="checklist-item">✅ Chiffrement des données sensibles</div>
                <div class="checklist-item">✅ Accès restreints et logs</div>
                <div class="checklist-item">✅ Sauvegardes régulières chiffrées</div>
                
                <h3>👤 Droits des utilisateurs</h3>
                <div class="checklist-item">✅ Droit d'accès (export données)</div>
                <div class="checklist-item">✅ Droit de rectification</div>
                <div class="checklist-item">✅ Droit à l'effacement ("droit à l'oubli")</div>
                <div class="checklist-item">✅ Droit à la portabilité</div>
                <div class="checklist-item">✅ Droit d'opposition</div>
                <div class="checklist-item">✅ Réponse sous 1 mois maximum</div>
            </div>

            <h2>Comment rédiger une politique de confidentialité RGPD</h2>
            
            <div class="privacy-policy-template">
                <h3>Structure type d'une politique de confidentialité :</h3>
                
                <div class="policy-section">
                    <h4>1. Identité du responsable de traitement</h4>
                    <p>Nom, adresse, contact, DPO si applicable</p>
                </div>
                
                <div class="policy-section">
                    <h4>2. Données collectées</h4>
                    <p>Liste exhaustive : identité, contact, navigation, etc.</p>
                </div>
                
                <div class="policy-section">
                    <h4>3. Finalités du traitement</h4>
                    <p>Gestion commandes, newsletter, statistiques, etc.</p>
                </div>
                
                <div class="policy-section">
                    <h4>4. Base légale</h4>
                    <p>Consentement, contrat, obligation légale, intérêt légitime</p>
                </div>
                
                <div class="policy-section">
                    <h4>5. Destinataires des données</h4>
                    <p>Services internes, sous-traitants, partenaires</p>
                </div>
                
                <div class="policy-section">
                    <h4>6. Durée de conservation</h4>
                    <p>Préciser pour chaque type de donnée</p>
                </div>
                
                <div class="policy-section">
                    <h4>7. Droits des personnes</h4>
                    <p>Accès, rectification, effacement, portabilité, opposition</p>
                </div>
                
                <div class="policy-section">
                    <h4>8. Sécurité et confidentialité</h4>
                    <p>Mesures techniques et organisationnelles</p>
                </div>
                
                <div class="policy-section">
                    <h4>9. Cookies et traceurs</h4>
                    <p>Liste, finalités, durée, gestion consentement</p>
                </div>
                
                <div class="policy-section">
                    <h4>10. Modification de la politique</h4>
                    <p>Comment les utilisateurs seront informés</p>
                </div>
            </div>

            <h2>Cookies : Ce que dit la loi en 2024</h2>
            
            <div class="cookie-law">
                <h3>🍪 Règles strictes de la CNIL :</h3>
                
                <div class="law-rule">
                    <h4>❌ Interdit</h4>
                    <ul>
                        <li>Cases pré-cochées pour accepter</li>
                        <li>Cookie wall (blocage total sans acceptation)</li>
                        <li>Continuer = accepter</li>
                        <li>Scroll = accepter</li>
                        <li>Cookies déposés avant consentement</li>
                    </ul>
                </div>
                
                <div class="law-rule">
                    <h4>✅ Obligatoire</h4>
                    <ul>
                        <li>Bouton "Tout refuser" aussi visible que "Tout accepter"</li>
                        <li>Possibilité de refuser facilement</li>
                        <li>Information claire sur chaque cookie</li>
                        <li>Durée de validité du consentement : 6 mois max</li>
                        <li>Preuve du consentement conservée</li>
                    </ul>
                </div>
            </div>

            <h2>Exemples de sanctions RGPD en France</h2>
            
            <div class="sanctions-examples">
                <div class="sanction">
                    <h4>Google (2020)</h4>
                    <p class="amount">90 millions €</p>
                    <p>Cookies publicitaires sans consentement</p>
                </div>
                
                <div class="sanction">
                    <h4>Amazon (2021)</h4>
                    <p class="amount">746 millions €</p>
                    <p>Cookies de tracking non conformes</p>
                </div>
                
                <div class="sanction">
                    <h4>TikTok (2024)</h4>
                    <p class="amount">5 millions €</p>
                    <p>Refus des cookies difficile</p>
                </div>
            </div>

            <h2>Nos services de mise en conformité RGPD</h2>
            
            <div class="rgpd-services">
                <div class="service">
                    <h4>📋 Audit RGPD</h4>
                    <p class="price">À partir de 1 290€</p>
                    <ul>
                        <li>Analyse complète du site</li>
                        <li>Identification des non-conformités</li>
                        <li>Plan d'action priorisé</li>
                        <li>Rapport détaillé</li>
                    </ul>
                </div>
                
                <div class="service featured">
                    <h4>✅ Mise en conformité complète</h4>
                    <p class="price">À partir de 2 990€</p>
                    <ul>
                        <li>Audit + Implémentation</li>
                        <li>Rédaction politique de confidentialité</li>
                        <li>Banner cookies conforme</li>
                        <li>Registre des traitements</li>
                        <li>Formation équipe</li>
                        <li>Suivi 1 an</li>
                    </ul>
                </div>
                
                <div class="service">
                    <h4>🛡️ DPO externalisé</h4>
                    <p class="price">590€/mois</p>
                    <ul>
                        <li>DPO dédié à votre entreprise</li>
                        <li>Veille réglementaire</li>
                        <li>Gestion demandes d'accès</li>
                        <li>Support illimité</li>
                    </ul>
                </div>
            </div>

            <h2>Demandez votre audit RGPD gratuit</h2>
            <p>Obtenez un <strong>pré-audit gratuit</strong> de votre site web avec les 5 non-conformités les plus critiques.</p>
        `,
        category: 'Conformité',
        date: '2024-11-15',
        readingTime: '11 min',
        author: 'Expert RGPD',
        tags: ['RGPD', 'Conformité', 'Protection données', 'CNIL', 'Cookies'],
        image: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&h=600&fit=crop&q=80',
        seo: {
            metaTitle: 'RGPD Site Web 2024 : Guide conformité et éviter les amendes | WebCreation',
            metaDescription: 'Mettez votre site en conformité RGPD : cookies, politique de confidentialité, droits utilisateurs. Audit gratuit et accompagnement complet.',
            keywords: ['RGPD site web', 'conformité RGPD', 'cookies CNIL', 'politique confidentialité', 'protection données', 'audit RGPD']
        }
    },
    {
        id: 'performance-web-pagespeed-optimisation',
        title: 'Performance Web : Accélérez votre site pour Google et vos visiteurs',
        slug: 'performance-web-pagespeed-optimisation',
        excerpt: 'Un site lent perd 53% de ses visiteurs. Découvrez comment atteindre un score PageSpeed de 95+ et booster vos conversions.',
        content: `
            <h2>Pourquoi la vitesse de votre site est critique</h2>
            
            <div class="speed-impact">
                <h3>📊 Impact business de la performance :</h3>
                <div class="impact-stat">
                    <h4>+100ms = -1% conversions</h4>
                    <p>Chaque dixième de seconde compte pour Amazon</p>
                </div>
                <div class="impact-stat">
                    <h4>53% abandonnent si >3s</h4>
                    <p>La moitié de vos visiteurs potentiels partent</p>
                </div>
                <div class="impact-stat">
                    <h4>70% préfèrent sites rapides</h4>
                    <p>La vitesse influence la perception de qualité</p>
                </div>
            </div>

            <h2>Comment mesurer la performance de votre site</h2>
            
            <h3>1. PageSpeed Insights (Google)</h3>
            <p>L'outil officiel de Google pour mesurer les <strong>Core Web Vitals</strong>.</p>
            
            <div class="tool-scores">
                <div class="score good">
                    <h4>90-100 points</h4>
                    <p>✅ Excellent - Continuez ainsi !</p>
                </div>
                <div class="score medium">
                    <h4>50-89 points</h4>
                    <p>⚠️ Moyen - Optimisations nécessaires</p>
                </div>
                <div class="score bad">
                    <h4>0-49 points</h4>
                    <p>❌ Mauvais - Action urgente requise</p>
                </div>
            </div>

            <h3>2. GTmetrix</h3>
            <p>Analyse complète avec recommandations détaillées et tests depuis plusieurs localisations.</p>

            <h3>3. WebPageTest</h3>
            <p>Tests avancés : filmstrip, waterfall, connexions lentes, différents navigateurs.</p>

            <h2>Les 15 optimisations qui font la différence</h2>
            
            <h3>🖼️ 1. Optimisation des images</h3>
            <p>Les images représentent en moyenne <strong>50% du poids</strong> d'une page web.</p>
            
            <div class="image-optimization">
                <h4>Formats modernes :</h4>
                <ul>
                    <li><strong>WebP</strong> : -30% poids vs JPEG, excellent support navigateurs</li>
                    <li><strong>AVIF</strong> : -50% poids vs JPEG, support croissant</li>
                    <li><strong>SVG</strong> : Vectoriel, poids minimal pour logos/icônes</li>
                </ul>
                
                <h4>Techniques :</h4>
                <ul>
                    <li>✅ Compression avec TinyPNG, Squoosh, ImageOptim</li>
                    <li>✅ Lazy loading (chargement différé)</li>
                    <li>✅ Responsive images (srcset + sizes)</li>
                    <li>✅ Dimensions explicites (width + height)</li>
                    <li>✅ CDN pour distribution rapide</li>
                </ul>
            </div>

            <h3>📦 2. Minification CSS/JS</h3>
            <p>Réduire la taille des fichiers en supprimant espaces, commentaires, lignes vides.</p>
            
            <pre><code>/* Avant minification (15 KB) */
function calculateTotal(items) {
    let total = 0;
    for (let i = 0; i < items.length; i++) {
        total += items[i].price;
    }
    return total;
}

/* Après minification (8 KB) */
function calculateTotal(t){let e=0;for(let l=0;l<t.length;l++)e+=t[l].price;return e}</code></pre>

            <h3>🗜️ 3. Compression GZIP/Brotli</h3>
            <p>Compresser les ressources textuelles avant envoi au navigateur.</p>
            
            <div class="compression-comparison">
                <div class="comp-col">
                    <h4>Sans compression</h4>
                    <p>HTML: 50 KB</p>
                    <p>CSS: 80 KB</p>
                    <p>JS: 200 KB</p>
                    <p class="total">Total: 330 KB</p>
                </div>
                <div class="comp-col">
                    <h4>Avec Brotli</h4>
                    <p>HTML: 12 KB (-76%)</p>
                    <p>CSS: 15 KB (-81%)</p>
                    <p>JS: 45 KB (-78%)</p>
                    <p class="total">Total: 72 KB (-78%)</p>
                </div>
            </div>

            <h3>🚀 4. CDN (Content Delivery Network)</h3>
            <p>Distribuer votre contenu depuis des serveurs géographiquement proches de vos visiteurs.</p>
            
            <div class="cdn-providers">
                <div class="provider">
                    <h4>Cloudflare</h4>
                    <p>Gratuit - 0$/mois</p>
                    <p>Plan gratuit excellent pour PME</p>
                </div>
                <div class="provider">
                    <h4>AWS CloudFront</h4>
                    <p>Pay-as-you-go</p>
                    <p>Intégration parfaite AWS</p>
                </div>
                <div class="provider">
                    <h4>Fastly</h4>
                    <p>Enterprise</p>
                    <p>Performance maximale</p>
                </div>
            </div>

            <h3>⚡ 5. Mise en cache (Caching)</h3>
            <p>Stocker les ressources localement pour éviter de les re-télécharger.</p>
            
            <div class="cache-types">
                <h4>Browser caching</h4>
                <p>Cache navigateur (headers Cache-Control, Expires)</p>
                
                <h4>Server caching</h4>
                <p>Redis, Memcached, Varnish</p>
                
                <h4>CDN caching</h4>
                <p>Cache edge servers proche utilisateurs</p>
            </div>

            <h3>📱 6. Responsive images</h3>
            <p>Servir des images adaptées à la taille d'écran.</p>
            
            <pre><code>&lt;img
  src="image-800w.jpg"
  srcset="image-400w.jpg 400w,
          image-800w.jpg 800w,
          image-1200w.jpg 1200w"
  sizes="(max-width: 600px) 400px,
         (max-width: 1200px) 800px,
         1200px"
  alt="Description"
/&gt;</code></pre>

            <h3>🔤 7. Optimisation des fonts</h3>
            <p>Les webfonts peuvent ralentir considérablement le chargement.</p>
            
            <ul>
                <li>✅ <strong>font-display: swap</strong> : Afficher texte immédiatement</li>
                <li>✅ <strong>Sous-ensembles</strong> : Charger uniquement caractères nécessaires</li>
                <li>✅ <strong>Préchargement</strong> : &lt;link rel="preload"&gt;</li>
                <li>✅ <strong>Formats modernes</strong> : WOFF2 (30% plus léger que WOFF)</li>
            </ul>

            <h3>🎯 8. Critical CSS</h3>
            <p>Inliner le CSS critique pour affichage immédiat, différer le reste.</p>
            
            <pre><code>&lt;head&gt;
  &lt;style&gt;
    /* Critical CSS inliné */
    body { font-family: sans-serif; }
    .hero { background: #0066FF; }
  &lt;/style&gt;
  
  &lt;link rel="preload" href="styles.css" as="style"
        onload="this.rel='stylesheet'"&gt;
&lt;/head&gt;</code></pre>

            <h3>🔄 9. Code splitting</h3>
            <p>Diviser le JavaScript en chunks chargés à la demande.</p>
            
            <pre><code>// Lazy load d'un composant
const Modal = React.lazy(() => import('./Modal'));

// Utilisation
&lt;Suspense fallback={&lt;Loading /&gt;}&gt;
  &lt;Modal /&gt;
&lt;/Suspense&gt;</code></pre>

            <h3>🌐 10. HTTP/2 et HTTP/3</h3>
            <p>Protocoles modernes permettant multiplexage et compression des headers.</p>
            
            <div class="http-comparison">
                <div class="http-version">
                    <h4>HTTP/1.1</h4>
                    <p>❌ 1 requête à la fois</p>
                    <p>❌ Headers non compressés</p>
                </div>
                <div class="http-version">
                    <h4>HTTP/2</h4>
                    <p>✅ Multiplexage</p>
                    <p>✅ Server push</p>
                    <p>✅ Compression headers</p>
                </div>
                <div class="http-version">
                    <h4>HTTP/3 (QUIC)</h4>
                    <p>✅ Tout HTTP/2</p>
                    <p>✅ UDP (plus rapide)</p>
                    <p>✅ 0-RTT</p>
                </div>
            </div>

            <h2>Checklist d'optimisation complète</h2>
            
            <div class="optimization-checklist">
                <h3>🎨 Frontend</h3>
                <div class="checklist-item">✅ Images optimisées (WebP, lazy loading)</div>
                <div class="checklist-item">✅ CSS minifié et critical inliné</div>
                <div class="checklist-item">✅ JavaScript minifié et différé</div>
                <div class="checklist-item">✅ Fonts optimisés (WOFF2, font-display)</div>
                <div class="checklist-item">✅ Pas de render-blocking resources</div>
                
                <h3>⚙️ Backend</h3>
                <div class="checklist-item">✅ Compression GZIP/Brotli activée</div>
                <div class="checklist-item">✅ Cache navigateur configuré</div>
                <div class="checklist-item">✅ Serveur HTTP/2 ou HTTP/3</div>
                <div class="checklist-item">✅ Database queries optimisées</div>
                <div class="checklist-item">✅ CDN configuré</div>
                
                <h3>📊 Monitoring</h3>
                <div class="checklist-item">✅ Google Search Console actif</div>
                <div class="checklist-item">✅ Real User Monitoring (RUM)</div>
                <div class="checklist-item">✅ Alertes performance configurées</div>
            </div>

            <h2>Budget type pour optimiser un site</h2>
            
            <div class="optimization-pricing">
                <div class="pricing-tier">
                    <h4>🔧 Optimisation basique</h4>
                    <p class="price">890€</p>
                    <ul>
                        <li>Audit performance</li>
                        <li>Optimisation images</li>
                        <li>Minification CSS/JS</li>
                        <li>Cache navigateur</li>
                        <li>Score PageSpeed 70-85</li>
                    </ul>
                </div>
                
                <div class="pricing-tier featured">
                    <h4>⚡ Optimisation avancée</h4>
                    <p class="price">2 490€</p>
                    <ul>
                        <li>Audit + Basique</li>
                        <li>CDN configuré</li>
                        <li>Critical CSS</li>
                        <li>Code splitting</li>
                        <li>HTTP/2</li>
                        <li>Score PageSpeed 90-95</li>
                    </ul>
                </div>
                
                <div class="pricing-tier">
                    <h4>🚀 Optimisation expert</h4>
                    <p class="price">4 990€</p>
                    <ul>
                        <li>Audit + Avancé</li>
                        <li>HTTP/3</li>
                        <li>Edge computing</li>
                        <li>Monitoring RUM</li>
                        <li>Alertes custom</li>
                        <li>Score PageSpeed 95-100</li>
                    </ul>
                </div>
            </div>

            <h2>Demandez votre audit de performance gratuit</h2>
            <p>Obtenez un <strong>rapport PageSpeed gratuit</strong> avec les 10 optimisations prioritaires pour accélérer votre site.</p>
        `,
        category: 'Performance',
        date: '2024-11-14',
        readingTime: '10 min',
        author: 'Expert Performance Web',
        tags: ['Performance', 'PageSpeed', 'Optimisation', 'Core Web Vitals', 'Vitesse'],
        image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop&q=80',
        seo: {
            metaTitle: 'Performance Web 2024 : Optimisation PageSpeed et Core Web Vitals | WebCreation',
            metaDescription: 'Accélérez votre site web : techniques d\'optimisation, Core Web Vitals, CDN, images. Audit gratuit et score PageSpeed 95+.',
            keywords: ['performance web', 'optimisation site', 'PageSpeed', 'Core Web Vitals', 'vitesse chargement', 'CDN']
        }
    }
];

// Fusionner avec les articles précédents
const allBlogArticles = typeof blogArticles !== 'undefined' 
    ? [...blogArticles, ...blogArticlesPart2]
    : blogArticlesPart2;

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { blogArticlesPart2, allBlogArticles };
}
