/**
 * Framer-Inspired Components Library
 * Vanilla JavaScript adaptations of popular Framer components
 * Version: 1.0.0
 * 
 * Components:
 * - TypewriterEffect: Animated typing text
 * - HorizontalScroller: Smooth horizontal scroll navigation
 * - LiquidImage: Liquid morphing effects on images
 * - DynamicToggle: Animated toggle switches
 */

// ============================================
// 1. TYPEWRITER EFFECT
// ============================================
class TypewriterEffect {
    constructor(element, options = {}) {
        this.element = element;
        this.text = options.text || element.getAttribute('data-typewriter') || element.textContent;
        this.speed = options.speed || 80;
        this.delay = options.delay || 0;
        this.loop = options.loop || false;
        this.cursor = options.cursor !== false;
        this.cursorChar = options.cursorChar || '|';
        
        this.currentIndex = 0;
        this.isTyping = false;
        this.element.textContent = '';
        
        if (this.cursor) {
            this.cursorElement = document.createElement('span');
            this.cursorElement.className = 'typewriter-cursor';
            this.cursorElement.textContent = this.cursorChar;
            this.element.appendChild(this.cursorElement);
        }
        
        this.init();
    }
    
    init() {
        setTimeout(() => this.type(), this.delay);
    }
    
    type() {
        if (this.currentIndex < this.text.length) {
            this.isTyping = true;
            const char = this.text.charAt(this.currentIndex);
            
            if (this.cursor) {
                this.element.insertBefore(
                    document.createTextNode(char),
                    this.cursorElement
                );
            } else {
                this.element.textContent += char;
            }
            
            this.currentIndex++;
            setTimeout(() => this.type(), this.speed);
        } else {
            this.isTyping = false;
            if (this.loop) {
                setTimeout(() => this.reset(), 2000);
            }
        }
    }
    
    reset() {
        this.currentIndex = 0;
        this.element.textContent = '';
        if (this.cursor) {
            this.element.appendChild(this.cursorElement);
        }
        this.type();
    }
    
    static initAll(selector = '[data-typewriter]') {
        document.querySelectorAll(selector).forEach(element => {
            new TypewriterEffect(element);
        });
    }
}

// ============================================
// 2. HORIZONTAL SCROLLER
// ============================================
class HorizontalScroller {
    constructor(container, options = {}) {
        this.container = container;
        this.track = container.querySelector('.horizontal-scroller-track');
        this.items = this.track.querySelectorAll('.scroller-item');
        this.speed = options.speed || 1;
        this.autoScroll = options.autoScroll || false;
        this.dragToScroll = options.dragToScroll !== false;
        
        this.isDragging = false;
        this.startX = 0;
        this.scrollLeft = 0;
        
        this.init();
    }
    
    init() {
        // Smooth scrolling on wheel
        this.container.addEventListener('wheel', (e) => {
            e.preventDefault();
            this.container.scrollLeft += e.deltaY * this.speed;
        });
        
        if (this.dragToScroll) {
            this.initDragScroll();
        }
        
        if (this.autoScroll) {
            this.startAutoScroll();
        }
    }
    
    initDragScroll() {
        this.container.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.startX = e.pageX - this.container.offsetLeft;
            this.scrollLeft = this.container.scrollLeft;
            this.container.style.cursor = 'grabbing';
        });
        
        this.container.addEventListener('mouseleave', () => {
            this.isDragging = false;
            this.container.style.cursor = 'grab';
        });
        
        this.container.addEventListener('mouseup', () => {
            this.isDragging = false;
            this.container.style.cursor = 'grab';
        });
        
        this.container.addEventListener('mousemove', (e) => {
            if (!this.isDragging) return;
            e.preventDefault();
            const x = e.pageX - this.container.offsetLeft;
            const walk = (x - this.startX) * 2;
            this.container.scrollLeft = this.scrollLeft - walk;
        });
    }
    
    startAutoScroll() {
        setInterval(() => {
            this.container.scrollLeft += this.speed;
            if (this.container.scrollLeft >= this.track.scrollWidth - this.container.offsetWidth) {
                this.container.scrollLeft = 0;
            }
        }, 30);
    }
    
    scrollTo(index, smooth = true) {
        const item = this.items[index];
        if (item) {
            item.scrollIntoView({
                behavior: smooth ? 'smooth' : 'auto',
                inline: 'center',
                block: 'nearest'
            });
        }
    }
    
    static initAll(selector = '.horizontal-scroller') {
        document.querySelectorAll(selector).forEach(container => {
            new HorizontalScroller(container);
        });
    }
}

// ============================================
// 3. LIQUID IMAGE
// ============================================
class LiquidImage {
    constructor(element, options = {}) {
        this.element = element;
        this.intensity = options.intensity || 20;
        this.smoothness = options.smoothness || 0.1;
        
        this.currentX = 0;
        this.currentY = 0;
        this.targetX = 0;
        this.targetY = 0;
        
        this.init();
    }
    
    init() {
        this.element.style.transition = 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)';
        
        this.element.addEventListener('mousemove', (e) => {
            const rect = this.element.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width;
            const y = (e.clientY - rect.top) / rect.height;
            
            this.targetX = (x - 0.5) * this.intensity;
            this.targetY = (y - 0.5) * this.intensity;
            
            this.animate();
        });
        
        this.element.addEventListener('mouseleave', () => {
            this.targetX = 0;
            this.targetY = 0;
            this.animate();
        });
    }
    
    animate() {
        this.currentX += (this.targetX - this.currentX) * this.smoothness;
        this.currentY += (this.targetY - this.currentY) * this.smoothness;
        
        this.element.style.transform = `
            scale(1.05) 
            translate(${this.currentX}px, ${this.currentY}px)
            rotateX(${-this.currentY * 0.5}deg)
            rotateY(${this.currentX * 0.5}deg)
        `;
        
        if (Math.abs(this.targetX - this.currentX) > 0.1 || 
            Math.abs(this.targetY - this.currentY) > 0.1) {
            requestAnimationFrame(() => this.animate());
        }
    }
    
    static initAll(selector = '.liquid-image') {
        document.querySelectorAll(selector).forEach(element => {
            new LiquidImage(element);
        });
    }
}

// ============================================
// 4. DYNAMIC TOGGLE
// ============================================
class DynamicToggle {
    constructor(element, options = {}) {
        this.element = element;
        this.checked = element.hasAttribute('checked') || options.checked || false;
        this.onChange = options.onChange || (() => {});
        this.disabled = element.hasAttribute('disabled') || options.disabled || false;
        
        this.init();
    }
    
    init() {
        this.element.classList.add('dynamic-toggle');
        if (this.checked) this.element.classList.add('checked');
        if (this.disabled) this.element.classList.add('disabled');
        
        // Create toggle structure
        const track = document.createElement('div');
        track.className = 'toggle-track';
        
        const thumb = document.createElement('div');
        thumb.className = 'toggle-thumb';
        
        track.appendChild(thumb);
        this.element.appendChild(track);
        
        // Click handler
        this.element.addEventListener('click', () => {
            if (!this.disabled) {
                this.toggle();
            }
        });
    }
    
    toggle() {
        this.checked = !this.checked;
        this.element.classList.toggle('checked', this.checked);
        this.onChange(this.checked);
        
        // Trigger animation
        this.element.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.element.style.transform = 'scale(1)';
        }, 100);
    }
    
    setChecked(value) {
        this.checked = value;
        this.element.classList.toggle('checked', this.checked);
    }
    
    setDisabled(value) {
        this.disabled = value;
        this.element.classList.toggle('disabled', this.disabled);
    }
    
    static initAll(selector = '.toggle') {
        document.querySelectorAll(selector).forEach(element => {
            new DynamicToggle(element);
        });
    }
}

// ============================================
// 5. MAGNETIC BUTTON (Bonus - Framer style)
// ============================================
class MagneticButton {
    constructor(element, options = {}) {
        this.element = element;
        this.strength = options.strength || 30;
        
        this.init();
    }
    
    init() {
        this.element.addEventListener('mousemove', (e) => {
            const rect = this.element.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            
            const moveX = (x / rect.width) * this.strength;
            const moveY = (y / rect.height) * this.strength;
            
            this.element.style.transform = `translate(${moveX}px, ${moveY}px) scale(1.05)`;
        });
        
        this.element.addEventListener('mouseleave', () => {
            this.element.style.transform = 'translate(0, 0) scale(1)';
        });
    }
    
    static initAll(selector = '.magnetic-btn') {
        document.querySelectorAll(selector).forEach(element => {
            new MagneticButton(element);
        });
    }
}

// ============================================
// AUTO-INIT ON DOM LOAD
// ============================================
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFramerComponents);
} else {
    initFramerComponents();
}

function initFramerComponents() {
    // Auto-initialize all components with data attributes
    // Typewriter désactivé à la demande
    // TypewriterEffect.initAll();
    HorizontalScroller.initAll();
    LiquidImage.initAll();
    DynamicToggle.initAll();
    MagneticButton.initAll();
    
    console.log('✨ Framer Components initialized (typewriter désactivé)');
}

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        TypewriterEffect,
        HorizontalScroller,
        LiquidImage,
        DynamicToggle,
        MagneticButton
    };
}
