/* ========================================
   WEBCREATION - JAVASCRIPT FINAL CONSOLIDÉ
   Menu bubble avec GSAP + Interactions
   ======================================== */

(function() {
  'use strict';

  // ===== CONFIGURATION =====
  const CONFIG = {
    animationEase: 'back.out(1.5)',
    animationDuration: 0.5,
    staggerDelay: 0.12,
    isMobile: window.innerWidth <= 768
  };

  // ===== CHARGEMENT GSAP DEPUIS CDN =====
  function loadGSAP() {
    return new Promise((resolve, reject) => {
      if (typeof gsap !== 'undefined') {
        resolve(gsap);
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js';
      script.onload = () => {
        if (typeof gsap !== 'undefined') {
          console.log('✅ GSAP chargé avec succès');
          resolve(gsap);
        } else {
          reject(new Error('GSAP non disponible après chargement'));
        }
      };
      script.onerror = () => reject(new Error('Erreur chargement GSAP'));
      document.head.appendChild(script);
    });
  }

  // ===== BUBBLE MENU =====
  class BubbleMenu {
    constructor() {
      this.menuBtn = document.querySelector('.toggle-bubble');
      this.menuOverlay = document.querySelector('.bubble-menu-items');
      this.pillLinks = document.querySelectorAll('.pill-link');
      this.isOpen = false;
      this.gsap = null;
      
      this.init();
    }

    async init() {
      if (!this.menuBtn || !this.menuOverlay) {
        console.warn('⚠️ Éléments menu non trouvés');
        return;
      }

      try {
        // Charger GSAP
        this.gsap = await loadGSAP();
        console.log('✅ BubbleMenu initialisé avec GSAP');

        // Event listeners
        this.menuBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggle();
        });

        // Fermer au clic sur un lien
        this.pillLinks.forEach(link => {
          link.addEventListener('click', () => {
            if (this.isOpen) {
              this.close();
            }
          });
        });

        // Fermer au clic en dehors
        document.addEventListener('click', (e) => {
          if (this.isOpen && 
              !this.menuOverlay.contains(e.target) && 
              !this.menuBtn.contains(e.target)) {
            this.close();
          }
        });

        // Fermer avec ESC
        document.addEventListener('keydown', (e) => {
          if (e.key === 'Escape' && this.isOpen) {
            this.close();
          }
        });

        // Smooth scroll
        this.setupSmoothScroll();

      } catch (error) {
        console.error('❌ Erreur initialisation BubbleMenu:', error);
        // Fallback sans animations
        this.setupFallback();
      }
    }

    toggle() {
      if (this.isOpen) {
        this.close();
      } else {
        this.open();
      }
    }

    open() {
      this.isOpen = true;
      this.menuBtn.classList.add('open');
      this.menuOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';

      // Animation GSAP
      if (this.gsap) {
        this.gsap.killTweensOf(this.pillLinks);
        
        // Reset initial
        this.gsap.set(this.pillLinks, { 
          scale: 0, 
          autoAlpha: 0,
          transformOrigin: '50% 50%' 
        });

        // Animation staggered
        this.pillLinks.forEach((link, i) => {
          const delay = i * CONFIG.staggerDelay + this.gsap.utils.random(-0.05, 0.05);
          
          this.gsap.to(link, {
            scale: 1,
            autoAlpha: 1,
            duration: CONFIG.animationDuration,
            ease: CONFIG.animationEase,
            delay: delay
          });
        });
      } else {
        // Fallback sans GSAP
        this.pillLinks.forEach(link => {
          link.style.opacity = '1';
          link.style.transform = 'scale(1)';
        });
      }

      // Accessibility
      this.menuBtn.setAttribute('aria-expanded', 'true');
    }

    close() {
      this.isOpen = false;
      this.menuBtn.classList.remove('open');
      document.body.style.overflow = '';

      // Animation GSAP
      if (this.gsap) {
        this.gsap.killTweensOf(this.pillLinks);
        
        this.gsap.to(this.pillLinks, {
          scale: 0,
          autoAlpha: 0,
          duration: 0.2,
          ease: 'power3.in',
          stagger: 0.03,
          onComplete: () => {
            this.menuOverlay.classList.remove('active');
          }
        });
      } else {
        // Fallback sans GSAP
        this.pillLinks.forEach(link => {
          link.style.opacity = '0';
          link.style.transform = 'scale(0)';
        });
        setTimeout(() => {
          this.menuOverlay.classList.remove('active');
        }, 200);
      }

      // Accessibility
      this.menuBtn.setAttribute('aria-expanded', 'false');
    }

    setupSmoothScroll() {
      // Smooth scroll pour les ancres
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
          const href = anchor.getAttribute('href');
          if (href && href !== '#' && href.length > 1) {
            const target = document.querySelector(href);
            if (target) {
              e.preventDefault();
              this.smoothScrollTo(target);
            }
          }
        });
      });
    }

    smoothScrollTo(target) {
      const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - 100;
      const startPosition = window.pageYOffset;
      const distance = targetPosition - startPosition;
      const duration = 800;
      let startTime = null;

      const animation = (currentTime) => {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const progress = Math.min(timeElapsed / duration, 1);
        
        // Easing cubic
        const ease = progress < 0.5
          ? 4 * progress * progress * progress
          : 1 - Math.pow(-2 * progress + 2, 3) / 2;

        window.scrollTo(0, startPosition + distance * ease);

        if (timeElapsed < duration) {
          requestAnimationFrame(animation);
        }
      };

      requestAnimationFrame(animation);
    }

    setupFallback() {
      // Version sans GSAP (fallback)
      console.log('⚠️ Mode fallback sans GSAP');
      
      this.menuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggleFallback();
      });
    }

    toggleFallback() {
      this.isOpen = !this.isOpen;
      
      if (this.isOpen) {
        this.menuBtn.classList.add('open');
        this.menuOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      } else {
        this.menuBtn.classList.remove('open');
        this.menuOverlay.classList.remove('active');
        document.body.style.overflow = '';
      }
    }
  }

  // ===== NAVIGATION STICKY =====
  class StickyNav {
    constructor() {
      this.nav = document.querySelector('.bubble-menu');
      this.lastScroll = 0;
      this.init();
    }

    init() {
      if (!this.nav) return;

      window.addEventListener('scroll', () => {
        this.handleScroll();
      }, { passive: true });
    }

    handleScroll() {
      const currentScroll = window.pageYOffset;

      // Ajouter classe scrolled si > 50px
      if (currentScroll > 50) {
        this.nav.classList.add('scrolled');
      } else {
        this.nav.classList.remove('scrolled');
      }

      this.lastScroll = currentScroll;
    }
  }

  // ===== REVEAL ANIMATIONS =====
  class RevealOnScroll {
    constructor() {
      this.elements = document.querySelectorAll('.reveal-element');
      this.observer = null;
      this.init();
    }

    init() {
      if (!this.elements.length) return;

      // IntersectionObserver
      this.observer = new IntersectionObserver(
        (entries) => this.handleIntersection(entries),
        {
          rootMargin: '0px 0px -10% 0px',
          threshold: 0.1
        }
      );

      this.elements.forEach(el => {
        this.observer.observe(el);
      });
    }

    handleIntersection(entries) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          this.observer.unobserve(entry.target);
        }
      });
    }
  }

  // ===== BACK TO TOP BUTTON =====
  class BackToTop {
    constructor() {
      this.button = this.createButton();
      this.init();
    }

    createButton() {
      const btn = document.createElement('button');
      btn.className = 'back-to-top';
      btn.innerHTML = '<i class="fas fa-arrow-up"></i>';
      btn.setAttribute('aria-label', 'Retour en haut');
      
      // Styles inline
      Object.assign(btn.style, {
        position: 'fixed',
        bottom: '2rem',
        right: '2rem',
        width: '48px',
        height: '48px',
        background: 'var(--primary-blue)',
        color: 'white',
        border: 'none',
        borderRadius: '50%',
        cursor: 'pointer',
        boxShadow: '0 4px 20px rgba(0, 102, 255, 0.4)',
        opacity: '0',
        visibility: 'hidden',
        transform: 'translateY(20px)',
        transition: 'all 0.3s ease',
        zIndex: '1000',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '1.25rem'
      });
      
      document.body.appendChild(btn);
      return btn;
    }

    init() {
      // Show/hide on scroll
      window.addEventListener('scroll', () => {
        if (window.pageYOffset > 500) {
          this.button.style.opacity = '1';
          this.button.style.visibility = 'visible';
          this.button.style.transform = 'translateY(0)';
        } else {
          this.button.style.opacity = '0';
          this.button.style.visibility = 'hidden';
          this.button.style.transform = 'translateY(20px)';
        }
      }, { passive: true });

      // Click handler
      this.button.addEventListener('click', () => {
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      });

      // Hover effect
      this.button.addEventListener('mouseenter', () => {
        this.button.style.transform = 'translateY(-4px)';
        this.button.style.boxShadow = '0 6px 30px rgba(0, 102, 255, 0.6)';
      });

      this.button.addEventListener('mouseleave', () => {
        this.button.style.transform = 'translateY(0)';
        this.button.style.boxShadow = '0 4px 20px rgba(0, 102, 255, 0.4)';
      });
    }
  }

  // ===== LAZY LOADING IMAGES =====
  class LazyLoader {
    constructor() {
      this.images = document.querySelectorAll('img[data-src], img[loading="lazy"]');
      this.observer = null;
      this.init();
    }

    init() {
      if (!this.images.length) return;

      this.observer = new IntersectionObserver(
        (entries) => this.handleIntersection(entries),
        {
          rootMargin: '50px 0px',
          threshold: 0.01
        }
      );

      this.images.forEach(img => {
        this.observer.observe(img);
      });
    }

    handleIntersection(entries) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          
          if (img.dataset.src) {
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
          }

          this.observer.unobserve(img);
        }
      });
    }
  }

  // ===== PERFORMANCE MONITOR (DEBUG) =====
  class PerformanceMonitor {
    constructor() {
      this.isDebug = window.location.search.includes('debug');
      if (this.isDebug) {
        this.init();
      }
    }

    init() {
      const monitor = document.createElement('div');
      Object.assign(monitor.style, {
        position: 'fixed',
        bottom: '20px',
        left: '20px',
        background: 'rgba(0, 0, 0, 0.8)',
        color: '#0F0',
        padding: '10px 15px',
        borderRadius: '8px',
        fontFamily: 'monospace',
        fontSize: '12px',
        zIndex: '10000'
      });
      document.body.appendChild(monitor);

      let lastTime = performance.now();
      let frames = 0;

      const updateFPS = () => {
        const currentTime = performance.now();
        frames++;

        if (currentTime >= lastTime + 1000) {
          const fps = Math.round((frames * 1000) / (currentTime - lastTime));
          monitor.textContent = `FPS: ${fps}`;
          frames = 0;
          lastTime = currentTime;
        }

        requestAnimationFrame(updateFPS);
      };

      requestAnimationFrame(updateFPS);
    }
  }

  // ===== INFINITE SCROLLER (PARTENAIRES) =====
  class InfiniteScroller {
    constructor() {
      this.scroller = document.querySelector('.horizontal-scroller');
      this.track = document.querySelector('.horizontal-scroller-track');
      
      if (!this.scroller || !this.track) {
        return;
      }
      
      this.init();
    }
    
    init() {
      // Dupliquer les items pour un scroll infini sans coupure
      const items = Array.from(this.track.children);
      
      // Cloner tous les items et les ajouter à la fin
      items.forEach(item => {
        const clone = item.cloneNode(true);
        this.track.appendChild(clone);
      });
      
      // Cloner encore une fois pour assurer la fluidité
      items.forEach(item => {
        const clone = item.cloneNode(true);
        this.track.appendChild(clone);
      });
      
      console.log('✅ Infinite scroller initialisé avec ' + (items.length * 3) + ' items');
      
      // Pause au hover
      this.scroller.addEventListener('mouseenter', () => {
        this.track.style.animationPlayState = 'paused';
      });
      
      this.scroller.addEventListener('mouseleave', () => {
        this.track.style.animationPlayState = 'running';
      });
    }
  }

  // ===== INITIALISATION =====
  function init() {
    // Attendre que le DOM soit chargé
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
      return;
    }

    console.log('🚀 Initialisation WebCreation...');

    // Initialiser tous les modules
    try {
      new BubbleMenu();
      new StickyNav();
      new RevealOnScroll();
      new BackToTop();
      new LazyLoader();
      new InfiniteScroller(); // 👈 NOUVEAU
      new PerformanceMonitor();

      console.log('✅ Tous les modules initialisés avec succès');
    } catch (error) {
      console.error('❌ Erreur lors de l\'initialisation:', error);
    }
  }

  // Démarrer
  init();

})();
