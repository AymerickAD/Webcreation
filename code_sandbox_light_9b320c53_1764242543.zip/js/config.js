// ==========================================
// Mad'ia - Configuration
// ==========================================

// 🔑 Google OAuth Configuration
// ⚠️ IMPORTANT: Remplacez par votre vrai Client ID après l'avoir obtenu sur Google Cloud Console
// Guide complet dans GOOGLE_OAUTH_SETUP.md

const CONFIG = {
    // Google OAuth Client ID
    // Pour obtenir votre Client ID : https://console.cloud.google.com/
    GOOGLE_CLIENT_ID: '834495282347-hechvi8dcktora033m99ufri7q10mjf0.apps.googleusercontent.com',
    
    // Scopes demandés à Google
    GOOGLE_SCOPES: [
        'openid',
        'profile',
        'email',
        'https://www.googleapis.com/auth/calendar.events.readonly'
    ].join(' '),

    // URL publique du calendrier de rendez-vous Google (Planning de rendez-vous)
    GOOGLE_CALENDAR_BOOKING_URL: 'https://calendar.google.com/calendar/u/0/appointments/schedules/YOUR_SCHEDULE_ID',

    // Discovery docs requis pour l'API Calendar (OAuth côté client)
    GOOGLE_API_DISCOVERY_DOCS: [
        'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'
    ],
    
    // Email de contact
    CONTACT_EMAIL: 'dansicare.aymerickpro@gmail.com',
    
    // URLs de redirection après connexion
    REDIRECT_AFTER_LOGIN: 'dashboard.html',
    REDIRECT_AFTER_LOGOUT: 'index.html',
    
    // Configuration du site
    SITE_NAME: 'Mad\'ia Digital Solutions',
    SITE_URL: window.location.origin
};

// Vérifier si le Client ID est configuré
if (CONFIG.GOOGLE_CLIENT_ID === 'VOTRE_CLIENT_ID_ICI.apps.googleusercontent.com') {
    console.warn('⚠️ Google OAuth n\'est pas encore configuré !');
    console.warn('📖 Consultez le fichier GOOGLE_OAUTH_SETUP.md pour les instructions.');
    console.warn('🔑 Obtenez votre Client ID sur : https://console.cloud.google.com/');
}

if (CONFIG.GOOGLE_CALENDAR_BOOKING_URL.includes('YOUR_SCHEDULE_ID')) {
    console.warn('⚠️ L\'URL de prise de rendez-vous Google Calendar n\'est pas définie.');
    console.warn('👉 Remplacez GOOGLE_CALENDAR_BOOKING_URL par le lien "Publier" de votre planning de rendez-vous.');
}

// Export de la configuration
window.CONFIG = CONFIG;