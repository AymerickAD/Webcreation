/* ========================================
   SCROLL ENGINE V9
   Performance-optimized scroll animations
   GPU-accelerated, IntersectionObserver
   ======================================== */

(function() {
  'use strict';

  // ===== CONFIGURATION =====
  const CONFIG = {
    rootMargin: '0px 0px -10% 0px',
    threshold: [0, 0.25, 0.5, 0.75, 1],
    animationDelay: 100,
    smoothScrollDuration: 800,
    parallaxIntensity: 0.3,
    isMobile: window.innerWidth <= 768,
    reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches
  };

  // ===== UTILITIES =====
  const Utils = {
    // Debounce function
    debounce(func, wait) {
      let timeout;
      return function executedFunction(...args) {
        const later = () => {
          clearTimeout(timeout);
          func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
      };
    },

    // Throttle function
    throttle(func, limit) {
      let inThrottle;
      return function(...args) {
        if (!inThrottle) {
          func.apply(this, args);
          inThrottle = true;
          setTimeout(() => inThrottle = false, limit);
        }
      };
    },

    // Check if element is in viewport
    isInViewport(el, offset = 0) {
      const rect = el.getBoundingClientRect();
      return (
        rect.top >= -offset &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) + offset
      );
    },

    // Smooth scroll to element
    smoothScrollTo(target, duration = CONFIG.smoothScrollDuration) {
      const targetEl = typeof target === 'string' ? document.querySelector(target) : target;
      if (!targetEl) return;

      const targetPosition = targetEl.getBoundingClientRect().top + window.pageYOffset - 80;
      const startPosition = window.pageYOffset;
      const distance = targetPosition - startPosition;
      let startTime = null;

      const animation = (currentTime) => {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const progress = Math.min(timeElapsed / duration, 1);
        
        // Easing function (cubic ease-in-out)
        const ease = progress < 0.5
          ? 4 * progress * progress * progress
          : 1 - Math.pow(-2 * progress + 2, 3) / 2;

        window.scrollTo(0, startPosition + distance * ease);

        if (timeElapsed < duration) {
          requestAnimationFrame(animation);
        }
      };

      requestAnimationFrame(animation);
    }
  };

  // ===== SCROLL REVEAL ANIMATIONS =====
  class ScrollReveal {
    constructor() {
      this.elements = [];
      this.observer = null;
      this.init();
    }

    init() {
      // Désactiver si motion réduite
      if (CONFIG.reducedMotion) {
        this.revealAll();
        return;
      }

      // Sélectionner tous les éléments à révéler
      const selectors = [
        '.reveal-element',
        '.argument-content',
        '.argument-visual',
        '.timeline-item',
        '.pricing-card',
        '.trust-card',
        '.feature-item'
      ];

      selectors.forEach(selector => {
        const els = document.querySelectorAll(selector);
        els.forEach(el => {
          if (!el.classList.contains('revealed')) {
            this.elements.push(el);
          }
        });
      });

      // Créer l'IntersectionObserver
      this.observer = new IntersectionObserver(
        (entries) => this.handleIntersection(entries),
        {
          rootMargin: CONFIG.rootMargin,
          threshold: CONFIG.threshold
        }
      );

      // Observer tous les éléments
      this.elements.forEach(el => this.observer.observe(el));
    }

    handleIntersection(entries) {
      entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRatio > 0.1) {
          // Ajouter la classe revealed
          entry.target.classList.add('revealed');
          
          // Arrêter d'observer cet élément
          this.observer.unobserve(entry.target);
        }
      });
    }

    revealAll() {
      // Révéler immédiatement tous les éléments
      this.elements.forEach(el => {
        el.classList.add('revealed');
        el.style.opacity = '1';
        el.style.transform = 'none';
      });
    }

    destroy() {
      if (this.observer) {
        this.observer.disconnect();
      }
    }
  }

  // ===== NAVIGATION SCROLL BEHAVIOR =====
  class Navigation {
    constructor() {
      this.nav = document.querySelector('.nav');
      this.navToggle = document.querySelector('.nav-toggle');
      this.navMenu = document.querySelector('.nav-menu');
      this.navLinks = document.querySelectorAll('.nav-link');
      this.lastScroll = 0;
      this.init();
    }

    init() {
      if (!this.nav) return;

      // Scroll behavior
      window.addEventListener('scroll', Utils.throttle(() => this.handleScroll(), 100), { passive: true });

      // Menu toggle (mobile)
      if (this.navToggle && this.navMenu) {
        this.navToggle.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleMenu();
        });

        // Fermer menu au clic sur un lien
        this.navLinks.forEach(link => {
          link.addEventListener('click', () => {
            if (this.navMenu.classList.contains('active')) {
              this.toggleMenu();
            }
          });
        });

        // Fermer menu au clic en dehors
        document.addEventListener('click', (e) => {
          if (this.navMenu.classList.contains('active') && 
              !this.navMenu.contains(e.target) && 
              !this.navToggle.contains(e.target)) {
            this.toggleMenu();
          }
        });
      }

      // Smooth scroll pour les liens d'ancrage
      this.navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
          const href = link.getAttribute('href');
          if (href && href.startsWith('#')) {
            e.preventDefault();
            Utils.smoothScrollTo(href);
          }
        });
      });
    }

    handleScroll() {
      const currentScroll = window.pageYOffset;

      // Ajouter classe scrolled
      if (currentScroll > 50) {
        this.nav.classList.add('scrolled');
      } else {
        this.nav.classList.remove('scrolled');
      }

      this.lastScroll = currentScroll;
    }

    toggleMenu() {
      const isActive = this.navMenu.classList.toggle('active');
      this.navToggle.classList.toggle('active');
      
      // Bloquer scroll du body quand menu ouvert
      document.body.style.overflow = isActive ? 'hidden' : '';
      
      // Accessibility
      this.navToggle.setAttribute('aria-expanded', isActive);
    }
  }

  // ===== PARALLAX EFFECT (DESKTOP ONLY) =====
  class Parallax {
    constructor() {
      this.elements = [];
      this.init();
    }

    init() {
      // Désactiver sur mobile ou si motion réduite
      if (CONFIG.isMobile || CONFIG.reducedMotion) return;

      // Sélectionner éléments parallax
      this.elements = Array.from(document.querySelectorAll('.gradient-orb'));

      if (this.elements.length === 0) return;

      // Écouter le scroll
      window.addEventListener('scroll', Utils.throttle(() => this.update(), 16), { passive: true });
    }

    update() {
      const scrolled = window.pageYOffset;

      this.elements.forEach((el, index) => {
        const speed = CONFIG.parallaxIntensity * (index + 1);
        const yPos = -(scrolled * speed);
        
        // Utiliser transform pour GPU acceleration
        el.style.transform = `translate3d(0, ${yPos}px, 0)`;
      });
    }
  }

  // ===== PRICING TOGGLE =====
  class PricingToggle {
    constructor() {
      this.toggleBtns = document.querySelectorAll('.pricing-toggle-btn');
      this.pricingCards = document.querySelectorAll('.pricing-card');
      this.init();
    }

    init() {
      if (this.toggleBtns.length === 0) return;

      this.toggleBtns.forEach(btn => {
        btn.addEventListener('click', () => this.handleToggle(btn));
      });
    }

    handleToggle(activeBtn) {
      const billingType = activeBtn.dataset.billing;

      // Update active state
      this.toggleBtns.forEach(btn => btn.classList.remove('active'));
      activeBtn.classList.add('active');

      // Update pricing display (implementation depends on your data structure)
      this.updatePricing(billingType);
    }

    updatePricing(billingType) {
      // Cette fonction peut être personnalisée selon vos besoins
      // Par exemple, afficher/cacher des prix différents
      console.log('Billing type changed to:', billingType);
    }
  }

  // ===== FAQ ACCORDION =====
  class FAQAccordion {
    constructor() {
      this.faqItems = document.querySelectorAll('.faq-item');
      this.init();
    }

    init() {
      if (this.faqItems.length === 0) return;

      this.faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        if (question) {
          question.addEventListener('click', () => this.toggleItem(item));
        }
      });
    }

    toggleItem(item) {
      const isActive = item.classList.contains('active');

      // Fermer tous les autres items
      this.faqItems.forEach(faq => {
        if (faq !== item) {
          faq.classList.remove('active');
        }
      });

      // Toggle l'item cliqué
      item.classList.toggle('active');
    }
  }

  // ===== SMOOTH SCROLL LINKS =====
  class SmoothScrollLinks {
    constructor() {
      this.links = document.querySelectorAll('a[href^="#"]');
      this.init();
    }

    init() {
      this.links.forEach(link => {
        link.addEventListener('click', (e) => {
          const href = link.getAttribute('href');
          if (href && href !== '#' && href.length > 1) {
            const target = document.querySelector(href);
            if (target) {
              e.preventDefault();
              Utils.smoothScrollTo(target);
            }
          }
        });
      });
    }
  }

  // ===== BACK TO TOP BUTTON =====
  class BackToTop {
    constructor() {
      this.button = this.createButton();
      this.init();
    }

    createButton() {
      const btn = document.createElement('button');
      btn.className = 'back-to-top';
      btn.innerHTML = '<i class="fas fa-arrow-up"></i>';
      btn.setAttribute('aria-label', 'Retour en haut');
      document.body.appendChild(btn);
      return btn;
    }

    init() {
      // Show/hide sur scroll
      window.addEventListener('scroll', Utils.throttle(() => {
        if (window.pageYOffset > 500) {
          this.button.classList.add('visible');
        } else {
          this.button.classList.remove('visible');
        }
      }, 200), { passive: true });

      // Click handler
      this.button.addEventListener('click', () => {
        Utils.smoothScrollTo('body', 600);
      });
    }
  }

  // ===== LAZY LOADING IMAGES =====
  class LazyLoader {
    constructor() {
      this.images = [];
      this.observer = null;
      this.init();
    }

    init() {
      // Sélectionner toutes les images avec data-src
      this.images = document.querySelectorAll('img[data-src], img[loading="lazy"]');

      if (this.images.length === 0) return;

      // Utiliser IntersectionObserver
      this.observer = new IntersectionObserver(
        (entries) => this.handleIntersection(entries),
        {
          rootMargin: '50px 0px',
          threshold: 0.01
        }
      );

      this.images.forEach(img => this.observer.observe(img));
    }

    handleIntersection(entries) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          
          // Charger l'image
          if (img.dataset.src) {
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
          }

          // Arrêter d'observer
          this.observer.unobserve(img);
        }
      });
    }
  }

  // ===== PERFORMANCE MONITOR (DEV MODE) =====
  class PerformanceMonitor {
    constructor() {
      this.isDebug = window.location.search.includes('debug');
      if (this.isDebug) {
        this.init();
      }
    }

    init() {
      const monitor = document.createElement('div');
      monitor.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: rgba(0, 0, 0, 0.8);
        color: #0F0;
        padding: 10px 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        z-index: 10000;
      `;
      document.body.appendChild(monitor);

      let lastTime = performance.now();
      let frames = 0;

      const updateFPS = () => {
        const currentTime = performance.now();
        frames++;

        if (currentTime >= lastTime + 1000) {
          const fps = Math.round((frames * 1000) / (currentTime - lastTime));
          monitor.textContent = `FPS: ${fps}`;
          frames = 0;
          lastTime = currentTime;
        }

        requestAnimationFrame(updateFPS);
      };

      requestAnimationFrame(updateFPS);
    }
  }

  // ===== CSS POUR BACK TO TOP =====
  const backToTopStyles = document.createElement('style');
  backToTopStyles.textContent = `
    .back-to-top {
      position: fixed;
      bottom: 2rem;
      right: 2rem;
      width: 48px;
      height: 48px;
      background: var(--primary-blue);
      color: white;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      box-shadow: 0 4px 20px rgba(0, 102, 255, 0.4);
      opacity: 0;
      visibility: hidden;
      transform: translateY(20px);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.25rem;
    }

    .back-to-top.visible {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }

    .back-to-top:hover {
      background: #0052CC;
      transform: translateY(-4px);
      box-shadow: 0 6px 30px rgba(0, 102, 255, 0.6);
    }

    .back-to-top:active {
      transform: translateY(-2px);
    }
  `;
  document.head.appendChild(backToTopStyles);

  // ===== INITIALIZATION =====
  const init = () => {
    // Vérifier que le DOM est chargé
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
      return;
    }

    // Initialiser tous les modules
    new ScrollReveal();
    new Navigation();
    new Parallax();
    new PricingToggle();
    new FAQAccordion();
    new SmoothScrollLinks();
    new BackToTop();
    new LazyLoader();
    new PerformanceMonitor();

    // Log pour debug
    console.log('✅ Scroll Engine V9 initialisé');
  };

  // Démarrer
  init();

})();
