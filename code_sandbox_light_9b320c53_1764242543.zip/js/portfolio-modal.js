/**
 * PORTFOLIO MODAL SYSTEM - v3.3
 * Système de gestion des popups de réalisations
 * Aymerick - WebCreation Pro
 */

// Base de données des projets avec détails complets
const projectsData = {
    'bistrot-gourmet': {
        id: 'bistrot-gourmet',
        title: 'Le Bistrot Gourmet',
        subtitle: 'Restaurant gastronomique français',
        category: 'Site vitrine',
        image: 'images/portfolio/bistrot-gourmet-full.jpg',
        client: 'Le Bistrot Gourmet, Paris 8ème',
        duration: '6 semaines',
        year: '2024',
        url: '#',
        description: 'Création complète d\'un site vitrine moderne pour un restaurant gastronomique parisien. Le projet incluait une refonte complète de l\'identité visuelle en ligne, l\'intégration d\'un système de réservation en temps réel, et une galerie photos professionnelle mettant en valeur la cuisine du chef.',
        challenge: 'Le principal défi était de transmettre l\'élégance et le raffinement du restaurant tout en assurant une expérience utilisateur fluide sur mobile, sachant que 70% des réservations se font depuis un smartphone.',
        solution: 'Nous avons opté pour un design épuré avec des visuels haute qualité, une palette de couleurs chaudes (bordeaux, crème, doré), et un système de réservation intégré avec confirmation instantanée par email et SMS.',
        technologies: [
            { name: 'HTML5', icon: 'fab fa-html5' },
            { name: 'CSS3', icon: 'fab fa-css3-alt' },
            { name: 'JavaScript', icon: 'fab fa-js' },
            { name: 'PHP', icon: 'fab fa-php' },
            { name: 'MySQL', icon: 'fas fa-database' }
        ],
        features: [
            {
                icon: 'fas fa-utensils',
                title: 'Menu interactif',
                description: 'Carte des plats avec photos HD, allergènes et suggestions d\'accord mets-vins'
            },
            {
                icon: 'fas fa-calendar-check',
                title: 'Réservation en ligne',
                description: 'Système de booking temps réel avec sélection de tables et confirmation instantanée'
            },
            {
                icon: 'fas fa-images',
                title: 'Galerie photos',
                description: 'Showcase professionnel des plats, de l\'ambiance et de l\'équipe'
            },
            {
                icon: 'fas fa-mobile-alt',
                title: '100% Responsive',
                description: 'Optimisé pour tous les appareils avec touch gestures sur mobile'
            },
            {
                icon: 'fas fa-search',
                title: 'SEO optimisé',
                description: 'Référencement local optimisé pour "restaurant Paris 8ème"'
            },
            {
                icon: 'fas fa-tachometer-alt',
                title: 'Performance',
                description: 'Temps de chargement < 2s avec images optimisées et lazy loading'
            }
        ],
        results: [
            {
                icon: 'fas fa-chart-line',
                value: '+85%',
                label: 'Réservations en ligne'
            },
            {
                icon: 'fas fa-star',
                value: '4.8/5',
                label: 'Satisfaction clients'
            },
            {
                icon: 'fas fa-bolt',
                value: '92/100',
                label: 'PageSpeed Score'
            },
            {
                icon: 'fas fa-users',
                value: '+120%',
                label: 'Trafic web'
            }
        ],
        testimonial: {
            text: 'WebCreation Pro a parfaitement capturé l\'essence de notre restaurant. Le site est élégant, facile à utiliser, et nous avons constaté une augmentation significative des réservations en ligne dès la première semaine de lancement.',
            author: 'Jean-Pierre Durand',
            role: 'Chef & Propriétaire',
            avatar: 'JP'
        },
        timeline: [
            { date: 'Semaine 1', title: 'Analyse & Stratégie', description: 'Audit de la concurrence, définition du positionnement et wireframes' },
            { date: 'Semaine 2-3', title: 'Design & Maquettes', description: 'Création des maquettes haute fidélité et validation client' },
            { date: 'Semaine 4-5', title: 'Développement', description: 'Intégration front-end et back-end, système de réservation' },
            { date: 'Semaine 6', title: 'Tests & Lancement', description: 'Tests utilisateurs, corrections et mise en ligne' }
        ]
    },
    
    'style-co': {
        id: 'style-co',
        title: 'Style & Co',
        subtitle: 'E-commerce mode & accessoires',
        category: 'E-commerce',
        image: 'images/portfolio/style-co-full.jpg',
        client: 'Style & Co, Boutique en ligne',
        duration: '10 semaines',
        year: '2024',
        url: '#',
        description: 'Développement d\'une boutique e-commerce complète pour une marque de prêt-à-porter féminin. Le projet incluait la création d\'un catalogue produits de 300+ articles, l\'intégration de paiements sécurisés Stripe, un système de gestion des stocks en temps réel, et un programme de fidélité.',
        challenge: 'Créer une expérience d\'achat en ligne convaincante dans un marché ultra-compétitif, avec un taux de conversion élevé et une interface qui met en valeur les produits tout en restant performante.',
        solution: 'Architecture WooCommerce customisée avec filtres avancés, wishlist, recommandations personnalisées basées sur l\'historique, et checkout optimisé en 3 étapes. Design minimaliste qui met le produit au centre.',
        technologies: [
            { name: 'WordPress', icon: 'fab fa-wordpress' },
            { name: 'WooCommerce', icon: 'fab fa-shopify' },
            { name: 'Stripe', icon: 'fab fa-cc-stripe' },
            { name: 'PHP', icon: 'fab fa-php' },
            { name: 'JavaScript', icon: 'fab fa-js' }
        ],
        features: [
            {
                icon: 'fas fa-shopping-cart',
                title: 'Panier intelligent',
                description: 'Suggestions de produits complémentaires et sauvegarde automatique'
            },
            {
                icon: 'fas fa-credit-card',
                title: 'Paiements sécurisés',
                description: 'Stripe, PayPal, CB avec 3D Secure et certificat SSL'
            },
            {
                icon: 'fas fa-box',
                title: 'Gestion stocks',
                description: 'Suivi en temps réel avec alertes automatiques de rupture'
            },
            {
                icon: 'fas fa-gift',
                title: 'Programme fidélité',
                description: 'Points de récompense et codes promo personnalisés'
            },
            {
                icon: 'fas fa-truck',
                title: 'Suivi livraison',
                description: 'Tracking en temps réel avec notifications SMS/email'
            },
            {
                icon: 'fas fa-filter',
                title: 'Filtres avancés',
                description: 'Recherche par taille, couleur, prix, tendance avec résultats instantanés'
            }
        ],
        results: [
            {
                icon: 'fas fa-euro-sign',
                value: '45K€',
                label: 'CA mensuel moyen'
            },
            {
                icon: 'fas fa-shopping-bag',
                value: '150+',
                label: 'Commandes/mois'
            },
            {
                icon: 'fas fa-percentage',
                value: '3.8%',
                label: 'Taux de conversion'
            },
            {
                icon: 'fas fa-heart',
                value: '4.5/5',
                label: 'Satisfaction'
            }
        ],
        testimonial: {
            text: 'Nous voulions une boutique en ligne qui reflète l\'élégance de notre marque. WebCreation Pro a dépassé nos attentes avec un site magnifique, rapide, et qui convertit vraiment. Les ventes en ligne représentent maintenant 60% de notre chiffre d\'affaires.',
            author: 'Sophie Leclerc',
            role: 'Fondatrice Style & Co',
            avatar: 'SL'
        },
        timeline: [
            { date: 'Semaine 1-2', title: 'Architecture & UX', description: 'Définition du parcours client et arborescence' },
            { date: 'Semaine 3-4', title: 'Design UI', description: 'Maquettes desktop & mobile, charte graphique' },
            { date: 'Semaine 5-7', title: 'Développement', description: 'Intégration WooCommerce, paiements, gestion stocks' },
            { date: 'Semaine 8-9', title: 'Catalogue produits', description: 'Import des 300+ produits avec photos et descriptions' },
            { date: 'Semaine 10', title: 'Tests & Formation', description: 'Tests de charge, formation client, mise en ligne' }
        ]
    },
    
    'conseil-partners': {
        id: 'conseil-partners',
        title: 'Conseil & Partners',
        subtitle: 'Cabinet de conseil en stratégie',
        category: 'Corporate',
        image: 'images/portfolio/conseil-partners-full.jpg',
        client: 'Conseil & Partners, Paris La Défense',
        duration: '8 semaines',
        year: '2023',
        url: '#',
        description: 'Refonte complète du site institutionnel d\'un cabinet de conseil en stratégie d\'entreprise. L\'objectif était de moderniser l\'image de marque, améliorer la génération de leads, et positionner le cabinet comme leader d\'opinion via un blog expert.',
        challenge: 'Transmettre professionnalisme et expertise tout en créant une expérience engageante. Le site devait également être un outil de génération de leads qualifiés pour les consultants.',
        solution: 'Design corporate moderne avec animations subtiles, sections de présentation des services détaillées, études de cas clients (anonymisées), blog d\'expertise optimisé SEO, et formulaires de contact intelligents avec qualification automatique des leads.',
        technologies: [
            { name: 'WordPress', icon: 'fab fa-wordpress' },
            { name: 'HTML5', icon: 'fab fa-html5' },
            { name: 'CSS3', icon: 'fab fa-css3-alt' },
            { name: 'JavaScript', icon: 'fab fa-js' },
            { name: 'PHP', icon: 'fab fa-php' }
        ],
        features: [
            {
                icon: 'fas fa-briefcase',
                title: 'Présentation services',
                description: 'Pages détaillées pour chaque offre avec cas d\'usage et méthodologie'
            },
            {
                icon: 'fas fa-blog',
                title: 'Blog expert',
                description: 'Publication d\'articles de fond optimisés SEO avec CTA intégrés'
            },
            {
                icon: 'fas fa-users',
                title: 'Équipe & expertises',
                description: 'Profils détaillés des consultants avec spécialisations'
            },
            {
                icon: 'fas fa-envelope',
                title: 'Formulaires qualifiés',
                description: 'Questions intelligentes pour qualifier les demandes automatiquement'
            },
            {
                icon: 'fas fa-lock',
                title: 'Sécurité SSL',
                description: 'Certificat SSL, protection anti-spam et conformité RGPD'
            },
            {
                icon: 'fas fa-chart-bar',
                title: 'Analytics avancés',
                description: 'Tracking des conversions et heatmaps comportementales'
            }
        ],
        results: [
            {
                icon: 'fas fa-search',
                value: '+120%',
                label: 'Trafic SEO organique'
            },
            {
                icon: 'fas fa-envelope-open',
                value: '+95%',
                label: 'Leads qualifiés'
            },
            {
                icon: 'fas fa-shield-alt',
                value: 'A+',
                label: 'Score sécurité'
            },
            {
                icon: 'fas fa-clock',
                value: '1.8s',
                label: 'Temps de chargement'
            }
        ],
        testimonial: {
            text: 'Le nouveau site a transformé notre présence en ligne. Nous recevons maintenant des demandes de clients que nous n\'aurions jamais touchés auparavant. Le blog nous positionne comme experts et génère un flux constant de leads qualifiés.',
            author: 'Marc Dubois',
            role: 'Directeur Associé',
            avatar: 'MD'
        },
        timeline: [
            { date: 'Semaine 1-2', title: 'Audit & Stratégie', description: 'Analyse concurrentielle, personas, stratégie de contenu' },
            { date: 'Semaine 3-4', title: 'Design & Prototypes', description: 'Maquettes haute fidélité et prototype interactif' },
            { date: 'Semaine 5-6', title: 'Développement', description: 'Intégration WordPress, formulaires, blog' },
            { date: 'Semaine 7', title: 'Contenu & SEO', description: 'Rédaction, optimisation SEO, migration contenu' },
            { date: 'Semaine 8', title: 'Tests & Lancement', description: 'Tests de sécurité, performance, mise en production' }
        ]
    },
    
    'fitclub': {
        id: 'fitclub',
        title: 'FitClub',
        subtitle: 'Salle de sport & fitness',
        category: 'Sport & Santé',
        image: 'images/portfolio/fitclub-full.jpg',
        client: 'FitClub, Lyon 6ème',
        duration: '5 semaines',
        year: '2024',
        url: '#',
        description: 'Site vitrine moderne pour une salle de sport premium à Lyon. Le projet comprenait un planning des cours interactif en temps réel, un système d\'inscription en ligne, une galerie showcase de la salle et des équipements, et une section blog pour des conseils fitness.',
        challenge: 'Créer un site énergique et motivant qui donne envie de s\'inscrire, tout en facilitant la prise de rendez-vous et la consultation du planning des cours qui change chaque semaine.',
        solution: 'Design dynamique aux couleurs énergiques (orange/noir), planning interactif synchronisé avec Google Calendar, formulaire d\'inscription en 3 étapes avec essai gratuit, et galerie photo/vidéo immersive avec effet parallaxe.',
        technologies: [
            { name: 'HTML5', icon: 'fab fa-html5' },
            { name: 'CSS3', icon: 'fab fa-css3-alt' },
            { name: 'JavaScript', icon: 'fab fa-js' },
            { name: 'PHP', icon: 'fab fa-php' },
            { name: 'Google Calendar API', icon: 'fab fa-google' }
        ],
        features: [
            {
                icon: 'fas fa-calendar-alt',
                title: 'Planning en temps réel',
                description: 'Horaires des cours synchronisés avec réservation de places en ligne'
            },
            {
                icon: 'fas fa-dumbbell',
                title: 'Présentation équipements',
                description: 'Visite virtuelle 360° de la salle avec zoom sur machines'
            },
            {
                icon: 'fas fa-id-card',
                title: 'Inscription en ligne',
                description: 'Formulaire simple avec offre d\'essai gratuit et paiement sécurisé'
            },
            {
                icon: 'fas fa-video',
                title: 'Vidéos cours',
                description: 'Extraits vidéo des cours pour découvrir l\'ambiance'
            },
            {
                icon: 'fas fa-comments',
                title: 'Témoignages membres',
                description: 'Avis authentiques avec photos avant/après (avec consentement)'
            },
            {
                icon: 'fas fa-mobile-alt',
                title: 'App mobile ready',
                description: 'Interface optimisée pour consultation sur smartphone'
            }
        ],
        results: [
            {
                icon: 'fas fa-user-plus',
                value: '200+',
                label: 'Inscriptions en ligne'
            },
            {
                icon: 'fas fa-chart-line',
                value: '+65%',
                label: 'Trafic mensuel'
            },
            {
                icon: 'fas fa-mobile-alt',
                value: '95/100',
                label: 'Score mobile'
            },
            {
                icon: 'fas fa-star',
                value: '4.9/5',
                label: 'Avis clients'
            }
        ],
        testimonial: {
            text: 'Le nouveau site a complètement changé la donne. Les gens peuvent maintenant consulter les horaires, voir la salle en 360°, et s\'inscrire directement en ligne. On a rempli 80% de nos créneaux en moins de 2 mois !',
            author: 'Kévin Lambert',
            role: 'Manager FitClub Lyon',
            avatar: 'KL'
        },
        timeline: [
            { date: 'Semaine 1', title: 'Découverte & Brief', description: 'Visite sur site, photos/vidéos, définition des besoins' },
            { date: 'Semaine 2', title: 'Design & Maquettes', description: 'Création identité visuelle et maquettes' },
            { date: 'Semaine 3-4', title: 'Développement', description: 'Intégration, planning interactif, formulaires' },
            { date: 'Semaine 5', title: 'Contenu & Lancement', description: 'Import contenu, tests, formation et mise en ligne' }
        ]
    },
    
    'sophie-martin': {
        id: 'sophie-martin',
        title: 'Sophie Martin',
        subtitle: 'Photographe professionnelle',
        category: 'Portfolio',
        image: 'images/portfolio/sophie-martin-full.jpg',
        client: 'Sophie Martin, Photographe',
        duration: '4 semaines',
        year: '2023',
        url: '#',
        description: 'Portfolio en ligne pour une photographe professionnelle spécialisée en mariage, portrait et événementiel. L\'objectif était de créer une vitrine élégante mettant en valeur son travail avec une galerie optimisée, tout en facilitant la prise de contact et l\'obtention de devis.',
        challenge: 'Créer un portfolio qui fait ressortir la qualité artistique des photos sans compromettre la vitesse de chargement. La photographe avait également besoin d\'un système simple pour mettre à jour ses projets.',
        solution: 'Design minimaliste avec focus sur les images, galerie masonry avec lazy loading intelligent, intégration Instagram feed, formulaire de devis personnalisé selon le type de prestation, et back-office WordPress simplifié pour l\'autonomie.',
        technologies: [
            { name: 'WordPress', icon: 'fab fa-wordpress' },
            { name: 'HTML5', icon: 'fab fa-html5' },
            { name: 'CSS3', icon: 'fab fa-css3-alt' },
            { name: 'JavaScript', icon: 'fab fa-js' },
            { name: 'Lightbox', icon: 'fas fa-images' }
        ],
        features: [
            {
                icon: 'fas fa-images',
                title: 'Galerie masonry',
                description: 'Affichage élégant en mosaïque avec lightbox plein écran'
            },
            {
                icon: 'fas fa-folder-open',
                title: 'Catégories projets',
                description: 'Mariage, Portrait, Événementiel avec filtres rapides'
            },
            {
                icon: 'fab fa-instagram',
                title: 'Feed Instagram',
                description: 'Synchronisation automatique des dernières publications'
            },
            {
                icon: 'fas fa-file-invoice',
                title: 'Devis personnalisé',
                description: 'Formulaire adapté selon le type de shooting souhaité'
            },
            {
                icon: 'fas fa-bolt',
                title: 'Optimisation images',
                description: 'Compression intelligente sans perte de qualité visible'
            },
            {
                icon: 'fas fa-paint-brush',
                title: 'CMS simple',
                description: 'Interface d\'admin simplifiée pour ajout facile de projets'
            }
        ],
        results: [
            {
                icon: 'fas fa-envelope',
                value: '+180%',
                label: 'Demandes de devis'
            },
            {
                icon: 'fas fa-eye',
                value: '5000+',
                label: 'Visiteurs/mois'
            },
            {
                icon: 'fas fa-tachometer-alt',
                value: '98/100',
                label: 'Performance'
            },
            {
                icon: 'fas fa-mobile-alt',
                value: '100%',
                label: 'Mobile friendly'
            }
        ],
        testimonial: {
            text: 'Mon nouveau portfolio a transformé mon activité. Les clients potentiels peuvent maintenant voir tout mon travail organisé par catégorie, et je reçois beaucoup plus de demandes qualifiées. L\'interface d\'admin est tellement simple que je mets à jour mes projets moi-même !',
            author: 'Sophie Martin',
            role: 'Photographe professionnelle',
            avatar: 'SM'
        },
        timeline: [
            { date: 'Semaine 1', title: 'Sélection & Organisation', description: 'Tri des meilleures photos, catégorisation des projets' },
            { date: 'Semaine 2', title: 'Design Minimaliste', description: 'Maquettes épurées centrées sur les images' },
            { date: 'Semaine 3', title: 'Développement', description: 'Intégration WordPress, galerie, formulaires' },
            { date: 'Semaine 4', title: 'Import & Formation', description: 'Migration des photos, optimisation, formation CMS' }
        ]
    },
    
    'pharmacie-gambetta': {
        id: 'pharmacie-gambetta',
        title: 'Pharmacie Gambetta',
        subtitle: 'Site vitrine sécurisé et personnalisé',
        category: 'Site vitrine',
        image: 'images/portfolio/pharmacie-gambetta-full.jpg',
        client: 'Pharmacie Gambetta',
        duration: '5 semaines',
        year: '2024',
        url: '#',
        description: 'Création d\'un site vitrine moderne, sécurisé et conforme RGPD pour une pharmacie. Le projet incluait une présentation complète des services pharmaceutiques, un système de gestion des horaires dynamique, une section conseil santé et une intégration avec les réseaux sociaux de l\'établissement.',
        challenge: 'Les défis principaux étaient d\'assurer une sécurité maximale des données (conformité RGPD et certification SSL A+), de créer une interface rassurante et professionnelle adaptée au secteur de la santé, tout en permettant une gestion autonome du contenu par l\'équipe de la pharmacie.',
        solution: 'Nous avons développé un site avec un design médical moderne dans les tons verts et blancs, intégré un CMS facile d\'utilisation, mis en place un certificat SSL avec encryption renforcée, et créé une architecture d\'information claire pour guider les patients vers les informations essentielles (horaires, services, conseils).',
        technologies: [
            { name: 'HTML5', icon: 'fab fa-html5' },
            { name: 'CSS3', icon: 'fab fa-css3-alt' },
            { name: 'JavaScript', icon: 'fab fa-js' },
            { name: 'WordPress', icon: 'fab fa-wordpress' },
            { name: 'SSL/TLS', icon: 'fas fa-lock' }
        ],
        features: [
            {
                icon: 'fas fa-shield-alt',
                title: 'Sécurité renforcée',
                description: 'Certificat SSL A+, HTTPS forcé, protection contre les attaques XSS et CSRF'
            },
            {
                icon: 'fas fa-user-shield',
                title: 'Conformité RGPD',
                description: 'Gestion des cookies, politique de confidentialité, formulaires sécurisés'
            },
            {
                icon: 'fas fa-clock',
                title: 'Horaires dynamiques',
                description: 'Système de gestion des horaires avec affichage en temps réel et alertes fermetures exceptionnelles'
            },
            {
                icon: 'fas fa-pills',
                title: 'Services pharmaceutiques',
                description: 'Présentation détaillée des services : ordonnances, vaccinations, conseils personnalisés'
            },
            {
                icon: 'fas fa-newspaper',
                title: 'Blog santé',
                description: 'Section conseils et actualités santé avec articles validés par le pharmacien titulaire'
            },
            {
                icon: 'fas fa-mobile-alt',
                title: 'Mobile-first',
                description: 'Design 100% responsive optimisé pour consultations sur smartphone'
            }
        ],
        results: [
            {
                icon: 'fas fa-lock',
                value: 'SSL A+',
                label: 'Sécurité maximale'
            },
            {
                icon: 'fas fa-tachometer-alt',
                value: '95/100',
                label: 'PageSpeed Desktop'
            },
            {
                icon: 'fas fa-mobile',
                value: '92/100',
                label: 'PageSpeed Mobile'
            },
            {
                icon: 'fas fa-check-circle',
                value: 'RGPD',
                label: 'Conformité totale'
            }
        ],
        testimonial: {
            text: 'Le site créé par WebCreation répond parfaitement à nos besoins. Il est à la fois moderne, sécurisé et facile à mettre à jour. Nos patients trouvent facilement les informations dont ils ont besoin, et nous avons constaté une augmentation des demandes via le formulaire de contact.',
            author: 'Dr. Marie Lefebvre',
            role: 'Pharmacienne titulaire',
            avatar: 'ML'
        },
        timeline: [
            { date: 'Semaine 1', title: 'Audit & Stratégie', description: 'Analyse concurrence, cahier des charges, définition sécurité' },
            { date: 'Semaine 2', title: 'Design & Maquettes', description: 'Création identité visuelle, maquettes desktop/mobile' },
            { date: 'Semaine 3-4', title: 'Développement', description: 'Intégration WordPress, sécurisation, RGPD, tests' },
            { date: 'Semaine 5', title: 'Formation & Lancement', description: 'Formation équipe, migration contenu, mise en ligne sécurisée' }
        ]
    }
};

/**
 * Classe principale de gestion des modals
 */
class PortfolioModal {
    constructor() {
        this.currentProject = null;
        this.overlay = null;
        this.init();
    }

    /**
     * Initialisation du système de modal
     */
    init() {
        // Créer l'overlay modal dans le DOM
        this.createModalOverlay();
        
        // Attacher les événements sur tous les boutons "Voir le projet"
        this.attachEventListeners();
        
        // Gérer la fermeture avec ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.overlay.classList.contains('active')) {
                this.close();
            }
        });
    }

    /**
     * Créer la structure HTML du modal
     */
    createModalOverlay() {
        const overlay = document.createElement('div');
        overlay.className = 'portfolio-modal-overlay';
        overlay.innerHTML = `
            <div class="portfolio-modal" role="dialog" aria-modal="true">
                <button class="modal-close" aria-label="Fermer">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
                <div class="modal-content"></div>
            </div>
        `;
        
        document.body.appendChild(overlay);
        this.overlay = overlay;

        // Fermer si clic sur l'overlay (pas sur le modal)
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                this.close();
            }
        });

        // Fermer avec le bouton X
        overlay.querySelector('.modal-close').addEventListener('click', () => {
            this.close();
        });
    }

    /**
     * Attacher les événements sur les boutons portfolio
     */
    attachEventListeners() {
        // Trouver tous les boutons "Voir le projet"
        const portfolioButtons = document.querySelectorAll('.overlay-btn');
        
        console.log(`🔍 Portfolio Modal: ${portfolioButtons.length} boutons trouvés`);
        
        portfolioButtons.forEach((button, index) => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                // Vérifier si le bouton a une classe spécifique pour identifier le projet
                if (button.classList.contains('btn-pharmacie-gambetta')) {
                    this.open('pharmacie-gambetta');
                    return;
                }
                
                // Sinon, déterminer quel projet ouvrir basé sur l'ordre dans le DOM
                const projectIds = Object.keys(projectsData);
                
                if (index < projectIds.length) {
                    this.open(projectIds[index]);
                }
            });
        });
        
        // SOLUTION ALTERNATIVE: Attacher aussi sur les cartes portfolio entières
        // Permet de cliquer n'importe où sur la carte pour ouvrir le modal
        const portfolioItems = document.querySelectorAll('.portfolio-item');
        console.log(`🔍 ${portfolioItems.length} cartes portfolio cliquables`);
        
        portfolioItems.forEach((item, index) => {
            item.style.cursor = 'pointer';
            item.addEventListener('click', (e) => {
                // Ne pas déclencher si on clique sur un lien ou bouton  
                if (e.target.tagName === 'A' || e.target.closest('a')) {
                    return;
                }
                
                const projectIds = Object.keys(projectsData);
                if (index < projectIds.length) {
                    this.open(projectIds[index]);
                }
            });
        });
    }

    /**
     * Ouvrir le modal avec un projet spécifique
     */
    open(projectId) {
        const project = projectsData[projectId];
        if (!project) {
            console.error(`Projet ${projectId} non trouvé`);
            return;
        }

        this.currentProject = project;
        this.render(project);
        
        // Afficher le modal avec animation
        setTimeout(() => {
            this.overlay.classList.add('active');
            document.body.classList.add('modal-open');
        }, 10);
    }

    /**
     * Fermer le modal
     */
    close() {
        this.overlay.classList.remove('active');
        document.body.classList.remove('modal-open');
        
        // Attendre la fin de l'animation avant de vider le contenu
        setTimeout(() => {
            this.currentProject = null;
        }, 400);
    }

    /**
     * Générer le HTML du contenu du modal
     */
    render(project) {
        const modalContent = this.overlay.querySelector('.modal-content');
        
        modalContent.innerHTML = `
            ${this.renderHeader(project)}
            ${this.renderBody(project)}
            ${this.renderFooter(project)}
        `;
    }

    /**
     * Générer l'en-tête du modal
     */
    renderHeader(project) {
        return `
            <div class="modal-header">
                <img src="${project.image}" alt="${project.title}" loading="eager">
                <div class="modal-header-overlay">
                    <h2 class="modal-project-title">${project.title}</h2>
                    <p class="modal-project-subtitle">${project.subtitle}</p>
                </div>
            </div>
        `;
    }

    /**
     * Générer le corps du modal
     */
    renderBody(project) {
        return `
            <div class="modal-body">
                <!-- Info Grid -->
                <div class="project-info-grid">
                    <div class="info-item">
                        <span class="info-label">Client</span>
                        <span class="info-value">${project.client.split(',')[0]}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Durée</span>
                        <span class="info-value">${project.duration}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Année</span>
                        <span class="info-value">${project.year}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Catégorie</span>
                        <span class="info-value">${project.category}</span>
                    </div>
                </div>

                <!-- Description -->
                <div class="modal-section">
                    <h3 class="modal-section-title">Le Projet</h3>
                    <p class="modal-description">${project.description}</p>
                </div>

                <!-- Challenge & Solution -->
                <div class="modal-section">
                    <h3 class="modal-section-title">Le Défi</h3>
                    <p class="modal-description">${project.challenge}</p>
                </div>

                <div class="modal-section">
                    <h3 class="modal-section-title">La Solution</h3>
                    <p class="modal-description">${project.solution}</p>
                </div>

                <!-- Technologies -->
                <div class="modal-section">
                    <h3 class="modal-section-title">Technologies Utilisées</h3>
                    <div class="technologies-list">
                        ${project.technologies.map(tech => `
                            <div class="tech-badge">
                                <i class="${tech.icon}"></i>
                                ${tech.name}
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Features -->
                <div class="modal-section">
                    <h3 class="modal-section-title">Fonctionnalités Clés</h3>
                    <div class="features-list">
                        ${project.features.map(feature => `
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="${feature.icon}"></i>
                                </div>
                                <div class="feature-content">
                                    <h4>${feature.title}</h4>
                                    <p>${feature.description}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Results -->
                <div class="modal-section">
                    <h3 class="modal-section-title">Résultats & Performance</h3>
                    <div class="results-grid">
                        ${project.results.map(result => `
                            <div class="result-card">
                                <i class="${result.icon} result-icon"></i>
                                <span class="result-value">${result.value}</span>
                                <span class="result-label">${result.label}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Testimonial -->
                ${project.testimonial ? `
                    <div class="modal-section">
                        <h3 class="modal-section-title">Témoignage Client</h3>
                        <div class="testimonial">
                            <p class="testimonial-text">"${project.testimonial.text}"</p>
                            <div class="testimonial-author">
                                <div class="author-avatar">${project.testimonial.avatar}</div>
                                <div class="author-info">
                                    <strong>${project.testimonial.author}</strong>
                                    <span>${project.testimonial.role}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                ` : ''}

                <!-- Timeline -->
                ${project.timeline ? `
                    <div class="modal-section">
                        <h3 class="modal-section-title">Déroulement du Projet</h3>
                        <div class="project-timeline">
                            ${project.timeline.map(item => `
                                <div class="timeline-item">
                                    <div class="timeline-date">${item.date}</div>
                                    <div class="timeline-content">
                                        <h4>${item.title}</h4>
                                        <p>${item.description}</p>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    /**
     * Générer le footer du modal
     */
    renderFooter(project) {
        return `
            <div class="modal-footer">
                <div class="modal-footer-links">
                    <a href="#contact" class="modal-btn modal-btn-primary" onclick="portfolioModalInstance.close()">
                        <i class="fas fa-envelope"></i>
                        Discuter de votre projet
                    </a>
                    <button class="modal-btn modal-btn-secondary" onclick="portfolioModalInstance.close()">
                        <i class="fas fa-arrow-left"></i>
                        Retour au portfolio
                    </button>
                </div>
            </div>
        `;
    }
}

// Initialiser le système de modal au chargement de la page
let portfolioModalInstance;

document.addEventListener('DOMContentLoaded', () => {
    portfolioModalInstance = new PortfolioModal();
    console.log('✅ Portfolio Modal System initialisé');
});
