// ==========================================
// Mad'ia - Authentication JavaScript
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    initAuthForms();
    initPasswordToggles();
    initPasswordStrength();
});

// ==========================================
// Form Switching
// ==========================================
function initAuthForms() {
    const loginCard = document.getElementById('loginCard');
    const registerCard = document.getElementById('registerCard');
    const showRegisterBtn = document.getElementById('showRegister');
    const showLoginBtn = document.getElementById('showLogin');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    // Switch to register form
    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', (e) => {
            e.preventDefault();
            loginCard.classList.add('hidden');
            registerCard.classList.remove('hidden');
        });
    }
    
    // Switch to login form
    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', (e) => {
            e.preventDefault();
            registerCard.classList.add('hidden');
            loginCard.classList.remove('hidden');
        });
    }
    
    // Login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Register form submission
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
}

// ==========================================
// Password Toggle Visibility
// ==========================================
function initPasswordToggles() {
    const toggleButtons = document.querySelectorAll('.toggle-password');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-target');
            const input = document.getElementById(targetId);
            const icon = button.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
}

// ==========================================
// Password Strength Indicator
// ==========================================
function initPasswordStrength() {
    const passwordInput = document.getElementById('registerPassword');
    const strengthProgress = document.getElementById('strengthProgress');
    const strengthText = document.getElementById('strengthText');
    
    if (!passwordInput || !strengthProgress || !strengthText) return;
    
    passwordInput.addEventListener('input', () => {
        const password = passwordInput.value;
        const strength = calculatePasswordStrength(password);
        
        // Remove previous classes
        strengthProgress.className = 'strength-progress';
        strengthText.className = 'strength-text';
        
        if (password.length === 0) {
            strengthProgress.style.width = '0';
            strengthText.textContent = '';
            return;
        }
        
        if (strength < 3) {
            strengthProgress.classList.add('weak');
            strengthText.classList.add('weak');
            strengthText.textContent = 'Faible';
        } else if (strength < 5) {
            strengthProgress.classList.add('medium');
            strengthText.classList.add('medium');
            strengthText.textContent = 'Moyen';
        } else {
            strengthProgress.classList.add('strong');
            strengthText.classList.add('strong');
            strengthText.textContent = 'Fort';
        }
    });
}

function calculatePasswordStrength(password) {
    let strength = 0;
    
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;
    
    return strength;
}

// ==========================================
// Handle Login
// ==========================================
async function handleLogin(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const formData = new FormData(form);
    const data = {
        email: formData.get('email'),
        password: formData.get('password'),
        remember: formData.get('remember') === 'on'
    };
    
    // Validation
    if (!validateEmail(data.email)) {
        showAlert('Veuillez entrer une adresse email valide.', 'error');
        return;
    }
    
    if (data.password.length < 6) {
        showAlert('Le mot de passe doit contenir au moins 6 caractères.', 'error');
        return;
    }
    
    // Show loading
    submitBtn.classList.add('loading');
    
    try {
        // Simulate API call
        await simulateAuth(data);
        
        // Store user data
        const userData = {
            email: data.email,
            firstName: data.email.split('@')[0],
            loggedIn: true,
            loginTime: new Date().toISOString()
        };
        
        if (data.remember) {
            localStorage.setItem('madiaUser', JSON.stringify(userData));
        } else {
            sessionStorage.setItem('madiaUser', JSON.stringify(userData));
        }
        
        showAlert('Connexion réussie ! Redirection...', 'success');
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        showAlert(error.message || 'Erreur de connexion. Veuillez réessayer.', 'error');
        submitBtn.classList.remove('loading');
    }
}

// ==========================================
// Handle Register
// ==========================================
async function handleRegister(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const formData = new FormData(form);
    const data = {
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        password: formData.get('password'),
        passwordConfirm: formData.get('passwordConfirm'),
        terms: formData.get('terms') === 'on'
    };
    
    // Validation
    if (!data.firstName || !data.lastName) {
        showAlert('Veuillez renseigner votre nom complet.', 'error');
        return;
    }
    
    if (!validateEmail(data.email)) {
        showAlert('Veuillez entrer une adresse email valide.', 'error');
        return;
    }
    
    if (data.password.length < 8) {
        showAlert('Le mot de passe doit contenir au moins 8 caractères.', 'error');
        return;
    }
    
    if (data.password !== data.passwordConfirm) {
        showAlert('Les mots de passe ne correspondent pas.', 'error');
        return;
    }
    
    if (!data.terms) {
        showAlert('Veuillez accepter les conditions d\'utilisation.', 'error');
        return;
    }
    
    // Show loading
    submitBtn.classList.add('loading');
    
    try {
        // Simulate API call
        await simulateAuth(data, true);
        
        // Store user data
        const userData = {
            email: data.email,
            firstName: data.firstName,
            lastName: data.lastName,
            phone: data.phone,
            loggedIn: true,
            registerTime: new Date().toISOString()
        };
        
        localStorage.setItem('madiaUser', JSON.stringify(userData));
        
        showAlert('Compte créé avec succès ! Redirection...', 'success');
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        showAlert(error.message || 'Erreur d\'inscription. Veuillez réessayer.', 'error');
        submitBtn.classList.remove('loading');
    }
}

// ==========================================
// Email Validation
// ==========================================
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// ==========================================
// Simulate Authentication (Demo)
// ==========================================
async function simulateAuth(data, isRegister = false) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Simulate successful authentication
            resolve({ success: true });
            
            // For demo purposes, always succeed
            // In production, this would be a real API call
        }, 1500);
    });
}

// ==========================================
// Alert Helper
// ==========================================
function showAlert(message, type = 'info') {
    let alertEl = document.getElementById('alertMessage');
    
    if (!alertEl) {
        alertEl = document.createElement('div');
        alertEl.id = 'alertMessage';
        alertEl.className = 'alert-message';
        alertEl.innerHTML = `
            <div class="alert-content">
                <i class="fas fa-info-circle"></i>
                <span id="alertText"></span>
            </div>
        `;
        document.body.appendChild(alertEl);
    }
    
    const alertText = document.getElementById('alertText');
    const alertIcon = alertEl.querySelector('i');
    
    alertText.textContent = message;
    alertEl.className = 'alert-message ' + type;
    
    switch(type) {
        case 'success':
            alertIcon.className = 'fas fa-check-circle';
            break;
        case 'error':
            alertIcon.className = 'fas fa-times-circle';
            break;
        case 'warning':
            alertIcon.className = 'fas fa-exclamation-triangle';
            break;
        default:
            alertIcon.className = 'fas fa-info-circle';
    }
    
    setTimeout(() => {
        alertEl.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        alertEl.classList.remove('show');
    }, 4000);
}

// ==========================================
// Google Sign In (Placeholder)
// ==========================================
document.querySelectorAll('.btn-google').forEach(btn => {
    btn.addEventListener('click', () => {
        showAlert('La connexion Google sera disponible prochainement.', 'info');
        // In production, implement Google OAuth here
    });
});