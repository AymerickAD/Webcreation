/**
 * Blog Interactions Fix & Enhancement
 * Corrige les bugs et améliore l'UX du blog
 */

(function() {
    'use strict';
    
    // Attendre que le DOM soit chargé
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    function init() {
        fixMissingImageLinks();
        enhanceLazyLoading();
        addClickTracking();
        fixTitleLinks();
    }
    
    /**
     * Corrige les images sans lien en les rendant cliquables
     */
    function fixMissingImageLinks() {
        const articles = document.querySelectorAll('.article-card');
        
        articles.forEach(article => {
            // Chercher l'image directe (sans wrapper link)
            const directImage = article.querySelector(':scope > .article-image');
            
            if (directImage) {
                // Trouver le lien de l'article
                const articleLink = article.querySelector('.article-link');
                
                if (articleLink && articleLink.href) {
                    // Créer un wrapper link
                    const imageLink = document.createElement('a');
                    imageLink.href = articleLink.href;
                    imageLink.className = 'article-image-link';
                    imageLink.setAttribute('aria-label', 'Lire l\'article');
                    
                    // Envelopper l'image
                    directImage.parentNode.insertBefore(imageLink, directImage);
                    imageLink.appendChild(directImage);
                    
                    console.log('✅ Image link corrigé:', articleLink.href);
                }
            }
        });
    }
    
    /**
     * Corrige les titres sans lien
     */
    function fixTitleLinks() {
        const articles = document.querySelectorAll('.article-card');
        
        articles.forEach(article => {
            // Chercher le titre direct (sans wrapper link)
            const directTitle = article.querySelector('.article-content > .article-title');
            
            if (directTitle && !directTitle.parentElement.classList.contains('article-title-link')) {
                // Trouver le lien de l'article
                const articleLink = article.querySelector('.article-link');
                
                if (articleLink && articleLink.href) {
                    // Créer un wrapper link
                    const titleLink = document.createElement('a');
                    titleLink.href = articleLink.href;
                    titleLink.className = 'article-title-link';
                    
                    // Envelopper le titre
                    directTitle.parentNode.insertBefore(titleLink, directTitle);
                    titleLink.appendChild(directTitle);
                    
                    console.log('✅ Title link corrigé:', articleLink.href);
                }
            }
        });
    }
    
    /**
     * Améliore le lazy loading des images
     */
    function enhanceLazyLoading() {
        const images = document.querySelectorAll('.article-image img[loading="lazy"]');
        
        images.forEach(img => {
            // Ajouter classe loaded quand l'image est chargée
            if (img.complete) {
                img.classList.add('loaded');
            } else {
                img.addEventListener('load', function() {
                    this.classList.add('loaded');
                });
            }
        });
    }
    
    /**
     * Ajoute le tracking des clics pour analytics
     */
    function addClickTracking() {
        // Tracking clics sur images
        document.querySelectorAll('.article-image-link').forEach(link => {
            link.addEventListener('click', function(e) {
                const articleTitle = this.closest('.article-card')
                    ?.querySelector('.article-title')?.textContent.trim();
                
                console.log('📊 Clic image article:', articleTitle);
                
                // Envoyer à Google Analytics si disponible
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'click', {
                        'event_category': 'Blog',
                        'event_label': 'Image - ' + articleTitle,
                        'transport_type': 'beacon'
                    });
                }
            });
        });
        
        // Tracking clics sur titres
        document.querySelectorAll('.article-title-link').forEach(link => {
            link.addEventListener('click', function(e) {
                const articleTitle = this.querySelector('.article-title')?.textContent.trim();
                
                console.log('📊 Clic titre article:', articleTitle);
                
                // Envoyer à Google Analytics si disponible
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'click', {
                        'event_category': 'Blog',
                        'event_label': 'Titre - ' + articleTitle,
                        'transport_type': 'beacon'
                    });
                }
            });
        });
    }
    
    /**
     * Précharge les pages au hover pour navigation plus rapide
     */
    function preloadOnHover() {
        const links = document.querySelectorAll('.article-image-link, .article-title-link, .article-link');
        
        links.forEach(link => {
            link.addEventListener('mouseenter', function() {
                const href = this.getAttribute('href');
                
                if (href && !document.querySelector(`link[rel="prefetch"][href="${href}"]`)) {
                    const prefetchLink = document.createElement('link');
                    prefetchLink.rel = 'prefetch';
                    prefetchLink.href = href;
                    document.head.appendChild(prefetchLink);
                    
                    console.log('⚡ Préchargement:', href);
                }
            }, { once: true });
        });
    }
    
    // Activer le préchargement après 2 secondes (économie ressources)
    setTimeout(preloadOnHover, 2000);
    
    /**
     * Validation des liens au chargement
     */
    function validateLinks() {
        const allLinks = document.querySelectorAll('.article-link, .article-image-link, .article-title-link');
        let brokenLinks = 0;
        
        allLinks.forEach(link => {
            const href = link.getAttribute('href');
            
            if (!href || href === '#' || href === '') {
                console.error('❌ Lien cassé détecté:', link);
                brokenLinks++;
                
                // Désactiver visuellement
                link.style.opacity = '0.5';
                link.style.cursor = 'not-allowed';
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    alert('Désolé, cet article n\'est pas encore disponible.');
                });
            }
        });
        
        if (brokenLinks > 0) {
            console.warn(`⚠️ ${brokenLinks} lien(s) cassé(s) détecté(s)`);
        } else {
            console.log('✅ Tous les liens fonctionnent correctement');
        }
    }
    
    // Valider les liens
    validateLinks();
    
    /**
     * Amélioration accessibilité clavier
     */
    function enhanceKeyboardNav() {
        const cards = document.querySelectorAll('.article-card');
        
        cards.forEach((card, index) => {
            card.setAttribute('tabindex', '0');
            card.setAttribute('role', 'article');
            
            // Enter pour ouvrir
            card.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    const link = this.querySelector('.article-link');
                    if (link) {
                        link.click();
                    }
                }
            });
        });
    }
    
    enhanceKeyboardNav();
    
    console.log('✅ Blog interactions améliorées');
})();
