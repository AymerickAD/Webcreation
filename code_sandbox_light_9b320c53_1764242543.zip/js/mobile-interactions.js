/**
 * WebCreation - Advanced Mobile Interactions
 * Gestion des micro-interactions et effets mobiles
 */

(function() {
    'use strict';
    
    // ===================================
    // CONFIGURATION
    // ===================================
    
    const config = {
        scrollRevealThreshold: 0.1,
        scrollRevealDelay: 100,
        toastDuration: 3000,
        pullRefreshThreshold: 80
    };
    
    // ===================================
    // SCROLL REVEAL ANIMATIONS
    // ===================================
    
    function initScrollReveal() {
        const observerOptions = {
            threshold: config.scrollRevealThreshold,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.classList.add('visible');
                    }, index * config.scrollRevealDelay);
                }
            });
        }, observerOptions);
        
        // Observer tous les éléments avec classes reveal
        document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right, .reveal-scale, .fade-in-mobile').forEach(el => {
            observer.observe(el);
        });
    }
    
    // ===================================
    // SCROLL PROGRESS BAR
    // ===================================
    
    function initScrollProgress() {
        const scrollProgress = document.getElementById('scrollProgress');
        if (!scrollProgress) return;
        
        window.addEventListener('scroll', () => {
            const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
            const scrolled = (window.scrollY / scrollHeight) * 100;
            scrollProgress.style.width = `${Math.min(scrolled, 100)}%`;
        }, { passive: true });
    }
    
    // ===================================
    // STICKY CTA VISIBILITY
    // ===================================
    
    function initStickyCTA() {
        const stickyCTA = document.getElementById('stickyCTA');
        if (!stickyCTA) return;
        
        let lastScrollTop = 0;
        
        window.addEventListener('scroll', () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Afficher après 500px de scroll et en scrollant vers le bas
            if (scrollTop > 500 && scrollTop > lastScrollTop) {
                stickyCTA.classList.add('visible');
            } else if (scrollTop < 300) {
                stickyCTA.classList.remove('visible');
            }
            
            lastScrollTop = scrollTop;
        }, { passive: true });
    }
    
    // ===================================
    // NAVBAR SHRINK ON SCROLL
    // ===================================
    
    function initNavbarShrink() {
        const navbar = document.getElementById('navbar');
        if (!navbar) return;
        
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }, { passive: true });
    }
    
    // ===================================
    // RIPPLE EFFECT ON BUTTONS
    // ===================================
    
    function initRippleEffect() {
        document.querySelectorAll('.btn-primary, .btn-secondary').forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = `${size}px`;
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });
    }
    
    // ===================================
    // TOAST NOTIFICATIONS
    // ===================================
    
    const Toast = {
        show(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            const icon = this.getIcon(type);
            toast.innerHTML = `
                <div class="toast-icon">${icon}</div>
                <div class="toast-message">${message}</div>
            `;
            
            document.body.appendChild(toast);
            
            // Trigger animation
            setTimeout(() => toast.classList.add('show'), 10);
            
            // Auto remove
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 400);
            }, config.toastDuration);
        },
        
        getIcon(type) {
            const icons = {
                'success': '✓',
                'error': '✕',
                'info': 'ℹ',
                'warning': '⚠'
            };
            return icons[type] || icons.info;
        },
        
        success(message) {
            this.show(message, 'success');
        },
        
        error(message) {
            this.show(message, 'error');
        },
        
        info(message) {
            this.show(message, 'info');
        }
    };
    
    // Exposer Toast globalement
    window.Toast = Toast;
    
    // ===================================
    // FORM VALIDATION AVEC FEEDBACK
    // ===================================
    
    function initFormValidation() {
        const forms = document.querySelectorAll('form');
        
        forms.forEach(form => {
            const inputs = form.querySelectorAll('.form-input, .form-textarea');
            
            inputs.forEach(input => {
                // Real-time validation
                input.addEventListener('blur', function() {
                    validateInput(this);
                });
                
                // Remove error on input
                input.addEventListener('input', function() {
                    this.classList.remove('error');
                    const errorMsg = this.parentElement.querySelector('.error-message');
                    if (errorMsg) errorMsg.remove();
                });
            });
            
            // Form submit
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                let isValid = true;
                inputs.forEach(input => {
                    if (!validateInput(input)) {
                        isValid = false;
                    }
                });
                
                if (isValid) {
                    handleFormSubmit(this);
                } else {
                    Toast.error('Veuillez corriger les erreurs dans le formulaire');
                }
            });
        });
    }
    
    function validateInput(input) {
        const value = input.value.trim();
        const type = input.type;
        let isValid = true;
        let errorMessage = '';
        
        // Remove existing error
        const existingError = input.parentElement.querySelector('.error-message');
        if (existingError) existingError.remove();
        
        // Required check
        if (input.hasAttribute('required') && !value) {
            isValid = false;
            errorMessage = 'Ce champ est requis';
        }
        
        // Email validation
        else if (type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                isValid = false;
                errorMessage = 'Email invalide';
            }
        }
        
        // Tel validation
        else if (type === 'tel' && value) {
            const telRegex = /^[0-9+\-\s()]+$/;
            if (!telRegex.test(value)) {
                isValid = false;
                errorMessage = 'Numéro de téléphone invalide';
            }
        }
        
        // Show error
        if (!isValid) {
            input.classList.add('error');
            const error = document.createElement('div');
            error.className = 'error-message';
            error.textContent = errorMessage;
            error.style.cssText = `
                color: #EF4444;
                font-size: 0.875rem;
                margin-top: 0.5rem;
                animation: shake 0.3s ease;
            `;
            input.parentElement.appendChild(error);
        } else {
            input.classList.remove('error');
        }
        
        return isValid;
    }
    
    function handleFormSubmit(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Loading state
        submitBtn.classList.add('btn-loading');
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            // Success state
            submitBtn.classList.remove('btn-loading');
            submitBtn.classList.add('btn-success');
            submitBtn.textContent = 'Envoyé !';
            
            Toast.success('Message envoyé avec succès !');
            
            // Reset form
            setTimeout(() => {
                form.reset();
                submitBtn.classList.remove('btn-success');
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        }, 1500);
    }
    
    // ===================================
    // SMOOTH SCROLL TO ANCHOR
    // ===================================
    
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href === '#') return;
                
                e.preventDefault();
                const target = document.querySelector(href);
                
                if (target) {
                    const offsetTop = target.offsetTop - 80; // Account for fixed header
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    const navMenu = document.getElementById('navMenu');
                    const navToggle = document.getElementById('navToggle');
                    if (navMenu && navMenu.classList.contains('active')) {
                        navMenu.classList.remove('active');
                        navToggle.classList.remove('active');
                    }
                }
            });
        });
    }
    
    // ===================================
    // TOUCH GESTURES
    // ===================================
    
    function initTouchGestures() {
        const swipeables = document.querySelectorAll('.swipeable');
        
        swipeables.forEach(element => {
            let startX = 0;
            let currentX = 0;
            
            element.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
            }, { passive: true });
            
            element.addEventListener('touchmove', (e) => {
                currentX = e.touches[0].clientX;
                const diff = currentX - startX;
                
                if (Math.abs(diff) > 50) {
                    if (diff > 0) {
                        element.classList.add('swiping-right');
                        element.classList.remove('swiping-left');
                    } else {
                        element.classList.add('swiping-left');
                        element.classList.remove('swiping-right');
                    }
                }
            }, { passive: true });
            
            element.addEventListener('touchend', () => {
                element.classList.remove('swiping-left', 'swiping-right');
            }, { passive: true });
        });
    }
    
    // ===================================
    // LAZY LOADING IMAGES
    // ===================================
    
    function initLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');
        
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    }
    
    // ===================================
    // PERFORMANCE MONITORING
    // ===================================
    
    function logPerformance() {
        if (window.performance && window.performance.timing) {
            window.addEventListener('load', () => {
                setTimeout(() => {
                    const perfData = window.performance.timing;
                    const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
                    console.log(`📊 Page loaded in ${pageLoadTime}ms`);
                }, 0);
            });
        }
    }
    
    // ===================================
    // INITIALIZATION
    // ===================================
    
    function init() {
        // Wait for DOM ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initAll);
        } else {
            initAll();
        }
    }
    
    function initAll() {
        console.log('🚀 WebCreation Mobile Interactions initialized');
        
        initScrollReveal();
        initScrollProgress();
        initStickyCTA();
        initNavbarShrink();
        initRippleEffect();
        initFormValidation();
        initSmoothScroll();
        initTouchGestures();
        initLazyLoading();
        logPerformance();
    }
    
    // Start
    init();
    
})();