/**
 * WebCreation - Advanced 3D Effects
 * Inspired by ia.agency
 */

// ===========================
// 1. MOUSE PARALLAX EFFECTS
// ===========================
class ParallaxController {
    constructor() {
        this.mouse = { x: 0, y: 0 };
        this.smoothMouse = { x: 0, y: 0 };
        this.init();
    }

    init() {
        document.addEventListener('mousemove', (e) => {
            this.mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
            this.mouse.y = (e.clientY / window.innerHeight) * 2 - 1;
        });

        this.animate();
    }

    animate() {
        // Smooth interpolation
        this.smoothMouse.x += (this.mouse.x - this.smoothMouse.x) * 0.05;
        this.smoothMouse.y += (this.mouse.y - this.smoothMouse.y) * 0.05;

        // Apply parallax to orbs
        const orbs = document.querySelectorAll('.gradient-orb');
        orbs.forEach((orb, index) => {
            const speed = (index + 1) * 15;
            const x = this.smoothMouse.x * speed;
            const y = this.smoothMouse.y * speed;
            orb.style.transform = `translate(${x}px, ${y}px)`;
        });

        // Apply parallax to cards
        const cards = document.querySelectorAll('.service-card, .portfolio-item, .process-step');
        cards.forEach((card, index) => {
            const speed = 5 + (index % 3) * 2;
            const x = this.smoothMouse.x * speed;
            const y = this.smoothMouse.y * speed;
            card.style.transform = `translate(${x}px, ${y}px)`;
        });

        requestAnimationFrame(() => this.animate());
    }
}

// ===========================
// 2. 3D CARD TILT EFFECT
// ===========================
class CardTilt {
    constructor() {
        this.cards = document.querySelectorAll('.service-card, .portfolio-item');
        this.init();
    }

    init() {
        this.cards.forEach(card => {
            card.addEventListener('mousemove', (e) => this.handleMove(e, card));
            card.addEventListener('mouseleave', () => this.handleLeave(card));
        });
    }

    handleMove(e, card) {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * 10;
        const rotateY = ((x - centerX) / centerX) * -10;

        card.style.transform = `
            perspective(1000px)
            rotateX(${rotateX}deg)
            rotateY(${rotateY}deg)
            scale3d(1.02, 1.02, 1.02)
        `;

        // Add shine effect
        const shine = card.querySelector('.card-shine') || this.createShine(card);
        shine.style.background = `
            radial-gradient(
                circle at ${x}px ${y}px,
                rgba(255, 255, 255, 0.15),
                transparent 50%
            )
        `;
    }

    handleLeave(card) {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
        const shine = card.querySelector('.card-shine');
        if (shine) {
            shine.style.background = 'transparent';
        }
    }

    createShine(card) {
        const shine = document.createElement('div');
        shine.className = 'card-shine';
        shine.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            pointer-events: none;
            border-radius: inherit;
            z-index: 1;
            transition: background 0.3s ease;
        `;
        card.style.position = 'relative';
        card.appendChild(shine);
        return shine;
    }
}

// ===========================
// 3. ANIMATED GRADIENT ORBS
// ===========================
class AnimatedOrbs {
    constructor() {
        this.createExtraOrbs();
    }

    createExtraOrbs() {
        const sections = document.querySelectorAll('.services, .portfolio, .process');
        
        sections.forEach(section => {
            if (!section.querySelector('.gradient-orb')) {
                const orb1 = this.createOrb('orb-dynamic-1', {
                    size: '500px',
                    color: 'rgba(0, 102, 255, 0.08)',
                    top: '10%',
                    right: '-150px',
                    delay: '0s'
                });
                
                const orb2 = this.createOrb('orb-dynamic-2', {
                    size: '400px',
                    color: 'rgba(123, 97, 255, 0.06)',
                    bottom: '15%',
                    left: '-100px',
                    delay: '-7s'
                });

                section.style.position = 'relative';
                section.style.overflow = 'hidden';
                section.appendChild(orb1);
                section.appendChild(orb2);
            }
        });
    }

    createOrb(className, styles) {
        const orb = document.createElement('div');
        orb.className = `gradient-orb ${className}`;
        orb.style.cssText = `
            position: absolute;
            width: ${styles.size};
            height: ${styles.size};
            background: radial-gradient(circle, ${styles.color}, transparent 70%);
            border-radius: 50%;
            filter: blur(100px);
            opacity: 0.4;
            animation: float 20s ease-in-out infinite;
            animation-delay: ${styles.delay};
            pointer-events: none;
            z-index: 0;
            ${styles.top ? `top: ${styles.top};` : ''}
            ${styles.bottom ? `bottom: ${styles.bottom};` : ''}
            ${styles.left ? `left: ${styles.left};` : ''}
            ${styles.right ? `right: ${styles.right};` : ''}
        `;
        return orb;
    }
}

// ===========================
// 4. SCROLL-TRIGGERED 3D ANIMATIONS
// ===========================
class Scroll3DAnimations {
    constructor() {
        this.elements = document.querySelectorAll('.service-card, .portfolio-item, .process-step');
        this.init();
    }

    init() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animation = 'fadeInUp3D 0.8s ease forwards';
                    entry.target.style.opacity = '1';
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '50px'
        });

        this.elements.forEach(el => {
            el.style.opacity = '0';
            observer.observe(el);
        });

        // Add CSS for animation
        this.injectAnimations();
    }

    injectAnimations() {
        if (!document.getElementById('3d-animations-style')) {
            const style = document.createElement('style');
            style.id = '3d-animations-style';
            style.textContent = `
                @keyframes fadeInUp3D {
                    from {
                        opacity: 0;
                        transform: translate3d(0, 60px, -100px) rotateX(10deg);
                    }
                    to {
                        opacity: 1;
                        transform: translate3d(0, 0, 0) rotateX(0);
                    }
                }

                .service-card,
                .portfolio-item,
                .process-step {
                    transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
                }

                @keyframes float {
                    0%, 100% { transform: translate(0, 0) scale(1); }
                    33% { transform: translate(30px, -30px) scale(1.05); }
                    66% { transform: translate(-20px, 20px) scale(0.95); }
                }
            `;
            document.head.appendChild(style);
        }
    }
}

// ===========================
// 5. GLASSMORPHISM ENHANCEMENT
// ===========================
class GlassmorphismEffects {
    constructor() {
        this.enhanceGlassElements();
    }

    enhanceGlassElements() {
        const glassElements = document.querySelectorAll('.nav, .service-card, .portfolio-item');
        
        glassElements.forEach(el => {
            // Add subtle reflection effect
            el.style.position = 'relative';
            el.style.transformStyle = 'preserve-3d';
            
            // Enhance backdrop filter
            const currentBackdrop = window.getComputedStyle(el).backdropFilter;
            if (currentBackdrop.includes('blur')) {
                el.style.backdropFilter = `${currentBackdrop} saturate(1.8) brightness(1.1)`;
                el.style.webkitBackdropFilter = `${currentBackdrop} saturate(1.8) brightness(1.1)`;
            }
        });
    }
}

// ===========================
// INITIALIZE ALL EFFECTS
// ===========================
document.addEventListener('DOMContentLoaded', () => {
    // Check if user prefers reduced motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (!prefersReducedMotion) {
        new ParallaxController();
        new CardTilt();
        new AnimatedOrbs();
        new Scroll3DAnimations();
        new GlassmorphismEffects();
        
        console.log('🎨 WebCreation 3D Effects: Activated');
    } else {
        console.log('⚡ WebCreation: Reduced motion mode - 3D effects disabled');
    }
});

// Performance monitoring
if (window.performance) {
    window.addEventListener('load', () => {
        const perfData = window.performance.timing;
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
        console.log(`⚡ Page fully loaded in: ${pageLoadTime}ms`);
    });
}
