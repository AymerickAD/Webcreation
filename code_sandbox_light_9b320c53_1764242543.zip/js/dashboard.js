const SECTION_SUFFIX = 'Section';
const DEMO_BANNER_KEY = 'madiaDemoBannerDismissed';

document.addEventListener('DOMContentLoaded', () => {
    const currentUser = checkAuth();

    if (currentUser?.isDemo) {
        displayDemoBanner();
    }

    initSidebar();
    initUserMenu();
    initSectionNavigation();
    initCalendarEmbed();
    initMessageForm();
    initFileUpload();
    loadUserData(currentUser);
});

// ==========================================
// Authentication Helpers
// ==========================================
function checkAuth() {
    let userData = getUserData();

    if (!userData || !userData.loggedIn) {
        userData = createDemoUser();
    }

    return userData;
}

function getUserData() {
    const sessionUser = parseUserFromStorage(sessionStorage.getItem('madiaUser'));
    if (sessionUser) {
        return sessionUser;
    }

    const localUser = parseUserFromStorage(localStorage.getItem('madiaUser'));
    if (localUser) {
        return localUser;
    }

    return null;
}

function parseUserFromStorage(rawValue) {
    if (!rawValue) {
        return null;
    }

    try {
        return JSON.parse(rawValue);
    } catch (error) {
        console.warn('Données utilisateur corrompues détectées, suppression nécessaire.', error);
        return null;
    }
}

function createDemoUser() {
    const demoUser = {
        firstName: 'Invité',
        lastName: '',
        email: 'demo@madia.digital',
        phone: '',
        loggedIn: true,
        loginMethod: 'demo',
        isDemo: true,
        loginTime: new Date().toISOString()
    };

    sessionStorage.setItem('madiaUser', JSON.stringify(demoUser));
    return demoUser;
}

function displayDemoBanner() {
    if (sessionStorage.getItem(DEMO_BANNER_KEY) === 'true') {
        return;
    }

    if (document.getElementById('demoBanner')) {
        return;
    }

    const banner = document.createElement('div');
    banner.id = 'demoBanner';
    banner.className = 'demo-banner';
    banner.innerHTML = `
        <i class="fas fa-info-circle" aria-hidden="true"></i>
        <span><strong>Mode démonstration :</strong> vos actions sont simulées, aucun envoi réel n'est effectué.</span>
        <button type="button" aria-label="Fermer l'information de démonstration">
            <i class="fas fa-xmark" aria-hidden="true"></i>
        </button>
    `;

    const navbar = document.querySelector('.navbar');
    if (navbar) {
        navbar.insertAdjacentElement('afterend', banner);
    } else {
        document.body.insertBefore(banner, document.body.firstChild);
    }

    const closeButton = banner.querySelector('button');
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            sessionStorage.setItem(DEMO_BANNER_KEY, 'true');
            banner.remove();
        });
    }
}

// ==========================================
// User Data Rendering
// ==========================================
function loadUserData(userData = getUserData()) {
    if (!userData) {
        return;
    }

    const displayName = userData.firstName || 'Client';
    const navbarName = userData.isDemo ? `${displayName} (Démo)` : displayName;

    const userNameEl = document.getElementById('userName');
    if (userNameEl) {
        userNameEl.textContent = navbarName;
    }

    const userGreeting = document.getElementById('userGreeting');
    if (userGreeting) {
        userGreeting.textContent = displayName;
    }

    updateStats();
}

function updateStats() {
    const stats = {
        appointments: 1,
        projects: 0,
        messages: 3,
        documents: 0
    };
    
    const statsAppointments = document.getElementById('statsAppointments');
    const statsProjects = document.getElementById('statsProjects');
    const statsMessages = document.getElementById('statsMessages');
    const statsDocuments = document.getElementById('statsDocuments');
    
    if (statsAppointments) statsAppointments.textContent = stats.appointments;
    if (statsProjects) statsProjects.textContent = stats.projects;
    if (statsMessages) statsMessages.textContent = stats.messages;
    if (statsDocuments) statsDocuments.textContent = stats.documents;
}

// ==========================================
// Sidebar Navigation
// ==========================================
function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    if (!sidebar) {
        return;
    }

    const toggleSidebar = (forceOpen) => {
        const shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : !sidebar.classList.contains('active');
        sidebar.classList.toggle('active', shouldOpen);

        if (mobileSidebarToggle) {
            mobileSidebarToggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
        }
    };
    
    if (mobileSidebarToggle) {
        mobileSidebarToggle.addEventListener('click', (event) => {
            event.stopPropagation();
            toggleSidebar();
        });
    }
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => toggleSidebar(false));
    }
    
    document.addEventListener('click', (event) => {
        if (window.innerWidth > 768) {
            return;
        }

        const clickedInsideSidebar = sidebar.contains(event.target);
        const clickedToggle = mobileSidebarToggle && mobileSidebarToggle.contains(event.target);

        if (!clickedInsideSidebar && !clickedToggle) {
            toggleSidebar(false);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && window.innerWidth <= 768) {
            toggleSidebar(false);
        }
    });
}

function initUserMenu() {
    const toggle = document.getElementById('userMenuToggle');
    const dropdown = document.getElementById('userDropdown');
    const logoutBtn = document.getElementById('logoutBtn');

    const closeMenu = () => {
        if (dropdown && dropdown.classList.contains('active')) {
            dropdown.classList.remove('active');
            dropdown.setAttribute('aria-hidden', 'true');
        }
        if (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
        }
    };
    
    if (toggle) {
        toggle.addEventListener('click', (event) => {
            event.stopPropagation();
            const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');

            if (dropdown) {
                dropdown.classList.toggle('active');
                dropdown.setAttribute('aria-hidden', isExpanded ? 'true' : 'false');
            }
        });
    }

    if (dropdown) {
        dropdown.addEventListener('click', (event) => event.stopPropagation());
    }

    document.addEventListener('click', closeMenu);

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeMenu();
            if (toggle) {
                toggle.focus();
            }
        }
    });
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (event) => {
            event.preventDefault();
            handleLogout();
        });
    }
}

function handleLogout() {
    const userData = getUserData();
    
    if (userData && userData.loginMethod === 'google') {
        if (window.signOutGoogle) {
            signOutGoogle();
            return;
        }
    }
    
    sessionStorage.removeItem('madiaUser');
    localStorage.removeItem('madiaUser');
    sessionStorage.removeItem(DEMO_BANNER_KEY);
    
    showAlert('Déconnexion réussie', 'success');
    
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

// ==========================================
// Section Navigation
// ==========================================
function scrollToDashboardSection(targetSection) {
    if (!targetSection) return;

    const navbar = document.querySelector('.navbar');
    const headerHeight = navbar ? navbar.offsetHeight : 70;
    const offsetMargin = window.innerWidth <= 768 ? 16 : 24;
    const targetPosition = targetSection.getBoundingClientRect().top + window.pageYOffset;
    const offsetPosition = Math.max(targetPosition - (headerHeight + offsetMargin), 0);

    window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
    });
}

function setActiveSection(sectionName, options = {}) {
    const {
        scrollIntoView = true,
        updateHash = true,
        focusSection = false,
        closeMobileMenu = true
    } = options;

    if (!sectionName) {
        return;
    }

    const targetSection = document.getElementById(`${sectionName}${SECTION_SUFFIX}`);
    if (!targetSection) {
        return;
    }

    const sections = document.querySelectorAll('.dashboard-section');
    sections.forEach(section => {
        section.classList.toggle('active', section === targetSection);
    });

    const sidebarLinks = document.querySelectorAll('.sidebar-link[data-section]');
    sidebarLinks.forEach(link => {
        const matches = link.getAttribute('data-section') === sectionName;
        link.classList.toggle('active', matches);
        link.setAttribute('aria-current', matches ? 'page' : 'false');
    });

    if (updateHash) {
        const newHash = `#${sectionName}`;
        if (window.location.hash !== newHash) {
            history.replaceState(null, '', newHash);
        }
    }

    if (scrollIntoView) {
        scrollToDashboardSection(targetSection);
    }

    if (focusSection) {
        const heading = targetSection.querySelector('h1, h2, h3');
        if (heading) {
            const previousTabIndex = heading.getAttribute('tabindex');
            heading.setAttribute('tabindex', '-1');
            heading.focus({ preventScroll: true });
            if (previousTabIndex === null) {
                heading.addEventListener('blur', () => heading.removeAttribute('tabindex'), { once: true });
            }
        }
    }

    if (closeMobileMenu && window.innerWidth <= 768) {
        const sidebar = document.getElementById('sidebar');
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        if (sidebar) {
            sidebar.classList.remove('active');
        }
        if (mobileSidebarToggle) {
            mobileSidebarToggle.setAttribute('aria-expanded', 'false');
        }
    }
}

function initSectionNavigation() {
    const sidebarLinks = document.querySelectorAll('.sidebar-link[data-section]');
    const sections = document.querySelectorAll('.dashboard-section');

    if (!sidebarLinks.length || !sections.length) {
        return;
    }
    
    sidebarLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const sectionName = link.getAttribute('data-section');
            setActiveSection(sectionName, { focusSection: true });
        });
    });

    const initialHash = window.location.hash.replace('#', '');
    if (initialHash && document.getElementById(`${initialHash}${SECTION_SUFFIX}`)) {
        setActiveSection(initialHash, { scrollIntoView: false, updateHash: false, closeMobileMenu: false });
    } else {
        const activeLink = Array.from(sidebarLinks).find(link => link.classList.contains('active')) || sidebarLinks[0];
        if (activeLink) {
            setActiveSection(activeLink.getAttribute('data-section'), { scrollIntoView: false, updateHash: false, closeMobileMenu: false });
        }
    }

    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.replace('#', '');
        if (hash && document.getElementById(`${hash}${SECTION_SUFFIX}`)) {
            setActiveSection(hash, { scrollIntoView: false, updateHash: false, closeMobileMenu: false });
        }
    });
}

window.showSection = function(sectionName) {
    setActiveSection(sectionName, { focusSection: true });
};

// ==========================================
// Calendar Embed Toggle
// ==========================================
function initCalendarEmbed() {
    const toggleButton = document.getElementById('openCalendarBtn');
    const embedContainer = document.getElementById('calendarEmbed');

    if (!toggleButton || !embedContainer) {
        return;
    }

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const labelNode = toggleButton.querySelector('span');
    const originalLabel = labelNode ? labelNode.textContent.trim() : null;
    const hideLabel = toggleButton.getAttribute('data-hide-label') || 'Masquer le calendrier';

    const ensureFocusability = () => {
        if (!embedContainer.hasAttribute('tabindex')) {
            embedContainer.setAttribute('tabindex', '-1');
        }
    };

    ensureFocusability();
    embedContainer.setAttribute('aria-hidden', 'true');
    toggleButton.setAttribute('aria-expanded', 'false');
    if (!embedContainer.hasAttribute('hidden')) {
        embedContainer.setAttribute('hidden', '');
    }

    const setExpandedState = (expanded) => {
        toggleButton.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        embedContainer.setAttribute('aria-hidden', expanded ? 'false' : 'true');

        if (labelNode && originalLabel) {
            labelNode.textContent = expanded ? hideLabel : originalLabel;
        }

        if (expanded) {
            embedContainer.removeAttribute('hidden');
            embedContainer.classList.add('is-visible');

            requestAnimationFrame(() => {
                embedContainer.scrollIntoView({
                    behavior: prefersReducedMotion ? 'auto' : 'smooth',
                    block: 'start'
                });

                try {
                    embedContainer.focus({ preventScroll: true });
                } catch (error) {
                    // Certains navigateurs n'autorisent pas focus preventScroll
                    embedContainer.focus();
                }
            });
        } else {
            embedContainer.setAttribute('hidden', '');
            embedContainer.classList.remove('is-visible');

            requestAnimationFrame(() => {
                toggleButton.focus({ preventScroll: true });
            });
        }
    };

    toggleButton.addEventListener('click', () => {
        const isExpanded = toggleButton.getAttribute('aria-expanded') === 'true';
        setExpandedState(!isExpanded);
    });

    embedContainer.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            setExpandedState(false);
        }
    });
}

// ==========================================
// Message Form
// ==========================================
function initMessageForm() {
    const messageForm = document.getElementById('messageForm');
    
    if (!messageForm) {
        return;
    }

    messageForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const formData = new FormData(messageForm);
        const subject = (formData.get('messageSubject') || '').trim();
        const content = (formData.get('messageContent') || '').trim();
        const userData = getUserData();

        if (!subject || !content) {
            showAlert('Veuillez renseigner le sujet et le message avant l\'envoi.', 'warning');
            return;
        }

        if (!userData) {
            showAlert('Votre session a expiré. Merci de vous reconnecter.', 'error');
            return;
        }
        
        const mailSubject = encodeURIComponent(`[Dashboard] ${subject}`);
        const mailBody = encodeURIComponent(`
De: ${userData.firstName || 'Client'} ${userData.lastName || ''}
Email: ${userData.email || 'non communiqué'}

Message:
${content}
        `);
        
        const mailtoLink = `mailto:dansicare.aymerickpro@gmail.com?subject=${mailSubject}&body=${mailBody}`;
        
        window.location.href = mailtoLink;
        
        showAlert('Votre client email va s\'ouvrir', 'success');
        
        messageForm.reset();
        const subjectField = messageForm.querySelector('#messageSubject');
        if (subjectField) {
            subjectField.focus();
        }
    });
}

// ==========================================
// File Upload
// ==========================================
function initFileUpload() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    
    if (!uploadArea || !fileInput) return;
    
    uploadArea.addEventListener('click', (event) => {
        if (event.target.closest('button, input')) {
            return;
        }
        fileInput.click();
    });

    uploadArea.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            fileInput.click();
        }
    });
    
    uploadArea.addEventListener('dragover', (event) => {
        event.preventDefault();
        uploadArea.classList.add('is-dragover');
    });
    
    const removeDragState = () => uploadArea.classList.remove('is-dragover');

    uploadArea.addEventListener('dragleave', removeDragState);
    uploadArea.addEventListener('dragend', removeDragState);
    
    uploadArea.addEventListener('drop', (event) => {
        event.preventDefault();
        removeDragState();
        const files = event.dataTransfer?.files;
        handleFiles(files);
    });
    
    fileInput.addEventListener('change', (event) => {
        handleFiles(event.target.files);
        event.target.value = '';
    });
}

function handleFiles(files) {
    if (!files || files.length === 0) return;

    const fileArray = Array.from(files);
    const fileNames = fileArray.map(file => file.name).join(', ');

    renderDocumentPreview(fileArray);
    showAlert(`Fichier(s) prêts : ${fileNames}. (Upload simulé)`, 'info');
}

function renderDocumentPreview(files) {
    const listContainer = document.querySelector('.documents-list');
    if (!listContainer) return;

    let list = listContainer.querySelector('.documents-preview');
    if (!list) {
        list = document.createElement('ul');
        list.className = 'documents-preview';
        listContainer.appendChild(list);
    }

    list.innerHTML = '';

    const emptyState = listContainer.querySelector('.empty-state');
    if (emptyState) {
        emptyState.remove();
    }

    files.forEach(file => {
        const item = document.createElement('li');
        item.className = 'documents-preview-item';
        item.innerHTML = `
            <div class="item-icon" aria-hidden="true"><i class="fas fa-file-alt"></i></div>
            <div class="item-body">
                <p class="item-name">${file.name}</p>
                <span class="item-size">${formatFileSize(file.size)}</span>
            </div>
        `;
        list.appendChild(item);
    });
}

function formatFileSize(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) {
        return 'Taille inconnue';
    }

    const units = ['octets', 'Ko', 'Mo', 'Go', 'To'];
    const exponent = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const size = bytes / Math.pow(1024, exponent);

    const decimals = size >= 10 || exponent === 0 ? 0 : 1;
    return `${size.toFixed(decimals)} ${units[exponent]}`;
}

// ==========================================
// Alert Helper
// ==========================================
function showAlert(message, type = 'info') {
    let alertEl = document.getElementById('dashboardAlert');
    
    if (!alertEl) {
        alertEl = document.createElement('div');
        alertEl.id = 'dashboardAlert';
        alertEl.style.cssText = `
            position: fixed;
            top: 100px;
            right: 30px;
            max-width: 350px;
            background: white;
            padding: 20px 24px;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.16);
            z-index: 9999;
            transform: translateX(400px);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        `;
        alertEl.setAttribute('role', 'status');
        alertEl.setAttribute('aria-live', 'polite');
        alertEl.setAttribute('aria-atomic', 'true');
        document.body.appendChild(alertEl);
    }
    
    const colors = {
        success: '#10B981',
        error: '#EF4444',
        warning: '#F59E0B',
        info: '#4DC3D1'
    };
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    alertEl.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas ${icons[type]}" style="font-size: 24px; color: ${colors[type]};"></i>
            <span style="flex: 1; font-weight: 500; color: #0F172A;">${message}</span>
        </div>
    `;

    alertEl.style.transform = 'translateX(400px)';
    clearTimeout(alertEl.hideTimeoutId);

    setTimeout(() => {
        alertEl.style.transform = 'translateX(0)';
    }, 60);
    
    alertEl.hideTimeoutId = setTimeout(() => {
        alertEl.style.transform = 'translateX(400px)';
    }, 4000);
}
