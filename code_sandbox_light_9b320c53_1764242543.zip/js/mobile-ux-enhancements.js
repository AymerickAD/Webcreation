/**
 * Mobile UX Enhancements v5.0
 * Améliorations JavaScript pour l'expérience mobile
 */

(function() {
    'use strict';
    
    // ===================================
    // 1. SCROLL PROGRESS INDICATOR
    // ===================================
    
    function updateScrollProgress() {
        const scrollProgress = document.getElementById('scrollProgress');
        if (!scrollProgress) return;
        
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        const scrollPercentage = (scrollTop / (documentHeight - windowHeight)) * 100;
        scrollProgress.style.width = scrollPercentage + '%';
    }
    
    // Throttle scroll event pour performance
    let scrollTimeout;
    window.addEventListener('scroll', function() {
        if (!scrollTimeout) {
            scrollTimeout = setTimeout(function() {
                updateScrollProgress();
                scrollTimeout = null;
            }, 10);
        }
    }, { passive: true });
    
    // ===================================
    // 2. LAZY LOADING IMAGES
    // ===================================
    
    function setupLazyLoading() {
        const lazyImages = document.querySelectorAll('img[loading="lazy"]');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.addEventListener('load', function() {
                            img.classList.add('loaded');
                        });
                        observer.unobserve(img);
                    }
                });
            }, {
                rootMargin: '50px 0px'
            });
            
            lazyImages.forEach(img => imageObserver.observe(img));
        } else {
            // Fallback: charger toutes les images immédiatement
            lazyImages.forEach(img => img.classList.add('loaded'));
        }
    }
    
    // ===================================
    // 3. TOUCH FEEDBACK ON CARDS
    // ===================================
    
    function setupTouchFeedback() {
        const touchableElements = document.querySelectorAll(
            '.service-card, .portfolio-item, .review-card, .article-card, .filter-btn'
        );
        
        touchableElements.forEach(element => {
            element.addEventListener('touchstart', function() {
                this.style.transform = 'scale(0.98)';
            }, { passive: true });
            
            element.addEventListener('touchend', function() {
                this.style.transform = '';
            }, { passive: true });
            
            element.addEventListener('touchcancel', function() {
                this.style.transform = '';
            }, { passive: true });
        });
    }
    
    // ===================================
    // 4. SMOOTH SCROLL FOR ANCHOR LINKS
    // ===================================
    
    function setupSmoothScroll() {
        const anchorLinks = document.querySelectorAll('a[href^="#"]');
        
        anchorLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                // Ignorer les liens vides ou '#'
                if (!href || href === '#') return;
                
                const target = document.querySelector(href);
                if (!target) return;
                
                e.preventDefault();
                
                const headerHeight = document.querySelector('.nav')?.offsetHeight || 70;
                const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Fermer le menu mobile si ouvert
                const navMenu = document.getElementById('navMenu');
                const navToggle = document.getElementById('navToggle');
                if (navMenu && navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    navToggle?.classList.remove('active');
                    document.body.classList.remove('menu-open');
                }
            });
        });
    }
    
    // ===================================
    // 5. BACK TO TOP BUTTON VISIBILITY
    // ===================================
    
    function setupBackToTop() {
        const backToTop = document.getElementById('backToTop');
        if (!backToTop) return;
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTop.style.opacity = '1';
                backToTop.style.visibility = 'visible';
                backToTop.style.transform = 'translateY(0)';
            } else {
                backToTop.style.opacity = '0';
                backToTop.style.visibility = 'hidden';
                backToTop.style.transform = 'translateY(20px)';
            }
        }, { passive: true });
        
        backToTop.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        // Style initial
        backToTop.style.transition = 'all 0.3s ease';
        backToTop.style.opacity = '0';
        backToTop.style.visibility = 'hidden';
        backToTop.style.transform = 'translateY(20px)';
    }
    
    // ===================================
    // 6. PORTFOLIO FILTERS SCROLL INDICATOR
    // ===================================
    
    function setupFilterScroll() {
        const filtersContainer = document.querySelector('.portfolio-filters');
        if (!filtersContainer) return;
        
        // Vérifier si scroll nécessaire
        function checkScrollNeed() {
            if (filtersContainer.scrollWidth > filtersContainer.clientWidth) {
                filtersContainer.classList.add('has-scroll');
            } else {
                filtersContainer.classList.remove('has-scroll');
            }
        }
        
        checkScrollNeed();
        window.addEventListener('resize', checkScrollNeed);
    }
    
    // ===================================
    // 7. REVEAL ANIMATIONS ON SCROLL
    // ===================================
    
    function setupRevealAnimations() {
        const revealElements = document.querySelectorAll(
            '.service-card, .portfolio-item, .review-card, .process-step, .article-card'
        );
        
        if ('IntersectionObserver' in window) {
            const revealObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            });
            
            revealElements.forEach(element => {
                element.style.opacity = '0';
                element.style.transform = 'translateY(20px)';
                element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                revealObserver.observe(element);
            });
        } else {
            // Fallback: afficher directement
            revealElements.forEach(element => {
                element.style.opacity = '1';
                element.style.transform = 'none';
            });
        }
    }
    
    // ===================================
    // 8. FORM VALIDATION FEEDBACK
    // ===================================
    
    function setupFormFeedback() {
        const formInputs = document.querySelectorAll('input, textarea, select');
        
        formInputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement?.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                this.parentElement?.classList.remove('focused');
                if (this.value) {
                    this.parentElement?.classList.add('filled');
                } else {
                    this.parentElement?.classList.remove('filled');
                }
            });
        });
    }
    
    // ===================================
    // 9. PREVENT ZOOM ON INPUT FOCUS (iOS)
    // ===================================
    
    function preventIOSZoom() {
        if (!/iPhone|iPad|iPod/.test(navigator.userAgent)) return;
        
        const formElements = document.querySelectorAll('input, textarea, select');
        formElements.forEach(element => {
            if (element.style.fontSize && parseFloat(element.style.fontSize) < 16) {
                element.style.fontSize = '16px';
            }
        });
    }
    
    // ===================================
    // 10. HORIZONTAL SCROLL HINT
    // ===================================
    
    function setupHorizontalScrollHint() {
        const horizontalScrollers = document.querySelectorAll('.horizontal-scroller, .portfolio-filters');
        
        horizontalScrollers.forEach(scroller => {
            let hasScrolled = false;
            
            scroller.addEventListener('scroll', function() {
                if (!hasScrolled) {
                    hasScrolled = true;
                    this.classList.add('scrolled');
                }
            }, { passive: true });
        });
    }
    
    // ===================================
    // 11. PERFORMANCE: PASSIVE EVENT LISTENERS
    // ===================================
    
    function optimizeScrollPerformance() {
        // Désactiver pointer-events pendant le scroll pour améliorer performance
        let scrollTimer;
        window.addEventListener('scroll', function() {
            clearTimeout(scrollTimer);
            if (!document.body.classList.contains('scrolling')) {
                document.body.classList.add('scrolling');
            }
            scrollTimer = setTimeout(function() {
                document.body.classList.remove('scrolling');
            }, 150);
        }, { passive: true });
    }
    
    // ===================================
    // 12. FPS MONITOR (DEBUG MODE)
    // ===================================
    
    function setupFPSMonitor() {
        if (!window.location.search.includes('debug')) return;
        
        let lastTime = performance.now();
        let frames = 0;
        
        const fpsDisplay = document.createElement('div');
        fpsDisplay.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: rgba(0, 0, 0, 0.8);
            color: #0f0;
            padding: 5px 10px;
            font-family: monospace;
            font-size: 12px;
            z-index: 99999;
            border-radius: 4px;
        `;
        document.body.appendChild(fpsDisplay);
        
        function measureFPS() {
            const currentTime = performance.now();
            frames++;
            
            if (currentTime >= lastTime + 1000) {
                const fps = Math.round((frames * 1000) / (currentTime - lastTime));
                fpsDisplay.textContent = `FPS: ${fps}`;
                
                // Colorier selon performance
                if (fps >= 55) {
                    fpsDisplay.style.color = '#0f0'; // Vert
                } else if (fps >= 30) {
                    fpsDisplay.style.color = '#ff0'; // Jaune
                } else {
                    fpsDisplay.style.color = '#f00'; // Rouge
                }
                
                frames = 0;
                lastTime = currentTime;
            }
            
            requestAnimationFrame(measureFPS);
        }
        
        measureFPS();
    }
    
    // ===================================
    // INITIALIZATION
    // ===================================
    
    function init() {
        // Attendre le DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
            return;
        }
        
        // Initialiser tous les modules
        updateScrollProgress();
        setupLazyLoading();
        setupTouchFeedback();
        setupSmoothScroll();
        setupBackToTop();
        setupFilterScroll();
        setupRevealAnimations();
        setupFormFeedback();
        preventIOSZoom();
        setupHorizontalScrollHint();
        optimizeScrollPerformance();
        setupFPSMonitor();
        
        console.log('✅ Mobile UX Enhancements v5.0 initialized');
    }
    
    // Démarrer
    init();
    
})();
